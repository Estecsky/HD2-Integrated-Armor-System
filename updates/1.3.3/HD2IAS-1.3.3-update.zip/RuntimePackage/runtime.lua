-- Retired Lua stock stand-ins have no resources or fallback in this native-only build.
rawset(_G,'__hd2ir_stock_swap_frame',nil)
rawset(_G,'__hd2ir_stock_swap_result',nil)
rawset(_G,'__hd2ir_stock_actual_local3',nil)
-- Retired diagnostic observers are deliberately absent in the distributed runtime.
rawset(_G,'__hd2ir_peer_follow_trace',nil)
rawset(_G,'__hd2ir_scan_meter',nil)
rawset(_G,'__hd2ir_work_begin',nil)
rawset(_G,'__hd2ir_work_finish',nil)
rawset(_G,'__hd2ir_work_mark',nil)
rawset(_G,'__hd2ir_work_clock',nil)
rawset(_G,'__hd2ir_teammate_identity_status_sink',nil)
rawset(_G,'__hd2ir_native_handoff',nil)
rawset(_G,'__hd2ir_native_legacy_disabled',false)
do
  local function _v71273becf9af97(x,y)
    local r={5611037,8285469,6574275,8011722}
    return ((x or r[1])+r[2])%r[3],((y or r[4])+r[1])%r[2]
  end
end
do
  local function _v801bad96e82714(x,y)
    local r={834048,6858253,1393138,7663217}
    return ((x or r[1])+r[2])%r[3],((y or r[4])+r[1])%r[2]
  end
end
-- HD2 Independent Rig Runtime - multi-avatar pose feed and guarded Unit driver.
--
-- This file is a mergeable boot.lua BODY. It does not contain or pin the
-- game's boot.lua bytecode. Package it with the Lua Mod Manager only after
-- extracting the current game's boot.lua.
--
-- The normal mode is observe-only.  The explicit "roundtrip" mode reads each
-- configured armour Unit's parent-relative local pose, writes the exact same
-- values back to every weighted node, then calls
-- World.update_unit().  It is an identity proof for the Lua scene-graph route,
-- not the final skeleton correction.  Foreign Units and the avatar Unit are
-- never written, and a residual/error latch disables a failing profile.  The
-- separate "retarget_test" mode converts one C++ model-space result through
-- the Unit's real scene-graph hierarchy. Authored profiles use full correction;
-- legacy experiments keep their small blend. Both retain per-instance gates.

pcall(function()
  local sr = rawget(_G, "stingray")
  if type(sr) ~= "table" then return end

  local function get(t, k)
    local v = nil
    pcall(function() v = t[k] end)
    return v
  end
  local App, W, U = get(sr, "Application"), get(sr, "World"), get(sr, "Unit")
  local Net, GS = get(sr, "Network"), get(sr, "GameSession")
  local Q, V3 = get(sr, "Quaternion"), get(sr, "Vector3")
  local M4 = get(sr, "Matrix4x4")
  local Id64 = get(sr, "IdString64")
  if App == nil or W == nil or U == nil or Q == nil or V3 == nil or
     Id64 == nil then return end

  local ok_ffi, ffi = pcall(require, "ffi")
  if not ok_ffi or type(ffi) ~= "table" then return end
  pcall(function()
    ffi.cdef [[
      void *GetModuleHandleA(const char *name);
      void *GetProcAddress(void *module, const char *name);
      typedef struct hd2ir_scene_input_v1 {
        int parent; unsigned flags;
        double local_pose[7], world_pose[7], parent_pose[7];
      } hd2ir_scene_input_v1;
      typedef struct hd2ir_scene_output_v1 {
        double world_q[5],world_p[4],local_q[5],local_p[4],axis_angle[4],errors[4];
      } hd2ir_scene_output_v1;
      typedef struct hd2ir_status_v1 {
        unsigned version;
        unsigned mode;
        unsigned source_bones;
        unsigned profiles;
        unsigned avatars;
        unsigned unit_instances;
        unsigned long long committed_frame;
        unsigned long long pose_pushes;
        unsigned long long rejected_pushes;
        unsigned long long needle_matches;
        unsigned long long palette_writes;
        unsigned long long ambiguous_instances;
      } hd2ir_status_v1;
      typedef struct hd2ir_physics_capabilities_v1 {
        unsigned version;
        unsigned format_version;
        unsigned capabilities;
        unsigned max_chains;
        unsigned max_joints;
        unsigned max_colliders;
        unsigned max_chain_links;
        unsigned max_instances;
        unsigned max_contacts;
        unsigned max_link_collisions;
        unsigned max_candidates;
        unsigned reserved;
      } hd2ir_physics_capabilities_v1;
      typedef struct hd2ir_physics_status_v1 {
        unsigned version;
        unsigned configs;
        unsigned instances;
        unsigned reserved;
        unsigned long long steps;
        unsigned long long resets;
        unsigned long long rejected_steps;
      } hd2ir_physics_status_v1;
      typedef struct hd2ir_physics_events_v1 {
        unsigned version;
        unsigned last_reset_reason;
        unsigned long long initializations;
        unsigned long long layout_resets;
        unsigned long long frame_gap_resets;
        unsigned long long time_gap_resets;
        unsigned long long teleport_resets;
        unsigned long long continuation_trials;
        unsigned long long animation_fallbacks;
        unsigned long long partial_fallbacks;
        unsigned long long last_reset_frame;
        unsigned long long last_reset_unit;
        unsigned long long last_reset_instance;
        float last_reset_elapsed;
        float last_reset_anchor_distance;
      } hd2ir_physics_events_v1;
    ]]
  end)

  local log_count=0
  local candidate_trace
  local function log(message)
    message=tostring(message)
    if candidate_trace and (message:find("retarget binding",1,true) or
        message:find("presentation",1,true) or message:find("authored nonplayer",1,true) or
        message:find("preview-write",1,true) or message:find("preview-update",1,true) or
        message:find("render feed error",1,true)) then
      local line=message:sub(1,2048)
      pcall(candidate_trace,line,#line)
    end
    if log_count>=16 then return end
    if not (message:find("error",1,true) or message:find("failed",1,true) or message:find("unavailable",1,true)) then return end
    log_count=log_count+1
    local root=os.getenv("APPDATA") or os.getenv("TEMP")
    if not root then return end
    local f=io.open(root.."/hd2_runtime_errors.log",log_count==1 and "w" or "a")
    if f then f:write(os.date("%Y-%m-%d %H:%M:%S")," ",message:sub(1,1024),"\n");f:close()end
  end

  local function try(f)
    local value = nil
    local ok = pcall(function() value = f() end)
    return value, ok
  end
  local function call(f,...)
    return pcall(f,...)
  end
  -- This game's LuaJIT build can trace pcall(f) here as a nil success result
  -- after warmup (reproduced against bin/lua51.dll). Keep the tiny protected
  -- engine-call wrapper interpreted; pose math remains JIT eligible.
  if type(rawget(_G, "jit")) == "table" then jit.off(call, true) end
  local function finite(x)
    return type(x) == "number" and x == x and x < math.huge and x > -math.huge
  end
  local function q4(q)
    local x, y, z, w
    pcall(function() x, y, z, w = Q.to_elements(q) end)
    if not (finite(x) and finite(y) and finite(z) and finite(w)) then return nil end
    return { x, y, z, w }
  end
  local function v3(v)
    local x, y, z
    pcall(function() x, y, z = V3.to_elements(v) end)
    if not (finite(x) and finite(y) and finite(z)) then return nil end
    return { x, y, z }
  end
  local function qnormalize(q)
    local n = math.sqrt(q[1] * q[1] + q[2] * q[2] +
                        q[3] * q[3] + q[4] * q[4])
    if not finite(n) or n < 1.0e-8 then return nil end
    return { q[1] / n, q[2] / n, q[3] / n, q[4] / n }
  end
  local function qconjugate(q)
    return { -q[1], -q[2], -q[3], q[4] }
  end
  local function qmul(a, b)
    local x = a[4] * b[1] + a[1] * b[4] + a[2] * b[3] - a[3] * b[2]
    local y = a[4] * b[2] - a[1] * b[3] + a[2] * b[4] + a[3] * b[1]
    local z = a[4] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[4]
    local w = a[4] * b[4] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3]
    local n = math.sqrt(x*x+y*y+z*z+w*w)
    if not finite(n) or n < 1.0e-8 then return nil end
    return {x/n,y/n,z/n,w/n}
  end
  local function qrotate(q, p)
    -- Unit quaternions and the C++ Mat34 bridge use the same active,
    -- column-vector convention.  This expanded form avoids allocating two
    -- temporary quaternions per bone.
    local x, y, z, w = q[1], q[2], q[3], q[4]
    local tx = 2.0 * (y * p[3] - z * p[2])
    local ty = 2.0 * (z * p[1] - x * p[3])
    local tz = 2.0 * (x * p[2] - y * p[1])
    return {
      p[1] + w * tx + (y * tz - z * ty),
      p[2] + w * ty + (z * tx - x * tz),
      p[3] + w * tz + (x * ty - y * tx),
    }
  end
  local function qerror_degrees(a, b)
    -- Same conjugate/product/normalization as qmul, without allocating three
    -- temporary tables per residual test. Keep operation order and guards.
    local ax,ay,az,aw = -a[1],-a[2],-a[3],a[4]
    local x = aw*b[1]+ax*b[4]+ay*b[3]-az*b[2]
    local y = aw*b[2]-ax*b[3]+ay*b[4]+az*b[1]
    local z = aw*b[3]+ax*b[2]-ay*b[1]+az*b[4]
    local w = aw*b[4]-ax*b[1]-ay*b[2]-az*b[3]
    local n = math.sqrt(x*x+y*y+z*z+w*w)
    if not finite(n) or n < 1.0e-8 then return math.huge end
    w = math.abs(w/n)
    if w > 1.0 then w = 1.0 end
    return 2.0 * math.acos(w) * 180.0 / math.pi
  end
  local function perror(a, b)
    local x, y, z = a[1] - b[1], a[2] - b[2], a[3] - b[3]
    return math.sqrt(x * x + y * y + z * z)
  end
  local function compose_pose(aq, ap, bq, bp)
    local q = qmul(aq, bq)
    local rp = qrotate(aq, bp)
    if q == nil or rp == nil then return nil, nil end
    return q, {ap[1] + rp[1], ap[2] + rp[2], ap[3] + rp[3]}
  end
  local function relative_pose(parent_q, parent_p, child_q, child_p)
    local inverse_q = qconjugate(parent_q)
    local q = qmul(inverse_q, child_q)
    local p = qrotate(inverse_q, {
      child_p[1] - parent_p[1],
      child_p[2] - parent_p[2],
      child_p[3] - parent_p[3],
    })
    return q, p
  end
  local function inverse_pose(q, p)
    local inverse_q = qconjugate(q)
    local inverse_p = qrotate(inverse_q, {-p[1], -p[2], -p[3]})
    return inverse_q, inverse_p
  end
  local function qnlerp(a, b, amount)
    local dot = a[1] * b[1] + a[2] * b[2] +
                a[3] * b[3] + a[4] * b[4]
    if dot < 0.0 then
      b = {-b[1], -b[2], -b[3], -b[4]}
    end
    return qnormalize({
      a[1] + (b[1] - a[1]) * amount,
      a[2] + (b[2] - a[2]) * amount,
      a[3] + (b[3] - a[3]) * amount,
      a[4] + (b[4] - a[4]) * amount,
    })
  end
  local function matrix_pose(matrix, offset)
    local r00, r01, r02 = tonumber(matrix[offset + 0]),
                          tonumber(matrix[offset + 1]),
                          tonumber(matrix[offset + 2])
    local r10, r11, r12 = tonumber(matrix[offset + 4]),
                          tonumber(matrix[offset + 5]),
                          tonumber(matrix[offset + 6])
    local r20, r21, r22 = tonumber(matrix[offset + 8]),
                          tonumber(matrix[offset + 9]),
                          tonumber(matrix[offset + 10])
    local px, py, pz = tonumber(matrix[offset + 3]),
                       tonumber(matrix[offset + 7]),
                       tonumber(matrix[offset + 11])
    if not (finite(r00) and finite(r01) and finite(r02) and
            finite(r10) and finite(r11) and finite(r12) and
            finite(r20) and finite(r21) and finite(r22) and
            finite(px) and finite(py) and finite(pz)) then
      return nil, nil
    end
    local x, y, z, w
    local trace = r00 + r11 + r22
    if trace > 0.0 then
      local s = math.sqrt(trace + 1.0) * 2.0
      if s < 1.0e-8 then return nil, nil end
      w, x, y, z = 0.25 * s, (r21 - r12) / s,
                   (r02 - r20) / s, (r10 - r01) / s
    elseif r00 > r11 and r00 > r22 then
      local s = math.sqrt(math.max(0.0, 1.0 + r00 - r11 - r22)) * 2.0
      if s < 1.0e-8 then return nil, nil end
      w, x, y, z = (r21 - r12) / s, 0.25 * s,
                   (r01 + r10) / s, (r02 + r20) / s
    elseif r11 > r22 then
      local s = math.sqrt(math.max(0.0, 1.0 + r11 - r00 - r22)) * 2.0
      if s < 1.0e-8 then return nil, nil end
      w, x, y, z = (r02 - r20) / s, (r01 + r10) / s,
                   0.25 * s, (r12 + r21) / s
    else
      local s = math.sqrt(math.max(0.0, 1.0 + r22 - r00 - r11)) * 2.0
      if s < 1.0e-8 then return nil, nil end
      w, x, y, z = (r10 - r01) / s, (r02 + r20) / s,
                   (r12 + r21) / s, 0.25 * s
    end
    local q = qnormalize({x, y, z, w})
    if q == nil then return nil, nil end
    return q, {px, py, pz}
  end

  local pose_capture={}
  local V3Ctor = rawget(_G, "Vector3") or V3
  function pose_capture.vector(p,result)
    result.value=V3Ctor(p[1],p[2],p[3])
  end
  local function engine_vector(p)
    local result={}
    pcall(pose_capture.vector,p,result)
    return result.value
  end
  function pose_capture.quaternion(ax,ay,az,angle,result)
    local axis=V3Ctor(ax,ay,az)
    if axis==nil then return end
    local value=Q.axis_angle(axis,angle)
    if value==nil then return end
    local valid=Q.is_valid
    if type(valid)=="function" and valid(value)~=true then return end
    result.value=value
  end
  local function engine_quaternion(q)
    q = qnormalize(q)
    if q == nil then return nil end
    -- q and -q are the same rotation.  Choose w >= 0 so the axis-angle stays
    -- on the short arc and remains well conditioned around the identity.
    if q[4] < 0.0 then
      q = { -q[1], -q[2], -q[3], -q[4] }
    end
    local w = q[4]
    if w > 1.0 then w = 1.0 elseif w < -1.0 then w = -1.0 end
    local angle = 2.0 * math.acos(w)
    local s = math.sqrt(math.max(0.0, 1.0 - w * w))
    local ax,ay,az
    if s < 1.0e-7 then
      ax,ay,az=1.0,0.0,0.0
      angle = 0.0
    else
      ax,ay,az=q[1]/s,q[2]/s,q[3]/s
    end
    -- Construct and validate under one guard, publishing only after success.
    -- No userdata is retained across callbacks; any engine failure returns nil.
    local result={}
    pcall(pose_capture.quaternion,ax,ay,az,angle,result)
    return result.value
  end
  local function fill_matrix(out, offset, q, t)
    local x, y, z, w = q[1], q[2], q[3], q[4]
    local xx, yy, zz = x * x, y * y, z * z
    local xy, xz, yz = x * y, x * z, y * z
    local wx, wy, wz = w * x, w * y, w * z
    out[offset + 0] = 1.0 - 2.0 * (yy + zz)
    out[offset + 1] = 2.0 * (xy - wz)
    out[offset + 2] = 2.0 * (xz + wy)
    out[offset + 3] = t[1]
    out[offset + 4] = 2.0 * (xy + wz)
    out[offset + 5] = 1.0 - 2.0 * (xx + zz)
    out[offset + 6] = 2.0 * (yz - wx)
    out[offset + 7] = t[2]
    out[offset + 8] = 2.0 * (xz - wy)
    out[offset + 9] = 2.0 * (yz + wx)
    out[offset + 10] = 1.0 - 2.0 * (xx + yy)
    out[offset + 11] = t[3]
  end
  function pose_capture.legacy_pose(unit,node,world,result)
    local rotation_getter,position_getter=U.local_rotation,U.local_position
    if world then rotation_getter,position_getter=U.world_rotation,U.world_position end
    local x,y,z,w=Q.to_elements(rotation_getter(unit,node))
    local a,b,c=V3.to_elements(position_getter(unit,node))
    if not (finite(x) and finite(y) and finite(z) and finite(w) and finite(a) and finite(b) and finite(c)) then return end
    result.q,result.p={x,y,z,w},{a,b,c}
  end
  -- Each engine matrix is consumed immediately into numbers. No userdata or
  -- pose cache survives a call; post-write reads still query every written node.
  pose_capture.matrix_enabled=M4 and type(M4.to_elements)=='function' and
    type(U.local_pose)=='function' and type(U.world_pose)=='function'
  pose_capture.matrix_checks={[false]=0,[true]=0}
  pose_capture.matrix_info={enabled=pose_capture.matrix_enabled==true,local_checks=0,world_checks=0}
  function pose_capture.matrix_read(unit,node,world,result)
    local getter=world and U.world_pose or U.local_pose
    local a,d,g,b,e,h,c,f,i,x,y,z=M4.to_elements(getter(unit,node))
    if not(finite(a)and finite(b)and finite(c)and finite(d)and finite(e)and finite(f)and
      finite(g)and finite(h)and finite(i)and finite(x)and finite(y)and finite(z))then return end
    -- Reject scale, shear and reflection; keep the existing quaternion path
    -- for these nodes instead of silently normalizing a different transform.
    if math.abs(a*a+b*b+c*c-1)>.002 or math.abs(d*d+e*e+f*f-1)>.002 or
      math.abs(g*g+h*h+i*i-1)>.002 or math.abs(a*d+b*e+c*f)>.002 or
      math.abs(a*g+b*h+c*i)>.002 or math.abs(d*g+e*h+f*i)>.002 or
      math.abs(a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g)-1)>.003 then return end
    result.q,result.p=matrix_pose({a,b,c,x,d,e,f,y,g,h,i,z},1)
  end
  function pose_capture.pose(unit,node,world,result)
    result.q,result.p=nil,nil
    if pose_capture.matrix_enabled then
      local ok=pcall(pose_capture.matrix_read,unit,node,world,result)
      if ok and result.q then
        local checks=pose_capture.matrix_checks[world]
        if checks<128 then
          local old={};pose_capture.legacy_pose(unit,node,world,old)
          local q=old.q and qnormalize(old.q)
          if not q or not old.p or qerror_degrees(q,result.q)>.05 or perror(old.p,result.p)>.0005 then
            pose_capture.matrix_enabled=false;pose_capture.matrix_info.enabled=false;result.q,result.p=old.q,old.p
            log('core matrix reader: legacy fallback after pose contract mismatch')
            return
          end
          pose_capture.matrix_checks[world]=checks+1
          pose_capture.matrix_info[world and 'world_checks' or 'local_checks']=checks+1
          if checks==127 then log('core matrix reader: 128 '..(world and 'world' or 'local')..' pose checks accepted')end
        end
        return
      end
    end
    result.q,result.p=nil,nil
    pose_capture.legacy_pose(unit,node,world,result)
  end

  local function pose_numbers(unit,node,world)
    -- Stable protected reader; publish numbers only after every getter and
    -- finite check succeeds, without retaining engine values across calls.
    local result={}
    pcall(pose_capture.pose,unit,node,world,result)
    if not result.q then return nil,nil end
    return result.q,result.p
  end
  local function world_pose(unit, node)
    return pose_numbers(unit,node,true)
  end
  --@@CONTACT_FRAME_HELPERS_BEGIN@@
  -- These caches share the render source-snapshot lifetime. No engine handle
  -- survives the callback, and neither the FP graph nor Avatar is written here.
  function pose_capture.fp_graphs(world)
    local cache=rawget(_G,"__hd2ir_source_reads")
    local rows=cache and cache.fp_graphs
    if rows and rows[world] then return rows[world] end
    local units=try(function()
      return W.units_by_resource(world,"content/fac_helldivers/fp_cha_avatar/fp_cha_avatar")
    end)
    if cache and type(units)=="table" then
      if not rows then rows={};cache.fp_graphs=rows end
      rows[world]=units
    end
    return units
  end
  function pose_capture.fp_pose(unit,name)
    local cache=rawget(_G,"__hd2ir_source_reads")
    local units=cache and cache.fp_poses
    local rows=units and units[unit]
    if rows and rows[name] then return rows[name].q,rows[name].p end
    local node=try(function()if U.has_node(unit,name) then return U.node(unit,name) end end)
    if type(node)~="number" or node<0 then return nil,nil end
    local q,p=world_pose(unit,node)
    if not q or not p then return nil,nil end
    if cache then
      if not units then units={};cache.fp_poses=units end
      if not rows then rows={};units[unit]=rows end
      rows[name]={q=q,p=p}
    end
    return q,p
  end
  function pose_capture.local_contact_owner(avatar)
    if not avatar or not avatar.unit or not avatar.world or avatar.presentation_kind then return false end
    local cache=rawget(_G,"__hd2ir_source_reads")
    local owners=cache and cache.local_contact_owners
    if owners and owners[avatar]~=nil then return owners[avatar] end
    local identity=rawget(_G,"__hd2ir_physics_identity")
    local ok,owned=pcall(function()
      if not identity or identity.role(avatar.unit)~=1 then return false end
      local life=identity.shared_life(avatar.unit,avatar.world)
      return life~=nil and life.kind==nil
    end)
    owned=ok and owned==true
    if cache then
      if not owners then owners={};cache.local_contact_owners=owners end
      owners[avatar]=owned
    end
    return owned
  end
  function pose_capture.local_third_person(avatar)
    -- The local root/camera separation excludes ADS (observed <=0.93 m).
    -- A teammate passing our camera must neither steal the owner nor latch a
    -- global first-person gate. Native arm/weapon proofs remain mandatory.
    return pose_capture.local_contact_owner(avatar) and
      finite(avatar.camera_distance) and avatar.camera_distance>1.0
  end
  --@@CONTACT_FRAME_HELPERS_END@@
  function pose_capture.node(unit,node,result)
    pose_capture.pose(unit,node,false,result)
    if not result.q then return end
    result.local_q,result.local_p=result.q,result.p
    pose_capture.pose(unit,node,true,result)
    if not result.q then return end
    result.world_q,result.world_p=result.q,result.p
    result.parent=U.scene_graph_parent(unit,node)
    result.complete=true
  end
  local function node_pose_numbers(unit,node)
    local result={}
    pcall(pose_capture.node,unit,node,result)
    if not result.complete then return nil end
    return result
  end
  local function local_pose(unit, node)
    local rotation = try(function() return U.local_rotation(unit, node) end)
    local position = try(function() return U.local_position(unit, node) end)
    if q4(rotation) == nil or v3(position) == nil then return nil, nil end
    return rotation, position
  end
  -- One protected, synchronous readback per Unit, not two closures/pcalls per
  -- bone. Numeric results live only in this callback's write list. A failed
  -- getter cannot publish a completed batch; the caller still rolls it back.
  function pose_capture.readback(unit,writes,want_world,result)
    for i=1,#writes do
      local pose=writes[i]
      result.error="post-write local read failed"
      pose_capture.pose(unit,pose.node,false,result)
      if not result.q then return end
      pose.after_q,pose.after_p=result.q,result.p
      if want_world then
        result.error="post-write native-link world residual"
        pose_capture.pose(unit,pose.node,true,result)
        if not result.q then return end
        pose.after_world_q,pose.after_world_p=result.q,result.p
      end
    end
    result.complete=true
  end
  function pose_capture.verify_scene_completion(unit,writes,want_world,explicit,result)
    local read={}
    pose_capture.readback(unit,writes,want_world,read)
    if not read.complete then result.error=read.error;return end
    local residual_r,residual_p=0.0,0.0
    for _,pose in ipairs(writes)do
      local q=pose.after_q and qnormalize(pose.after_q)
      if not q then result.error="completed shared scene local residual";return end
      local r,p=qerror_degrees(pose.q,q),perror(pose.p,pose.after_p)
      residual_r,residual_p=math.max(residual_r,r),math.max(residual_p,p)
      if r>0.5 or p>0.002 then
        result.error="completed shared scene local residual";return
      end
      if want_world then
        local expected=explicit[pose.node+1]
        if not expected or qerror_degrees(pose.after_world_q,expected.q)>0.1 or
            perror(pose.after_world_p,expected.p)>0.001 then
          result.error="completed shared scene world residual";return
        end
      end
    end
    result.residual_r,result.residual_p=residual_r,residual_p
    result.complete=true
  end
  local function debug_name(unit)
    return string.lower(tostring((try(function() return U.debug_name(unit) end))))
  end

  local C, source_names, profiles = nil, {}, {}
  local bridge_attempt = -1000000
  local function load_bridge(frame)
    if C ~= nil then return true end
    if frame - bridge_attempt < 300 then return false end
    bridge_attempt = frame
    local ok_k32, k32 = pcall(ffi.load, "kernel32")
    if not ok_k32 then return false end
    local module = try(function()
      return k32.GetModuleHandleA("HD2IndependentRig.addon64")
    end)
    if module == nil or module == ffi.NULL then return false end
    local function fn(name, signature)
      local address = try(function() return k32.GetProcAddress(module, name) end)
      if address == nil or address == ffi.NULL then return nil end
      return (try(function() return ffi.cast(signature, address) end))
    end
    local physics_capabilities =
      fn("hd2ir_get_physics_capabilities", "unsigned (*)(void *, unsigned)")
    local physics_status =
      fn("hd2ir_get_physics_status", "unsigned (*)(void *, unsigned)")
    local api = {
      source_count = fn("hd2ir_source_bone_count", "unsigned (*)(void)"),
      source_name = fn("hd2ir_source_bone_name",
                       "unsigned (*)(unsigned, char *, unsigned)"),
      profile_count = fn("hd2ir_profile_count", "unsigned (*)(void)"),
      profile_id = fn("hd2ir_profile_unit_id",
                      "unsigned long long (*)(unsigned)"),
      profile_hash = fn("hd2ir_profile_unit_hash",
                        "unsigned (*)(unsigned, char *, unsigned)"),
      profile_flags = fn("hd2ir_profile_flags",
                         "unsigned (*)(unsigned, unsigned *)"),
      profile_active = fn("hd2ir_profile_active",
                          "unsigned (*)(unsigned)"),
      -- Discovery retains every valid free option. The runtime's live filter
      -- stops inactive output/physics; a later selection needs no Lua reload.
      profile_available = fn("hd2ir_profile_available", "unsigned (*)(unsigned)")
        or fn("hd2ir_profile_active", "unsigned (*)(unsigned)"),
      profile_target_count = fn("hd2ir_profile_target_count",
                                "unsigned (*)(unsigned)"),
      profile_target_node = fn("hd2ir_profile_target_node",
                               "unsigned (*)(unsigned, unsigned, unsigned *)"),
      profile_target_source = fn("hd2ir_profile_target_source_index",
                                 "unsigned (*)(unsigned, unsigned, unsigned *)"),
      profile_target_flags = fn("hd2ir_profile_target_flags",
                                "unsigned (*)(unsigned, unsigned, unsigned *)"),
      begin_frame = fn("hd2ir_begin_frame",
                       "unsigned (*)(unsigned long long)"),
      push_avatar = fn("hd2ir_push_avatar_pose",
                       "unsigned (*)(unsigned long long, const float *, unsigned, const float *)"),
      bind_unit = fn("hd2ir_bind_unit_instance",
                     "unsigned (*)(unsigned long long, unsigned long long, unsigned long long, const float *)"),
      end_frame = fn("hd2ir_end_frame",
                     "unsigned (*)(unsigned long long)"),
      retarget_bound = fn("hd2ir_retarget_bound_unit",
                          "unsigned (*)(unsigned long long, unsigned, unsigned *, float *)"),
      get_status = fn("hd2ir_get_status", "unsigned (*)(void *, unsigned)"),
    }
    for _, f in pairs(api) do if f == nil then return false end end
    api.retarget_unit_pose = fn("hd2ir_retarget_bound_unit_pose",
      "unsigned (*)(unsigned long long, unsigned, const float *, unsigned, unsigned *, float *)")
    api.retarget_unit_pose_action = fn("hd2ir_retarget_bound_unit_pose_action",
      "unsigned (*)(unsigned long long, unsigned, const float *, unsigned, unsigned, unsigned *, float *)")
    api.set_avatar_physics_class = fn("hd2ir_set_avatar_physics_class",
      "unsigned (*)(unsigned long long, unsigned)")
    api.shared_next_incarnation = fn("hd2ir_shared_next_incarnation", "unsigned long long (*)(void)")
    api.set_avatar_incarnation = fn("hd2ir_set_avatar_incarnation", "unsigned (*)(unsigned long long, unsigned long long)")
    api.forget_shared_avatar = fn("hd2ir_forget_shared_avatar", "unsigned (*)(unsigned long long, unsigned long long)")
    api.profile_domain = fn("hd2ir_profile_domain", "unsigned (*)(unsigned)")
    api.shared_body_profile = fn("hd2ir_shared_body_profile", "unsigned (*)(unsigned long long)")
    api.shared_body_solves = fn("hd2ir_shared_body_solves", "unsigned long long (*)(void)")
    -- Production keeps optional diagnostic callbacks unset. The guard also
    -- skips diagnostic pose collection before it reaches the normal log path.
    api.set_avatar_gait_weight = fn("hd2ir_set_avatar_gait_weight",
      "unsigned (*)(unsigned long long, float)")
    api.gait_correction_enabled = fn("hd2ir_gait_correction_enabled", "unsigned (*)(void)")
    api.corpse_freeze_enabled = fn("hd2ir_corpse_freeze_enabled", "unsigned (*)(void)")
    api.corpse_freeze_context = fn("hd2ir_corpse_freeze_context", "void (*)(uint64_t, unsigned)")
    api.freeze_corpse_physics = fn("hd2ir_freeze_corpse_physics", "unsigned (*)(uint64_t, uint64_t, uint64_t)")
    api.prepare_scene = fn("hd2ir_prepare_scene_pose_v1",
      "unsigned (*)(unsigned, unsigned, const hd2ir_scene_input_v1 *, const double *, const float *, unsigned, hd2ir_scene_output_v1 *)")
    api.retarget_unit_pose_contacts = fn("hd2ir_retarget_bound_unit_pose_contacts",
      "unsigned (*)(unsigned long long, unsigned, const float *, unsigned, unsigned, const float *, unsigned, unsigned *, float *)")
    api.retarget_unit_pose_singlehand = fn("hd2ir_retarget_bound_unit_pose_singlehand",
      "unsigned (*)(unsigned long long, unsigned, const float *, unsigned, unsigned, const float *, unsigned, unsigned *, float *)")
    api.weapon_root_trial_enabled = fn("hd2ir_weapon_root_trial_enabled", "unsigned (*)(void)")
    api.get_physics_events = fn("hd2ir_get_physics_events", "unsigned (*)(void *, unsigned)")
    api.weapon_root_offset = fn("hd2ir_tp_weapon_visual_offset",
      "unsigned (*)(unsigned long long, const float *, unsigned, const float *, const float *, float *)")
    api.retarget_presentation_pose = fn("hd2ir_retarget_presentation_pose",
      "unsigned (*)(unsigned long long, const float *, unsigned, const float *, unsigned, unsigned *, float *)")
    api.retarget_first_person_pose = fn("hd2ir_retarget_first_person_pose",
      "unsigned (*)(unsigned long long, const float *, unsigned, const float *, unsigned, unsigned *, float *)")
    api.retarget_presentation_instance = fn("hd2ir_retarget_presentation_instance",
      "unsigned (*)(unsigned long long, unsigned long long, unsigned long long, unsigned long long, const float *, unsigned, const float *, unsigned, unsigned *, float *)")

    local physics_unavailable_reason = nil
    if physics_capabilities == nil and physics_status == nil then
      physics_unavailable_reason = "缺少 PhysBone ABI 符号"
    elseif physics_capabilities == nil or physics_status == nil then
      physics_unavailable_reason = "PhysBone ABI 符号不完整"
    else
      local capabilities_size = ffi.sizeof("hd2ir_physics_capabilities_v1")
      local status_size = ffi.sizeof("hd2ir_physics_status_v1")
      if capabilities_size ~= 48 or status_size ~= 40 then
        physics_unavailable_reason = string.format(
          "LuaJIT FFI 结构尺寸不匹配 capabilities=%d/48 status=%d/40",
          capabilities_size, status_size)
      else
        local capabilities = ffi.new("hd2ir_physics_capabilities_v1[1]")
        -- try returns (value, ok); capture one value so ok cannot become
        -- tonumber's optional numeric-base argument and abort the bridge.
        local returned = try(function()
          return physics_capabilities(capabilities, capabilities_size)
        end)
        returned = tonumber(returned) or 0
        if returned ~= capabilities_size then
          physics_unavailable_reason = string.format(
            "能力查询尺寸不匹配 returned=%d expected=%d",
            returned, capabilities_size)
        elseif tonumber(capabilities[0].version) ~= 1 then
          physics_unavailable_reason = string.format(
            "不支持的 PhysBone ABI 版本 %d",
            tonumber(capabilities[0].version) or -1)
        else
          local p = capabilities[0]
          local format_version = tonumber(p.format_version) or -1
          local capability_bits = tonumber(p.capabilities) or -1
          local max_chains = tonumber(p.max_chains) or -1
          local max_joints = tonumber(p.max_joints) or -1
          local max_colliders = tonumber(p.max_colliders) or -1
          local max_chain_links = tonumber(p.max_chain_links) or -1
          local max_instances = tonumber(p.max_instances) or -1
          local max_contacts = tonumber(p.max_contacts) or -1
          local max_link_collisions = tonumber(p.max_link_collisions) or -1
          local max_candidates = tonumber(p.max_candidates) or -1
          local reserved = tonumber(p.reserved) or -1
          if format_version ~= 1 then
            physics_unavailable_reason = string.format(
              "不支持的 PhysBone 文件版本 %d", format_version)
          -- 0x7df is the current node-contact build: collision filters are
          -- advertised and retired segment contacts are not. Keep legacy
          -- 0x3ff status compatibility; do not accept arbitrary new bits.
          elseif capability_bits ~= 0x3ff and capability_bits ~= 0x7df then
            physics_unavailable_reason = string.format(
              "PhysBone 局部弯曲/布条约束能力位不完整或包含未知扩展 0x%x", capability_bits)
          elseif max_chains ~= 1024 or max_joints ~= 8192 or
                 max_colliders ~= 1024 or max_chain_links ~= 1024 or
                 max_instances ~= 1024 or max_contacts ~= 32768 or
                 max_link_collisions ~= 8192 or max_candidates ~= 65536 then
            physics_unavailable_reason = string.format(
              "PhysBone P6 上限不匹配 chains=%d joints=%d colliders=%d links=%d instances=%d contacts=%d link_collisions=%d candidates=%d",
              max_chains, max_joints, max_colliders, max_chain_links,
              max_instances, max_contacts, max_link_collisions, max_candidates)
          elseif reserved ~= 0 then
            physics_unavailable_reason = "PhysBone P6 保留字段非零"
          else
            api.get_physics_status = physics_status
            api.physics_capabilities = {
              version = tonumber(p.version),
              format_version = format_version,
              capabilities = capability_bits,
              max_chains = max_chains,
              max_joints = max_joints,
              max_colliders = max_colliders,
              max_chain_links = max_chain_links,
              max_instances = max_instances,
              max_contacts = max_contacts,
              max_link_collisions = max_link_collisions,
              max_candidates = max_candidates,
            }
          end
        end
      end
    end

    local bones, units = {}, {}
    local count = tonumber(api.source_count()) or 0
    if count < 1 or count > 256 then return false end
    local text = ffi.new("char[128]")
    for i = 0, count - 1 do
      if tonumber(api.source_name(i, text, 128)) <= 1 then return false end
      bones[#bones + 1] = ffi.string(text)
    end
    local profile_count = tonumber(api.profile_count()) or 0
    if profile_count < 0 or profile_count > 512 or (profile_count==0 and not rawget(_G,"__hd2ir_native_handoff")) then return false end
    local hash = ffi.new("char[32]")
    local node_out = ffi.new("unsigned[1]")
    local seen_unit_hashes = {}
    local observe_only_profiles = 0
    local active_profiles = 0
    local unmarked_profiles = 0
    for i = 0, profile_count - 1 do
      if tonumber(api.profile_hash(i, hash, 32)) <= 1 then return false end
      local unit_hash = string.lower(ffi.string(hash))
      if not seen_unit_hashes[unit_hash] then
        seen_unit_hashes[unit_hash] = true
        if tonumber(api.profile_flags(i, node_out)) ~= 1 then return false end
        local profile_flags = tonumber(node_out[0]) or 0
        local observe_only = math.floor(profile_flags / 2) % 2 == 1
        local active = tonumber(api.profile_available(i)) == 1
        local gender = math.floor(profile_flags / 4) % 4
        if gender==3 then return false end
        if gender==0 then unmarked_profiles=unmarked_profiles+1 end
        -- A declaration is mandatory for any pose-correction observation.
        -- Do not even resolve graph targets for unmarked/inactive profiles.
        if gender~=0 and active then
        if observe_only then observe_only_profiles = observe_only_profiles + 1 end
        if active then active_profiles = active_profiles + 1 end
        local target_count = tonumber(api.profile_target_count(i)) or 0
        if target_count < 1 or target_count > 256 then return false end
        local nodes, target_sources, target_flags, seen_nodes = {}, {}, {}, {}
        local authored = false
        for ti = 0, target_count - 1 do
          if tonumber(api.profile_target_node(i, ti, node_out)) ~= 1 then
            return false
          end
          local node = tonumber(node_out[0])
          if node == nil or node < 0 or node > 4095 then return false end
          if seen_nodes[node] then return false end
          seen_nodes[node] = true
          nodes[#nodes + 1] = node
          if tonumber(api.profile_target_source(i, ti, node_out)) ~= 1 then
            return false
          end
          local source_index = tonumber(node_out[0])
          if source_index == nil or source_index < 0 or
             source_index >= #bones then return false end
          target_sources[#target_sources + 1] = source_index
          if tonumber(api.profile_target_flags(i, ti, node_out)) ~= 1 then
            return false
          end
          target_flags[#target_flags + 1] = tonumber(node_out[0]) or 0
          if math.floor(target_flags[#target_flags] / 1024) % 2 == 1 then
            authored = true
          end
        end
        local anchor_nodes, seen_anchor_nodes = {}, {}
        local function add_anchor(target_index)
          local node = nodes[target_index]
          if node ~= nil and not seen_anchor_nodes[node] and
             #anchor_nodes < 3 then
            seen_anchor_nodes[node] = true
            anchor_nodes[#anchor_nodes + 1] = node
          end
        end
        if observe_only then
          for _, preferred_name in ipairs({"head", "neck", "chest", "boss", "root"}) do
            for target_index = 1, #target_sources do
              if bones[target_sources[target_index] + 1] == preferred_name then
                add_anchor(target_index)
              end
            end
          end
          add_anchor(1)
          add_anchor(math.floor((#nodes + 1) / 2))
          add_anchor(#nodes)
        end
        units[#units + 1] = {
          index = i,
          id = api.profile_id(i),
          hash = unit_hash,
          flags = profile_flags,
          active = active,
          observe_only = observe_only,
          female = gender==2,
          nodes = nodes,
          anchor_nodes = anchor_nodes,
          target_sources = target_sources,
          target_flags = target_flags,
          authored = authored,
          -- Metadata only. The native binding remains mandatory for visibility.
          domain = api.profile_domain and tonumber(api.profile_domain(i)) or 0,
          target_count = target_count,
        }
        end
      end
    end
    if rawget(_G,"__hd2ir_pose_batch") then rawget(_G,"__hd2ir_pose_batch").install(api,fn) end
    C, source_names, profiles = api, bones, units
    rawset(_G,"__hd2ir_declared_profile_count",#units)
    log(string.format(
      "bridge ready: %d source bones, %d Unit profiles, %d active, %d observe-only, %d unmarked-native",
      #source_names, #profiles, active_profiles, observe_only_profiles,unmarked_profiles))
    if api.physics_capabilities ~= nil then
      local p = api.physics_capabilities
      log(string.format(
        "PhysBone bridge ready: format=%d capabilities=0x%x " ..
        "max_chains=%d max_joints=%d max_colliders=%d max_chain_links=%d " ..
        "max_instances=%d max_contacts=%d max_link_collisions=%d max_candidates=%d",
        p.format_version, p.capabilities, p.max_chains, p.max_joints,
        p.max_colliders, p.max_chain_links, p.max_instances, p.max_contacts,
        p.max_link_collisions, p.max_candidates))
    else
      log("当前 addon 不支持扩展 PhysBone: " ..
          tostring(physics_unavailable_reason or "未知原因"))
    end
    return true
  end

  local AVATAR_RESOURCE = "content/fac_helldivers/cha_avatar/avatar_helldiver"
  -- EX-03 and EX-16 share the ordinary body Units. Their package manifests do
  -- contain six variant-only Unit resources each, however. These candidates
  -- are read-only identity anchors: later builds can keep the Unit alive while
  -- replacing its visible mesh with an empty/custom mesh, so hiding armour
  -- plates does not have to destroy per-armour identity.
  local ARMOUR_MARKER_IDS = {
    {family = "ex03", hash = "40189ccbd00bbed1"},
    {family = "ex03", hash = "5c9d044ef0f869ab"},
    {family = "ex03", hash = "9929e54e0469d5b3"},
    {family = "ex03", hash = "b10f6fbc0100c388"},
    {family = "ex03", hash = "b47137c061c13946"},
    {family = "ex03", hash = "ec2a6695ebc9cd84"},
    {family = "ex16", hash = "07fe9ad17429dc6b"},
    {family = "ex16", hash = "1599344ea7c10370"},
    {family = "ex16", hash = "183271a9d7fe06c3"},
    {family = "ex16", hash = "a5b75ba593c03fc0"},
    {family = "ex16", hash = "aa0ec0745d816c7c"},
    {family = "ex16", hash = "fe0a7081f76f9ab5"},
  }
  local marker_probe_logged = {}
  local marker_lookup_hits, marker_lookup_misses = 0, 0
  local marker_assignment_logged = {}
  local marker_assignments, marker_conflicts = 0, 0
  local MARKER_ASSOCIATION_MARGIN = 0.05
  -- V23.1 custom art carrier lease. V23 proved that a marker-attributed EX-16
  -- Avatar can own a separately spawned custom Unit, but linking that Unit to
  -- a presentation Avatar let native World teardown destroy an external child
  -- and crashed while opening the armour screen. The safe lease therefore:
  --   * never keeps Unit handles or IdString64 values across render callbacks;
  --   * never links or explicitly destroys a carrier;
  --   * re-discovers carriers and writes their unparented root pose each frame;
  --   * hides an unused carrier and lets its World perform final destruction;
  --   * skips worlds whose Avatar roots overlap (equipment/presentation UI).
  local CARRIER_RESOURCE = "content/hd2ir/avatar/ex16/carrier_v23"
  local CARRIER_RESOURCE_HASH = "7765c19fcc75cd9a"
  -- V24/V25 resource-slot probes: the independently spawned clone is
  -- deliberately disabled. A magenta donor is routed through a native body or
  -- armour FileID instead, so the equipment system—not Lua—owns first-person
  -- visibility. Production export will split each armour's art into the same
  -- native visibility groups.
  local CARRIER_NATIVE_CHEST_SLOT_PROBE = true
  local CARRIER_OFFSET = {0.60, 0.0, 0.20}
  local CARRIER_ROOT_NODE = 1
  local CARRIER_MATCH_LIMIT2 = 2.25
  local CARRIER_MATCH_MARGIN = 0.05
  local PRESENTATION_OVERLAP2 = 0.0001
  local carrier_spawned, carrier_hidden, carrier_errors = 0, 0, 0
  local carrier_log_once = {}
  -- tostring(Unit) is the resource identity, not an instance identity: two
  -- players using the same Avatar print the same value. We never call an API
  -- through a cached key; each frame first re-queries the World. Identity-only
  -- keys are bounded below and never dereferenced after their callback.
  local carrier_world_safe = setmetatable({}, {__mode = "k"})
  local frame = 0
  -- Keys are retained briefly for identity only; never call an API through
  -- a cached key. Weak keys vanished at GC and caused false remove/add events.
  local instance_slots, instance_seen = {}, {}
  local instance_pruned = -1
  local next_instance_slot = 1
  local function instance_slot(value)
    if value == nil then return 0 end
    if frame % 120 == 0 and instance_pruned ~= frame then
      instance_pruned = frame
      for key, last in pairs(instance_seen) do
        if frame - last > 2 and not (rawget(_G,'__hd2ir_corpse_slots') or {})[instance_slots[key]] then
          instance_slots[key], instance_seen[key] = nil, nil
        end
      end
    end
    local slot = instance_slots[value]
    if slot == nil then
      slot = next_instance_slot
      next_instance_slot = next_instance_slot + 1
      instance_slots[value] = slot
    end
    instance_seen[value] = frame
    return slot
  end
  -- Keep the render callback below LuaJIT 5.1's 60-upvalue limit.
  rawset(_G, "__hd2ir_unit_instance_slot", instance_slot)
  local function discover_armour_markers(world)
    local discovered = {}
    for mi = 1, #ARMOUR_MARKER_IDS do
      local marker = ARMOUR_MARKER_IDS[mi]
      local fresh_key = try(function() return Id64.from_hex(marker.hash) end)
      local units = try(function() return W.units_by_resource(world, fresh_key) end)
      if type(units) == "table" and #units > 0 then
        marker_lookup_hits = marker_lookup_hits + #units
        for ui = 1, #units do
          local dn = debug_name(units[ui])
          if string.find(dn, marker.hash, 1, true) and
             not marker_probe_logged[marker.hash] then
            marker_probe_logged[marker.hash] = true
            local rn = try(function() return U.resource_name(units[ui]) end)
            local node_count = try(function()
              return U.num_scene_graph_items(units[ui])
            end) or -1
            local root_node = node_count > 1 and 1 or 0
            local _, p = world_pose(units[ui], root_node)
            log(string.format(
              "armour marker family=%s hash=%s resource=%s debug=%s " ..
              "nodes=%d root=%d position=(%.4f,%.4f,%.4f)",
              marker.family, marker.hash, tostring(rn), dn, node_count,
              root_node, p and p[1] or 0.0, p and p[2] or 0.0,
              p and p[3] or 0.0))
          end
          local node_count = try(function()
            return U.num_scene_graph_items(units[ui])
          end) or -1
          if node_count > 1 then
            local q, p = world_pose(units[ui], 1)
            if q ~= nil and p ~= nil then
              discovered[#discovered + 1] = {
                unit = units[ui], family = marker.family,
                hash = marker.hash, q = q, p = p,
              }
            end
          end
        end
      else
        marker_lookup_misses = marker_lookup_misses + 1
      end
    end
    return discovered
  end

  local function assign_armour_markers(markers, avatars, world)
    local world_key = tostring(world)
    local state = carrier_world_safe[world]
    if type(state) ~= "table" then
      state = {
        markers = setmetatable({}, {__mode = "k"}),
        carriers = setmetatable({}, {__mode = "k"}),
        avatar_families = setmetatable({}, {__mode = "k"}),
      }
      carrier_world_safe[world] = state
    end
    state.markers = type(state.markers) == "table" and state.markers or
      setmetatable({}, {__mode = "k"})
    state.avatar_families = type(state.avatar_families) == "table" and
      state.avatar_families or setmetatable({}, {__mode = "k"})
    local avatar_by_key, seen_markers = {}, {}
    for ai = 1, #avatars do
      avatar_by_key[avatars[ai].unit] = avatars[ai]
    end
    for ai = 1, #avatars do
      avatars[ai].armour_marker_counts = {ex03 = 0, ex16 = 0}
      avatars[ai].armour_family = nil
    end
    for mi = 1, #markers do
      local marker = markers[mi]
      local marker_key = marker.unit
      seen_markers[marker_key] = true
      local candidates = {}
      for ai = 1, #avatars do
        local ap = avatars[ai].p
        local dx = marker.p[1] - ap[1]
        local dy = marker.p[2] - ap[2]
        local dz = marker.p[3] - ap[3]
        candidates[#candidates + 1] = {
          avatar = avatars[ai], d2 = dx * dx + dy * dy + dz * dz,
        }
      end
      table.sort(candidates, function(a, b) return a.d2 < b.d2 end)
      local chosen = nil
      local leased_avatar = avatar_by_key[state.markers[marker_key]]
      if leased_avatar ~= nil then
        local dx = marker.p[1] - leased_avatar.p[1]
        local dy = marker.p[2] - leased_avatar.p[2]
        local dz = marker.p[3] - leased_avatar.p[3]
        local leased_d2 = dx * dx + dy * dy + dz * dz
        if leased_d2 < 9.0 then
          chosen = {avatar = leased_avatar, d2 = leased_d2}
        end
      end
      if chosen == nil then chosen = candidates[1] end
      if chosen ~= nil and chosen.d2 < 9.0 then
        local best_distance = math.sqrt(chosen.d2)
        local tied_camera, tied_camera_count = nil, 0
        for ci = 1, #candidates do
          local distance = math.sqrt(candidates[ci].d2)
          if distance - best_distance <= MARKER_ASSOCIATION_MARGIN and
             candidates[ci].avatar.camera_nearest then
            tied_camera = candidates[ci]
            tied_camera_count = tied_camera_count + 1
          end
        end
        local second = candidates[2]
        local has_lease = leased_avatar ~= nil and
                          chosen.avatar == leased_avatar
        if has_lease and candidates[1] ~= nil and
           candidates[1].avatar ~= leased_avatar then
          local log_key = "marker_lease_retained|" .. world_key
          if not carrier_log_once[log_key] then
            carrier_log_once[log_key] = true
            log(string.format(
              "marker lease retained across proximity world=%s family=%s",
              world_key, marker.family))
          end
        end
        if not has_lease and second ~= nil and
           math.sqrt(second.d2) - best_distance <=
             MARKER_ASSOCIATION_MARGIN then
          -- Presentation worlds keep several Avatar instances at precisely
          -- the same transform. Select the unique camera-nearest one if the
          -- camera proves it; otherwise remain fail-closed.
          chosen = tied_camera_count == 1 and tied_camera or nil
        end
      else
        chosen = nil
      end
      if chosen ~= nil then
        state.markers[marker_key] = chosen.avatar.unit
        local counts = chosen.avatar.armour_marker_counts
        counts[marker.family] = (counts[marker.family] or 0) + 1
        marker_assignments = marker_assignments + 1
      end
    end
    for marker_key in pairs(state.markers) do
      if not seen_markers[marker_key] then state.markers[marker_key] = nil end
    end
    for ai = 1, #avatars do
      local avatar = avatars[ai]
      avatar.instance_slot = instance_slot(avatar.unit)
      local ex03 = avatar.armour_marker_counts.ex03 or 0
      local ex16 = avatar.armour_marker_counts.ex16 or 0
      if ex16 > 0 and ex03 == 0 then
        avatar.armour_family = "ex16"
        state.avatar_families[avatar.unit] = "ex16"
      elseif ex03 > 0 and ex16 == 0 then
        avatar.armour_family = "ex03"
        state.avatar_families[avatar.unit] = "ex03"
      elseif ex03 > 0 or ex16 > 0 then
        avatar.armour_family = "conflict"
        marker_conflicts = marker_conflicts + 1
      else
        -- Game cleanup may remove armour plate markers before removing a
        -- corpse Avatar.  Keep the last proven family on that exact instance;
        -- a live armour switch overwrites it as soon as the new markers exist.
        avatar.armour_family = state.avatar_families[avatar.unit]
      end
      if avatar.armour_family ~= nil then
        local avatar_slot = avatar.instance_slot
        local key = string.format("%d|%s|%d|%d|%d", avatar_slot,
          avatar.armour_family, #avatars, ex03, ex16)
        if not marker_assignment_logged[key] then
          marker_assignment_logged[key] = true
          log(string.format(
            "armour identity slot=%d family=%s avatars=%d ex03_markers=%d " ..
            "ex16_markers=%d camera_nearest=%s position=(%.4f,%.4f,%.4f)",
            avatar_slot, avatar.armour_family, #avatars, ex03, ex16,
            tostring(avatar.camera_nearest), avatar.p[1], avatar.p[2],
            avatar.p[3]))
        end
      end
    end
  end
  local function carrier_target(avatar)
    return {
      avatar.p[1] + CARRIER_OFFSET[1],
      avatar.p[2] + CARRIER_OFFSET[2],
      avatar.p[3] + CARRIER_OFFSET[3],
    }
  end

  local function avatars_overlap(avatars)
    for ai = 1, #avatars do
      for bi = ai + 1, #avatars do
        local a, b = avatars[ai].p, avatars[bi].p
        local dx, dy, dz = a[1] - b[1], a[2] - b[2], a[3] - b[3]
        if dx * dx + dy * dy + dz * dz <= PRESENTATION_OVERLAP2 then
          return true
        end
      end
    end
    return false
  end

  local function fresh_carriers(world)
    local key = try(function()
      return Id64.from_hex(CARRIER_RESOURCE_HASH)
    end)
    if key == nil then return {} end
    local units = try(function() return W.units_by_resource(world, key) end)
    return type(units) == "table" and units or {}
  end

  local function set_carrier_lease(carrier, avatar, visible)
    local target = carrier_target(avatar)
    local position = engine_vector(target)
    local rotation = engine_quaternion(avatar.root_q)
    if position == nil or rotation == nil then return false end
    return call(function()
      U.set_local_rotation(carrier, CARRIER_ROOT_NODE, rotation)
      U.set_local_position(carrier, CARRIER_ROOT_NODE, position)
      -- A skinned carrier is visible only after its bone Profile completes a
      -- full write and passes the post-write residual gate in this same frame.
      U.set_unit_visibility(carrier, false)
    end)
  end

  local function update_carrier_units(world, avatars, suppress_all_carriers)
    local world_key = tostring(world)
    local state = carrier_world_safe[world]
    if type(state) ~= "table" then
      state = {
        markers = setmetatable({}, {__mode = "k"}),
        carriers = setmetatable({}, {__mode = "k"}),
        avatar_families = setmetatable({}, {__mode = "k"}),
      }
      carrier_world_safe[world] = state
    end
    state.carriers = type(state.carriers) == "table" and state.carriers or
      setmetatable({}, {__mode = "k"})
    if CARRIER_NATIVE_CHEST_SLOT_PROBE then return end
    local carriers = fresh_carriers(world)
    if suppress_all_carriers then
      -- Unit.set_unit_visibility(false) is not authoritative during ADS: the
      -- native render path restores the unparented Unit after this Lua hook.
      -- Keep the visibility write as a first gate, but also park every current
      -- carrier far outside this World's camera/Avatar region. The carrier is
      -- unlinked, so no gameplay or network transform follows it. When ADS
      -- ends, the normal lease path below places it back before committing its
      -- bones and visibility.
      local base = avatars[1] and avatars[1].p or {0.0, 0.0, 0.0}
      local parked_position = engine_vector({
        base[1] + 16384.0, base[2] + 16384.0, base[3] + 16384.0,
      })
      for ci = 1, #carriers do
        if parked_position == nil or not call(function()
          U.set_local_position(carriers[ci], CARRIER_ROOT_NODE,
                               parked_position)
          U.set_unit_visibility(carriers[ci], false)
        end) then
          carrier_errors = carrier_errors + 1
        end
      end
      if #carriers > 0 and not carrier_log_once["first_person_parked"] then
        carrier_log_once["first_person_parked"] = true
        log(string.format(
          "parked %d third-person carrier(s) outside local first-person Worlds",
          #carriers))
      end
      return
    end
    local avatar_by_key, seen_carriers = {}, {}
    for ai = 1, #avatars do
      avatar_by_key[avatars[ai].unit] = avatars[ai]
    end

    local assigned = {}
    for ci = 1, #carriers do
      local carrier = carriers[ci]
      local carrier_key = carrier
      seen_carriers[carrier_key] = true
      local _, cp = world_pose(carrier, CARRIER_ROOT_NODE)
      local candidates = {}
      if cp ~= nil then
        for ai = 1, #avatars do
          local target = carrier_target(avatars[ai])
          local dx, dy, dz = cp[1] - target[1], cp[2] - target[2],
                             cp[3] - target[3]
          candidates[#candidates + 1] = {
            index = ai, d2 = dx * dx + dy * dy + dz * dz,
          }
        end
        table.sort(candidates, function(a, b) return a.d2 < b.d2 end)
      end
      local chosen, leased_avatar = nil,
        avatar_by_key[state.carriers[carrier_key]]
      if leased_avatar ~= nil and leased_avatar.armour_family == "ex16" then
        for ai = 1, #avatars do
          if avatars[ai] == leased_avatar then
            chosen = {index = ai, d2 = 0.0, stable = true}
            break
          end
        end
      end
      if chosen ~= nil and chosen.stable and candidates[1] ~= nil and
         avatars[candidates[1].index] ~= leased_avatar then
        local log_key = "carrier_lease_retained|" .. world_key
        if not carrier_log_once[log_key] then
          carrier_log_once[log_key] = true
          log(string.format(
            "carrier lease retained across proximity world=%s avatars=%d",
            world_key, #avatars))
        end
      end
      if chosen == nil then chosen = candidates[1] end
      if chosen ~= nil and chosen.d2 <= CARRIER_MATCH_LIMIT2 and
         (chosen.stable or candidates[2] == nil or
          math.sqrt(candidates[2].d2) - math.sqrt(chosen.d2) >
            CARRIER_MATCH_MARGIN) and assigned[chosen.index] == nil then
        local avatar = avatars[chosen.index]
        local visible = avatar.armour_family == "ex16"
        if set_carrier_lease(carrier, avatar, visible) then
          assigned[chosen.index] = true
          if visible then
            state.carriers[carrier_key] = avatar.unit
            avatar.carrier_units = avatar.carrier_units or {}
            avatar.carrier_units[carrier_key] = true
          else
            state.carriers[carrier_key] = nil
          end
          if not visible then carrier_hidden = carrier_hidden + 1 end
        else
          carrier_errors = carrier_errors + 1
        end
      else
        state.carriers[carrier_key] = nil
        -- An unowned or ambiguous carrier must not leak into the scene. Do not
        -- destroy it here: native World teardown owns its lifetime.
        if not call(function() U.set_unit_visibility(carrier, false) end) then
          carrier_errors = carrier_errors + 1
        end
      end
    end

    for ai = 1, #avatars do
      local avatar = avatars[ai]
      if avatar.armour_family == "ex16" and not assigned[ai] then
        local target = carrier_target(avatar)
        local position = engine_vector(target)
        local rotation = engine_quaternion(avatar.root_q)
        local carrier = nil
        if position ~= nil and rotation ~= nil then
          carrier = try(function()
            return W.spawn_unit(world, CARRIER_RESOURCE, position, rotation)
          end)
        end
        local alive = carrier ~= nil and
          try(function() return U.alive(carrier) end) == true
        if alive and set_carrier_lease(carrier, avatar, true) then
          local carrier_key = carrier
          state.carriers[carrier_key] = avatar.unit
          seen_carriers[carrier_key] = true
          avatar.carrier_units = avatar.carrier_units or {}
          avatar.carrier_units[carrier_key] = true
          carrier_spawned = carrier_spawned + 1
          local log_key = "safe_spawn|" .. world_key
          if not carrier_log_once[log_key] then
            carrier_log_once[log_key] = true
            log(string.format(
              "carrier safe lease spawned resource=%s world=%s " ..
              "avatar_slot=%d avatar=%s " ..
              "position=(%.4f,%.4f,%.4f)", CARRIER_RESOURCE, world_key,
              instance_slot(avatar.unit), tostring(avatar.unit),
              avatar.p[1], avatar.p[2], avatar.p[3]))
          end
        else
          carrier_errors = carrier_errors + 1
          if not carrier_log_once["safe_spawn_error"] then
            carrier_log_once["safe_spawn_error"] = true
            log("carrier safe lease spawn failed resource=" .. CARRIER_RESOURCE)
          end
        end
      end
    end
    for carrier_key in pairs(state.carriers) do
      if not seen_carriers[carrier_key] then
        state.carriers[carrier_key] = nil
      end
    end
  end
  local function update_armour_identities(world, avatars,
                                           suppress_all_carriers)
    assign_armour_markers(discover_armour_markers(world), avatars, world)
    update_carrier_units(world, avatars, suppress_all_carriers)
  end
  local function camera_position(world)
    if M4 == nil then return nil end
    local pose = try(function() return W.debug_camera_pose(world) end)
    if pose == nil then return nil end
    local translation = try(function() return M4.translation(pose) end)
    return translation and v3(translation) or nil
  end

  local function active_avatar_worlds()
    if rawget(_G,'__hd2ir_topology_barrier')then rawget(_G,'__hd2ir_topology_barrier')()end
    local worlds = try(function() return App.worlds() end)
    if type(worlds) ~= "table" then return nil end
    local active = {}
    local budget=rawget(_G,'__hd2ir_native_handoff')
    local avatars_by_world={}
    rawset(_G,'__hd2ir_presentation_budget_active',false)
    if budget and budget.presentation_begin then
      budget.presentation_begin()
      for i=1,#worlds do
        local avatars=try(function()return W.units_by_resource(worlds[i],AVATAR_RESOURCE)end)
        avatars=type(avatars)=="table" and avatars or {}
        avatars_by_world[i]=avatars
        if budget.skip_presentation(avatars) then
          rawset(_G,'__hd2ir_presentation_budget_active',true)
        end
      end
    end
    for i = 1, #worlds do
      local n = try(function() return W.num_units(worlds[i]) end) or -1
      local avatars = avatars_by_world[i] or try(function()
        return W.units_by_resource(worlds[i], AVATAR_RESOURCE)
      end)
      avatars=type(avatars)=="table" and avatars or {}
      local scene_sources={}
      if Id64~=nil then
        for _,reference in ipairs({{hash="5b390845a8e3fc29",kind="ship-display"},
                                    {hash="15678e360612b805",kind="democracy-officer"}}) do
          local key=try(function() return Id64.from_hex(reference.hash) end)
          local units=key and try(function() return W.units_by_resource(worlds[i],key) end)
          if type(units)=="table" and #units<=32 then
            for _,unit in ipairs(units) do
              if string.find(debug_name(unit),reference.hash,1,true) then
                scene_sources[#scene_sources+1]={unit=unit,hash=reference.hash,kind=reference.kind}
              end
            end
          end
        end
      end
      -- ADS can render clothing in a World with an FP graph but no TP Avatar.
      -- Enrolling the World only enables discovery, not ownership or writes.
      local fp_graphs=pose_capture.fp_graphs(worlds[i])
      if n > 0 and (#avatars > 0 or #scene_sources > 0 or
          (type(fp_graphs)=="table" and next(fp_graphs)~=nil)) then
        active[#active + 1] = {
          world = worlds[i], avatars = avatars, scene_sources=scene_sources, unit_count = n,
          fp_graph_absent=type(fp_graphs)=="table" and next(fp_graphs)==nil,
        }
      end
    end
    local gate=rawget(_G,'__hd2ir_native_handoff')
    if gate then
      gate.observe(active)
      for _,context in ipairs(active)do
        local to=1
        for _,unit in ipairs(context.avatars)do
          if not gate.early(unit)then context.avatars[to]=unit;to=to+1 end
        end
        for i=#context.avatars,to,-1 do context.avatars[i]=nil end
      end
    end
    return active
  end

  local function active_world_set_key(contexts)
    local keys = {}
    -- World userdata wrappers can be recreated while the native World stays
    -- alive. Their printable resource form plus world count is intentionally
    -- coarse but stable enough for lifecycle diagnostics; ownership itself is
    -- resolved separately within each current callback.
    for i = 1, #contexts do keys[i] = tostring(contexts[i].world) end
    table.sort(keys)
    return table.concat(keys, "|")
  end

  -- A Unit handle and IdString64 never cross a frame. A low-frequency full
  -- scan is retained as a fail-closed diagnostic fallback. The normal path
  -- reconstructs a temporary IdString64 from the known resource hash in every
  -- render callback, then asks World.units_by_resource() for fresh handles.
  local DISCOVERY_INTERVAL = 60
  -- Only throttle timestamps are stored here, never World/Unit handles.
  -- Weak userdata keys disappeared under GC and restarted full World scans
  -- during missions. A printable-world collision can only defer a diagnostic
  -- scan; the fresh per-resource lookup below still runs every callback.
  -- Only negative resource results are throttled. A live/previously indexed
  -- resource is queried every callback for FRESH handles, as are all fallback
  -- full enumerations. No cached handle becomes evidence of current presence.
  -- Poll empty resources at 4 Hz; full scans, small-World changes and changes
  -- in the freshly enumerated Avatar set invalidate the negative deadline.
  local discovery_negative_deadlines={}

  local last_discovery_by_world = {}
  -- Counts only, never engine handles. A proven incomplete resource index must
  -- use fresh full enumeration continuously until the index recovers/despawns.
  local discovery_counts_by_world = {}
  local discovery_scans, discovery_hits = 0, 0
  local resource_lookup_hits, resource_lookup_misses = 0, 0
  local resource_probe_logged = {}
  local resource_alias_logged = {}
  local presentation_linkage_logged = {}
  local function inspect_presentation_links(unit,dn,current_frame)
    if current_frame<600 then return end
    local resource
    for _,hash in ipairs({"15678e360612b805","5b390845a8e3fc29","82595b5d94c57343",
                          "bbc58977ee49a281","9443b6dc83b9e4bb"}) do
      if string.find(dn,hash,1,true) then resource=hash break end
    end
    if not resource or presentation_linkage_logged[resource] then return end
    local count=try(function() return U.num_scene_graph_items(unit) end)
    if type(count)~="number" or count~=count or count~=math.floor(count) or count<1 or count>256 then return end
    local rows,positioned={},false
    for _,name in ipairs(source_names) do
      local node=try(function() if U.has_node(unit,name) then return U.node(unit,name) end end)
      -- The runtime resolves these actual engine indices by name. Index zero
      -- is not accepted by this diagnostic on the verified one-based game.
      if type(node)=="number" and node==math.floor(node) and node>=1 and node<=count then
        local q,p=world_pose(unit,node)
        local lq,lp=local_pose(unit,node);lq,lp=lq and q4(lq),lp and v3(lp)
        local parent=try(function() return U.scene_graph_parent(unit,node) end)
        if q and p and lq and lp then
          if math.abs(p[1])+math.abs(p[2])+math.abs(p[3])>1 then positioned=true end
          rows[#rows+1]=string.format("%s,%d,%s:%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f/%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f",
            name,node,tostring(parent),p[1],p[2],p[3],q[1],q[2],q[3],q[4],lp[1],lp[2],lp[3],lq[1],lq[2],lq[3],lq[4])
        end
      end
    end
    if positioned then
      presentation_linkage_logged[resource]=true
      log("presentation linkage probe resource="..resource.." nodes="..count.." poses="..table.concat(rows,";"))
    end
  end
  -- Bounded read-only inventory for identifying the actual ship display source.
  -- Do not keep Unit/World userdata and never use this log as ownership proof.
  local presentation_inventory_worlds, presentation_inventory_world_count = {}, 0
  local function inspect_presentation_resource(world, unit, dn)
    local world_key=tostring(world)
    local state=presentation_inventory_worlds[world_key]
    if not state then
      if presentation_inventory_world_count>=4 then return end
      state={seen={},emitted=0};presentation_inventory_worlds[world_key]=state
      presentation_inventory_world_count=presentation_inventory_world_count+1
    end
    if state.emitted>=512 then return end
    local count=try(function() return U.num_scene_graph_items(unit) end)
    if type(count)~="number" or count~=count or count~=math.floor(count) or count<14 or count>256 then return end
    local root=try(function()
      if U.has_node(unit,"StingrayEntityRoot") then return U.node(unit,"StingrayEntityRoot") end
    end)
    if type(root)~="number" or root~=root or root~=math.floor(root) or root<0 or root>count then return end
    local q,p=world_pose(unit,root)
    if not q or not p then return end
    local key=string.format("%s|%.2f,%.2f,%.2f",dn,p[1],p[2],p[3])
    if state.seen[key] then return end
    state.seen[key]=true;state.emitted=state.emitted+1
    local spine=try(function() return U.has_node(unit,"spine1") end)==true
    log(string.format("presentation resource inventory world=%s resource=%s nodes=%d root=%.4f,%.4f,%.4f spine1=%s",
      world_key,dn,count,p[1],p[2],p[3],tostring(spine)))
  end
  local function discover_armour_units(world, current_frame, unit_count, avatar_signature, gameplay_world)
    local meter=rawget(_G,'__hd2ir_scan_meter');if meter then meter('resource_begin')end
    local world_key = tostring(world)
    local last = last_discovery_by_world[world_key] or -1000000
    local previous = discovery_counts_by_world[world_key] or {}
    local now=os.clock()
    local negative=discovery_negative_deadlines[world_key]
    local actor_changed=not negative or negative.signature~=avatar_signature
    if actor_changed then
      negative={signature=avatar_signature,until_time={}};discovery_negative_deadlines[world_key]=negative
    end
    local valid_count=type(unit_count)=="number" and unit_count==unit_count and
      unit_count>=0 and unit_count<=10000000 and unit_count==math.floor(unit_count)
    -- Small presentation Worlds need immediate discovery when new clothing
    -- appears. Large mission Worlds retain their existing scan budget.
    local population_changed=not gameplay_world and valid_count and unit_count<=512 and unit_count~=previous.__unit_count
    local need_scan = current_frame - last >= DISCOVERY_INTERVAL
    -- A positively classified gameplay World is not a small preview merely
    -- because its population falls below 512. Enemy/effect count changes do
    -- not trigger armor enumeration. Stable indexed armor is still fresh on
    -- every callback; a two-second audit catches silent index omissions.
    -- Missing/partial previously observed armor continues to force an
    -- immediate fresh fallback below, with no remembered engine handles.
    if gameplay_world then need_scan=actor_changed or now>=(negative.next_full_scan or 0)end
    if population_changed then need_scan=true end
    -- Candidate-only generation trial: replacing objects can leave both the
    -- World population and resource-index counts unchanged. Re-enumerate small
    -- active Worlds with fresh handles; ownership/pose proof stays downstream.
    -- Normal ABI and large mission Worlds retain the original scan budget.
    -- Live acceptance failed: keep this extra scan opt-in, never on by default.
    local generation_scan=rawget(_G,"__hd2ir_preview_generation_scan_enabled")==true and
      C and C.shared_body_profile and valid_count and
      unit_count>0 and unit_count<=512
    if generation_scan then need_scan=true end
    local discovered, seen_units, fast_counts = {}, {}, {}
    for pi = 1, #profiles do
      local profile = profiles[pi]
      local due=need_scan or population_changed or not avatar_signature or
        (previous[profile.hash] or 0)>0 or now>=(negative.until_time[profile.hash] or 0)
      local units={}
      if due then
        if meter then meter('resource_queries')end
        local fresh_key=try(function()return Id64.from_hex(profile.hash)end)
        units=try(function()return W.units_by_resource(world,fresh_key)end)
        -- Query failures are retried immediately; only a proven empty table
        -- earns a deadline. Returned foreign aliases also remain uncached.
        negative.until_time[profile.hash]=type(units)=='table' and #units==0 and now+.25 or nil
      end
      local count = 0
      if type(units) == "table" then
        for ui = 1, #units do
          local unit = units[ui]
          if not (rawget(_G,'__hd2ir_native_handoff') and rawget(_G,'__hd2ir_native_handoff').early(unit)) then
          local dn = debug_name(unit)
          if string.find(dn, profile.hash, 1, true) then
            if not seen_units[unit] then
              seen_units[unit] = true
              count = count + 1
              discovered[#discovered + 1] = {unit=unit, profile=profile}
            end
          elseif not resource_alias_logged[profile.hash] then
            resource_alias_logged[profile.hash] = true
            log("profile alias-mismatch query="..profile.hash.." debug="..dn)
          end
        end
      end
      end -- native exclusion: indexed Unit loop
      fast_counts[profile.hash] = count
      resource_lookup_hits = resource_lookup_hits + count
      if count == 0 then resource_lookup_misses = resource_lookup_misses + 1 end
      -- A partial index (one of two identical armour instances) is incomplete
      -- too. Never substitute a previous handle or borrow a nearby Avatar.
      if count < (previous[profile.hash] or 0) then need_scan = true end
    end
    if need_scan then
      discovery_scans = discovery_scans + 1
      local all = try(function() return W.units(world) end)
      if type(all) == "table" and (not generation_scan or #all<=512) then
        if meter then meter('full_scans');meter('world_units_read',#all)end
        -- Resource hashes are fixed 16-digit lowercase hex strings. Preserve
        -- the exact old substring/first-profile semantics, without trying
        -- every armor profile against every enemy/effect name.
        local hashes,hex_only={},true
        for pi,profile in ipairs(profiles)do
          local hash=profile.hash
          if type(hash)~='string' or #hash~=16 or hash:find('[^0-9a-f]') then hex_only=false;break end
          if not hashes[hash] then hashes[hash]={profile=profile,rank=pi}end
        end
        local function match_name(dn)
          if hex_only and #dn==16 then local row=hashes[dn];return row and row.profile or false end
          if hex_only and #dn<=512 then
            local best
            for run in dn:gmatch('[0-9a-f]+')do
              for start=1,#run-15 do
                local row=hashes[run:sub(start,start+15)]
                if row and (not best or row.rank<best.rank) then best=row end
              end
            end
            return best and best.profile or false
          end
          -- Malformed/unusual names or nonstandard fixture catalogs keep the
          -- original exact matcher. This optimization never authorizes writes.
          for _,profile in ipairs(profiles)do
            if string.find(dn,profile.hash,1,true)then return profile end
          end
          return false
        end
        local names,count={},0
        for _,unit in ipairs(all)do
          if not (rawget(_G,'__hd2ir_native_handoff') and rawget(_G,'__hd2ir_native_handoff').early(unit)) then
          local dn=debug_name(unit)
          local matched=names[dn]
          if matched==nil then
            matched=match_name(dn)
            if count<256 then names[dn]=matched;count=count+1 end
          end
          if matched and not seen_units[unit] then
            seen_units[unit]=true
            discovered[#discovered+1]={unit=unit,profile=matched}
            discovery_hits=discovery_hits+1
          end
        end

        end -- native exclusion: fallback Unit loop

        -- A successful fresh enumeration can prove disappearance and end
        -- the fallback. An unavailable enumeration cannot prove either.
        local counts = {}
        for i = 1, #discovered do
          local hash = discovered[i].profile.hash
          counts[hash] = (counts[hash] or 0) + 1
        end
        if valid_count then counts.__unit_count=unit_count end
        if population_changed and C and C.shared_body_profile then
          for hash,count in pairs(counts) do
            if hash~="__unit_count" and count>(fast_counts[hash] or 0) and
               not resource_probe_logged["population|"..hash] then
              resource_probe_logged["population|"..hash]=true
              log(string.format("preview-write discovery unit=%s frame=%d indexed=%d enumerated=%d population=%d",
                hash,current_frame,fast_counts[hash] or 0,count,unit_count))
            end
          end
        end
        discovery_counts_by_world[world_key] = counts
        if gameplay_world then negative.next_full_scan=now+2.0 end
      end
      last_discovery_by_world[world_key] = current_frame
    else
      fast_counts.__unit_count=previous.__unit_count
      discovery_counts_by_world[world_key] = fast_counts
    end
    for key, checked in pairs(last_discovery_by_world) do
      if current_frame - checked > 600 then
        last_discovery_by_world[key], discovery_counts_by_world[key] = nil, nil
        discovery_negative_deadlines[key]=nil
      end
    end
    if meter then meter('resource_end')end
    return discovered
  end

  -- The log file in this exact APPDATA directory is already proven writable
  -- in game.  Keep the control file beside it instead of in a new subfolder.
  local mode_path = (os.getenv("APPDATA") or os.getenv("TEMP") or ".") ..
                    "/hd2_independent_rig_mode.txt"
  local drive_mode, last_mode_check = "retarget_test", -1000000
  local mode_probe_logged = false
  local profile_failures, profile_disabled = {}, {}
  -- Round-trip calibration is a profile-level check, but live retarget
  -- failures must be isolated to one concrete Avatar/armour binding. In a
  -- multiplayer scene, globally disabling a profile because one spawning or
  -- dying body was momentarily paired with the wrong component would also
  -- stop the same armour component on every healthy teammate.
  local binding_failures, binding_disabled, binding_retrying = {}, {}, {}
  local binding_safe_frames = {}
  local binding_quarantines, binding_recoveries = 0, 0
  -- V17 controlled first-person proof. These are the UF-84 left/right arm
  -- resources from the proxy rig, not a general hard-coded character table.
  -- The production exporter will encode the same baseline->custom Rest delta
  -- per target bone in the character Profile.
  local FP_ARM_PROFILES = {
    -- UF-84 V13 fixture: arms move toward the body by 60 mm at full Rest.
    ["b246fd9a5bfd6282"] = {side = "left", delta_x = 0.006,
                            family = "uf84"},
    ["9c02b2e67e2f389d"] = {side = "right", delta_x = -0.006,
                            family = "uf84"},
    -- Stock SR-24 fixture: the second armour family deliberately moves
    -- outward by 40 mm at full Rest, so its 10% first-person step is 4 mm.
    ["adb5d7b476e79121"] = {side = "left", delta_x = -0.004,
                            family = "sr24"},
    ["cb9aba6bfc485abc"] = {side = "left", delta_x = -0.004,
                            family = "sr24"},
    ["0e2809d29025f8fd"] = {side = "right", delta_x = 0.004,
                            family = "sr24"},
    ["2ce2b973e335f79c"] = {side = "right", delta_x = 0.004,
                            family = "sr24"},
    -- EX-16 anchor-gated fixture. EX-03 shares these body Unit IDs, so their
    -- bindings are admitted only when the same Avatar owns an EX-16 marker.
    ["d029b9f97b60a608"] = {side = "left", delta_x = -0.004,
                            family = "ex16_anchor"},
    ["e5b86a35c5d7cfcd"] = {side = "left", delta_x = -0.004,
                            family = "ex16_anchor"},
    ["152cefffe9127bdc"] = {side = "right", delta_x = 0.004,
                            family = "ex16_anchor"},
    ["aede84b9230fe530"] = {side = "right", delta_x = 0.004,
                            family = "ex16_anchor"},
  }
  -- A first-person sleeve is local-only. "Nearest camera Avatar" was not a
  -- sufficient ownership proof in multiplayer: on the ship and in Hellpods a
  -- teammate can be only 1.6 m from the local camera, and the two sleeve Units
  -- then oscillated between Avatars thousands of times. Real local ADS samples
  -- put the owning Avatar root at the debug-camera origin (0.000 m). Keep a
  -- deliberately small allowance for camera bob, and reject presentation
  -- Worlds containing coincident Avatar roots.
  local FP_LOCAL_CAMERA_MAX = 0.35
  local fp_gate_skips = 0
  local fp_gate_skip_logged = {}
  local PROFILE_REQUIRED_ARMOUR = {
    [CARRIER_RESOURCE_HASH] = "ex16",
    ["0bff00a00ecf5139"] = "ex16",
    ["152cefffe9127bdc"] = "ex16",
    ["2751057a607f074b"] = "ex16",
    ["aede84b9230fe530"] = "ex16",
    ["d029b9f97b60a608"] = "ex16",
    ["e5b86a35c5d7cfcd"] = "ex16",
  }
  -- V22 art-assembly proof. EX-03 and EX-16 share their ordinary body Unit
  -- resource IDs, so replacing that resource in an SDK patch changes both
  -- armours.  Stingray visibility, however, is a property of a live Unit
  -- instance.  Hide only the EX-16 hip instance after the read-only marker
  -- gate has attributed it to one Avatar, and explicitly restore the same
  -- live resource when it belongs to EX-03. Limiting this proof to the hip
  -- avoids touching either first-person arm proxy while still giving an
  -- unmistakable visual result. Production art uses the same lease for every
  -- shared vanilla body component and leaves the custom marker Unit visible.
  local VISIBILITY_PROBE_ENABLED = true
  local VISIBILITY_PROBE_PROFILES = {
    ["0bff00a00ecf5139"] = true, -- slim hip
    ["2751057a607f074b"] = true, -- stocky hip
  }
  local visibility_probe_logged = {}
  local visibility_hides, visibility_restores, visibility_errors = 0, 0, 0
  local function apply_visibility_probe(world, unit, profile, avatar)
    if not VISIBILITY_PROBE_ENABLED or
       not VISIBILITY_PROBE_PROFILES[profile.hash] then return end
    local family = avatar.armour_family
    if family ~= "ex16" and family ~= "ex03" then return end
    local visible = family == "ex03"
    if not call(function() U.set_unit_visibility(unit, visible) end) then
      visibility_errors = visibility_errors + 1
      local key = "error|" .. profile.hash
      if not visibility_probe_logged[key] then
        visibility_probe_logged[key] = true
        log(string.format(
          "visibility lease failed profile=%s family=%s world=%s",
          profile.hash, family, tostring(world)))
      end
      return
    end
    if visible then
      visibility_restores = visibility_restores + 1
    else
      visibility_hides = visibility_hides + 1
    end
    local key = family .. "|" .. profile.hash
    if not visibility_probe_logged[key] then
      visibility_probe_logged[key] = true
      log(string.format(
        "visibility lease profile=%s family=%s visible=%s world=%s",
        profile.hash, family, tostring(visible), tostring(world)))
    end
  end
  local fp_active, fp_pose_memory, fp_safe_frames = {}, {}, {}
  local fp_entries, fp_exits, fp_writes = 0, 0, 0
  local calibration_attempted = {}
  local roundtrip_units, roundtrip_nodes, roundtrip_rejected = 0, 0, 0
  local max_roundtrip_rotation, max_roundtrip_position = 0.0, 0.0
  -- nil means every equipped profile may participate. Per-profile coverage,
  -- delta and residual gates still fail independently.
  local RETARGET_TEST_PROFILE = nil
  local RETARGET_TEST_BLEND = 0.10
  local RETARGET_RAW_ROTATION_GATE = 45.0
  local RETARGET_RAW_POSITION_GATE = 0.25
  local RETARGET_STEP_ROTATION_GATE = 5.0
  local RETARGET_STEP_POSITION_GATE = 0.025
  -- First-person transitions can put the local third-person arm resources in
  -- a temporary pose far from the ordinary third-person Rest mapping. While a
  -- binding is quarantined, keep evaluating the full read-only gate every
  -- frame and resume only after three consecutive coherent frames. This makes
  -- third-person recovery effectively immediate without weakening any gate.
  local RETARGET_RECOVERY_STABLE_FRAMES = 3
  -- A first-person animation can cross the ordinary third-person raw gate for
  -- a few frames during recoil or reload. Releasing the proxy after only three
  -- such frames makes the state chatter even though the camera never left
  -- first person. Hold the already-proven rigid proxy for twelve coherent
  -- ordinary frames (~0.2 s at 60 Hz); a real return to third person is still
  -- substantially faster than the old one-second quarantine path.
  local FP_PROXY_RELEASE_STABLE_FRAMES = 12
  local retarget_attempts, retarget_units = 0, 0
  local retarget_nodes, retarget_rejected = 0, 0
  local max_retarget_raw_rotation, max_retarget_raw_position = 0.0, 0.0
  local max_retarget_step_rotation, max_retarget_step_position = 0.0, 0.0
  local max_retarget_residual_rotation, max_retarget_residual_position = 0.0, 0.0
  local retarget_mapping_logged = {}
  -- Lifecycle telemetry keeps only string snapshots of frame-local handles.
  -- It never dereferences an old handle or logs a player identity. The snapshots let a test prove that a
  -- death/respawn or world transition really discarded old bindings.
  local lifecycle_world, lifecycle_generation = nil, 0
  local lifecycle_binding_keys, lifecycle_signature = {}, nil
  local lifecycle_gap_frames, lifecycle_transitions = 0, 0
  local lifecycle_ambiguous_total = 0
  local ambiguity_probe_logged = {}
  local ambiguity_probe_count = 0
  local BINDING_AMBIGUITY_MARGIN = 0.20

  local function lifecycle_key(binding)
    return binding.profile.hash .. "|" .. instance_slot(binding.world) .. "|" ..
           instance_slot(binding.unit) .. "|" ..
           instance_slot(binding.avatar.unit)
  end

  -- Failure ownership follows the armour Unit, not the currently selected
  -- Avatar candidate. First-person transitions may alternate overlapping
  -- Avatar candidates while the physical sleeve Unit stays the same. Keying
  -- by Avatar made every rejected frame look like a new failure and produced
  -- log storms instead of one stable quarantine.
  local function retarget_failure_key(binding)
    return binding.profile.hash .. "|" .. instance_slot(binding.world) .. "|" ..
           instance_slot(binding.unit)
  end

  local function first_person_arm_profile(binding)
    -- The old millimetre proxy belongs to fixed test rigs, not a new author
    -- character that happens to replace the same SR-24/UF-84 Unit resource.
    if binding.profile.authored then return nil end
    local profile = FP_ARM_PROFILES[binding.profile.hash]
    if profile == nil or not binding.avatar.camera_nearest or
       binding.avatar.world_overlapping or
       (binding.avatar.camera_distance or math.huge) >
         FP_LOCAL_CAMERA_MAX then return nil end
    return profile
  end

  local function first_person_binding_allowed(profile, avatar, world, unit,
                                               suppress_all_carriers)
    if profile.hash == CARRIER_RESOURCE_HASH then
      -- A full third-person character carrier must never enter the local
      -- first-person frustum. The game renders ADS through two simultaneous
      -- Worlds: V23.6 correctly rejected the camera-zero Avatar's carrier, but
      -- the mirrored third-person World immediately made its own copy visible.
      -- The render pre-pass therefore raises one client-local frame flag when
      -- ANY current World proves first person. set_carrier_lease hid every
      -- fresh carrier earlier in this callback; rejecting all carrier bindings
      -- for this frame leaves both World copies hidden. No network state or
      -- ownership lease is changed, so third person resumes next render frame.
      if suppress_all_carriers then
        if not carrier_log_once["global_first_person_hidden"] then
          carrier_log_once["global_first_person_hidden"] = true
          log(string.format(
            "all third-person carriers hidden for local first-person frame " ..
            "candidate_distance=%.3f", avatar.camera_distance or math.huge))
        end
        return false
      end
      local state = carrier_world_safe[world]
      local owner = type(state) == "table" and
                    type(state.carriers) == "table" and
                    state.carriers[unit] or nil
      if owner ~= nil and owner == avatar.unit then return "stable" end
      return false
    end
    if profile.authored or FP_ARM_PROFILES[profile.hash] == nil then return true end
    local allowed = avatar.camera_nearest and not avatar.world_overlapping and
                    (avatar.camera_distance or math.huge) <=
                      FP_LOCAL_CAMERA_MAX
    if not allowed then
      fp_gate_skips = fp_gate_skips + 1
      local gate_key = profile.hash .. "|" .. instance_slot(world) .. "|" ..
                       tostring(avatar.world_overlapping)
      if not fp_gate_skip_logged[gate_key] then
        fp_gate_skip_logged[gate_key] = true
        log(string.format(
          "first-person binding skipped %s camera_nearest=%s " ..
          "camera_distance=%.3f overlapping_world=%s",
          profile.hash, tostring(avatar.camera_nearest),
          avatar.camera_distance or math.huge,
          tostring(avatar.world_overlapping)))
      end
    end
    return allowed
  end

  local function lifecycle_profile_signature(bindings)
    local counts, parts = {}, {}
    for i = 1, #bindings do
      local hash = bindings[i].profile.hash
      counts[hash] = (counts[hash] or 0) + 1
    end
    for i = 1, #profiles do
      local hash = profiles[i].hash
      local count = counts[hash] or 0
      if count > 0 then parts[#parts + 1] = hash .. "=" .. tostring(count) end
    end
    if #parts == 0 then return "none" end
    return table.concat(parts, ",")
  end

  local function update_lifecycle(world, world_count, avatars, bindings, ambiguous)
    if world ~= lifecycle_world then
      lifecycle_world = world
      lifecycle_generation = lifecycle_generation + 1
      lifecycle_binding_keys = {}
      lifecycle_signature = nil
      lifecycle_gap_frames = 0
      -- Failure latches belong to a world generation.  A load or mission
      -- transition gets a clean fail-closed trial instead of inheriting a
      -- stale disabled profile from the previous scene.
      profile_failures, profile_disabled = {}, {}
      binding_failures, binding_disabled, binding_retrying = {}, {}, {}
      binding_safe_frames = {}
      fp_active, fp_pose_memory, fp_safe_frames = {}, {}, {}
      calibration_attempted = {}
      log(string.format("lifecycle world generation=%d",
                        lifecycle_generation))
    end

    local current, current_failure, added, removed = {}, {}, 0, 0
    for i = 1, #bindings do
      current[lifecycle_key(bindings[i])] = true
      current_failure[retarget_failure_key(bindings[i])] = true
    end
    for key in pairs(current) do
      if not lifecycle_binding_keys[key] then added = added + 1 end
    end
    for key in pairs(lifecycle_binding_keys) do
      if not current[key] then removed = removed + 1 end
    end
    if added > 0 or removed > 0 then lifecycle_transitions = lifecycle_transitions + 1 end

    local profile_signature = lifecycle_profile_signature(bindings)
    local signature = string.format("%d|%d|%d|%d|%s",
      world_count, #avatars, #bindings, ambiguous, profile_signature)
    if signature ~= lifecycle_signature or added > 0 or removed > 0 or
       lifecycle_gap_frames > 0 then
      log(string.format(
        "lifecycle state generation=%d worlds=%d avatars=%d bindings=%d added=%d " ..
        "removed=%d ambiguous=%d profiles=%s recovered_gap_frames=%d",
        lifecycle_generation, world_count, #avatars, #bindings, added, removed,
        ambiguous, profile_signature, lifecycle_gap_frames))
      lifecycle_signature = signature
    end
    lifecycle_gap_frames = 0
    lifecycle_binding_keys = current

    -- A Unit handle is only meaningful in the current render callback. Keep
    -- failure state only while the same string-snapshot binding remains live;
    -- this prevents a long mission with many deaths from accumulating stale
    -- quarantines and lets a correctly rematched body start cleanly.
    for key in pairs(binding_failures) do
      if not current_failure[key] then binding_failures[key] = nil end
    end
    for key in pairs(binding_disabled) do
      if not current_failure[key] then binding_disabled[key] = nil end
    end
    for key in pairs(binding_retrying) do
      if not current_failure[key] then binding_retrying[key] = nil end
    end
    for key in pairs(binding_safe_frames) do
      if not current_failure[key] then binding_safe_frames[key] = nil end
    end
    for key in pairs(fp_active) do
      if not current_failure[key] then fp_active[key] = nil end
    end
    for key in pairs(fp_pose_memory) do
      if not current_failure[key] then fp_pose_memory[key] = nil end
    end
    for key in pairs(fp_safe_frames) do
      if not current_failure[key] then fp_safe_frames[key] = nil end
    end
  end

  local function update_lifecycle_gap()
    lifecycle_gap_frames = lifecycle_gap_frames + 1
    if lifecycle_gap_frames == 1 or lifecycle_gap_frames % 600 == 0 then
      log(string.format("lifecycle gap generation=%d no_avatar_frames=%d",
                        lifecycle_generation, lifecycle_gap_frames))
    end
  end

  local function refresh_drive_mode(current_frame)
    if current_frame - last_mode_check < 120 then return end
    last_mode_check = current_frame
    local selected = "retarget_test"
    local f = io.open(mode_path, "r")
    if f then
      local line = string.lower(tostring(f:read("*l") or ""))
      f:close()
      if line == "observe" or line == "roundtrip" or
         line == "retarget_test" then selected = line end
      if not mode_probe_logged then
        log("Lua Unit mode control read " .. mode_path .. " = " .. line)
        mode_probe_logged = true
      end
    elseif not mode_probe_logged then
      log("Lua Unit mode control missing; calibration default = retarget_test: " ..
          mode_path)
      mode_probe_logged = true
    end
    if selected ~= drive_mode then
      drive_mode = selected
      log("Lua Unit drive mode: " .. drive_mode)
    end
  end

  local function roundtrip_unit(world, binding)
    local profile = binding.profile
    if not profile.active or profile.observe_only or
       drive_mode ~= "roundtrip" or
       profile_disabled[profile.hash] or
       calibration_attempted[profile.hash] then
      return false
    end
    local unit, node_count = binding.unit, binding.node_count
    local poses = {}
    for i = 1, #profile.nodes do
      local node = profile.nodes[i]
      if node >= 0 and node < node_count then
        local before_q, before_p = world_pose(unit, node)
        before_q = before_q and qnormalize(before_q) or nil
        if before_q == nil or before_p == nil then
          roundtrip_rejected = roundtrip_rejected + 1
          return false
        end
        -- Unit.local_* already expresses the node relative to its actual
        -- scene-graph parent. Keep the engine userdata and write it back in
        -- this same callback; no quaternion reconstruction or hierarchy
        -- flattening occurs.
        local local_q, local_p = local_pose(unit, node)
        if local_q == nil or local_p == nil then
          roundtrip_rejected = roundtrip_rejected + 1
          return false
        end
        poses[#poses + 1] = {
          node = node, before_q = before_q, before_p = before_p,
          rotation = local_q, position = local_p,
        }
      end
    end
    if #poses == 0 then return false end

    -- Parent-relative calibration remains one-shot per equipped profile.
    -- Continuous writes are enabled only after every component reports a
    -- tight world-space residual.
    calibration_attempted[profile.hash] = true

    -- All engine temporaries are created and validated before the first write.
    -- They are consumed in this render callback and never stored across frames.
    for i = 1, #poses do
      local pose = poses[i]
      if not call(function()
        U.set_local_rotation(unit, pose.node, pose.rotation)
        U.set_local_position(unit, pose.node, pose.position)
      end) then
        profile_failures[profile.hash] = (profile_failures[profile.hash] or 0) + 1
        roundtrip_rejected = roundtrip_rejected + 1
        return false
      end
    end
    if not call(function() W.update_unit(world, unit) end) then
      profile_failures[profile.hash] = (profile_failures[profile.hash] or 0) + 1
      roundtrip_rejected = roundtrip_rejected + 1
      return false
    end

    local max_r, max_p = 0.0, 0.0
    for i = 1, #poses do
      local pose = poses[i]
      local after_q, after_p = world_pose(unit, pose.node)
      after_q = after_q and qnormalize(after_q) or nil
      if after_q == nil or after_p == nil then
        max_r, max_p = math.huge, math.huge
        break
      end
      max_r = math.max(max_r, qerror_degrees(pose.before_q, after_q))
      max_p = math.max(max_p, perror(pose.before_p, after_p))
    end
    max_roundtrip_rotation = math.max(max_roundtrip_rotation, max_r)
    max_roundtrip_position = math.max(max_roundtrip_position, max_p)
    roundtrip_units = roundtrip_units + 1
    roundtrip_nodes = roundtrip_nodes + #poses

    -- A correct identity round trip is much tighter than these gates.  Three
    -- bad frames disable only this Unit profile; other armour and the avatar
    -- remain untouched.
    if max_r > 0.5 or max_p > 0.002 then
      local failures = (profile_failures[profile.hash] or 0) + 1
      profile_failures[profile.hash] = failures
      if failures >= 3 then
        profile_disabled[profile.hash] = true
        log(string.format(
          "roundtrip disabled %s after residual %.4f deg / %.6f m",
          profile.hash, max_r, max_p))
      end
    else
      profile_failures[profile.hash] = 0
    end
    return true
  end

  local function reject_retarget(binding, reason)
    local profile = binding.profile
    local key = retarget_failure_key(binding)
    retarget_rejected = retarget_rejected + 1
    if binding_disabled[key] then
      binding_safe_frames[key] = 0
      return false
    end
    local failures = (binding_failures[key] or 0) + 1
    binding_failures[key] = failures
    if failures == 1 or failures == 3 then
      log(string.format("retarget binding rejected %s #%d: %s",
                        profile.hash, failures, tostring(reason)))
    end
    if failures >= 3 then
      binding_disabled[key] = true
      binding_safe_frames[key] = 0
      binding_quarantines = binding_quarantines + 1
      local view = binding.avatar.camera_nearest and "camera-nearest" or "remote"
      local camera_distance = binding.avatar.camera_distance or math.huge
      log(string.format(
        "retarget binding quarantined %s view=%s camera_distance=%.3f " ..
        "after repeated rejection; probing every frame",
        profile.hash, view, camera_distance))
    end
    return false
  end

  -- C++ returns one model-space target per weighted Unit node. Convert those
  -- targets through the actual scene graph instead of assuming that palette
  -- order and scene-graph parentage are the same. Non-target ancestors keep
  -- their current local transforms, so intermediate attachment nodes remain
  -- intact. Old experimental profiles retain their small blend; authored
  -- source-parent-space profiles require complete correction each frame.
  local function retarget_write_policy(profile)
    local carrier = profile.hash == CARRIER_RESOURCE_HASH
    local authored = false
    for _, flags in ipairs(profile.target_flags or {}) do
      if math.floor(flags / 1024) % 2 == 1 then authored = true break end
    end
    return (carrier or authored) and 1.0 or RETARGET_TEST_BLEND,
      carrier and 180.0 or RETARGET_RAW_ROTATION_GATE,
      carrier and 10.0 or RETARGET_RAW_POSITION_GATE,
      carrier and 180.0 or (authored and RETARGET_RAW_ROTATION_GATE or RETARGET_STEP_ROTATION_GATE),
      carrier and 10.0 or (authored and RETARGET_RAW_POSITION_GATE or RETARGET_STEP_POSITION_GATE)
  end

  -- Stable helpers keep per-binding state explicit and callback-local. No Unit
  -- handle, scene-graph sample or desired pose survives this driver invocation.
  function pose_capture.target_flag_set(value,flag)
    return math.floor((tonumber(value) or 0) / flag) % 2 == 1
  end
  function pose_capture.driver_read(context,node)
    local current=context.current
    local unit,node_count,node_offset=context.unit,context.node_count,context.node_offset
    local key = node + 1
    if current[key] ~= nil then return current[key] end
    local sample=node_pose_numbers(unit,node)
    if sample==nil then return nil end
    local local_q,local_p=sample.local_q,sample.local_p
    local world_q,world_p=sample.world_q,sample.world_p
    local_q = local_q and qnormalize(local_q) or nil
    world_q = world_q and qnormalize(world_q) or nil
    if local_q == nil or local_p == nil or world_q == nil or world_p == nil then
      return nil
    end
    local parent = sample.parent
    if type(parent) ~= "number" or parent < node_offset or parent >= node_count + node_offset or
       parent == node then
      parent = -1
    end
    current[key] = {
      local_q = local_q, local_p = local_p,
      world_q = world_q, world_p = world_p, parent = parent,
    }
    return current[key]
  end
  function pose_capture.driver_solve(context,node)
    local desired,visiting,explicit=context.desired,context.visiting,context.explicit
    local key = node + 1
    if desired[key] ~= nil then return desired[key] end
    if visiting[key] then return nil end
    visiting[key] = true
    local data = pose_capture.driver_read(context,node)
    if data == nil then visiting[key] = nil return nil end
    local result = explicit[key]
    if result == nil then
      if data.parent >= 0 then
        local parent_pose = pose_capture.driver_solve(context,data.parent)
        if parent_pose == nil then visiting[key] = nil return nil end
        local q, p = compose_pose(parent_pose.q, parent_pose.p,
                                  data.local_q, data.local_p)
        if q == nil or p == nil then visiting[key] = nil return nil end
        result = {q = q, p = p}
      else
        result = {q = data.world_q, p = data.world_p}
      end
    end
    visiting[key] = nil
    desired[key] = result
    return result
  end

  -- A stable hot loop, separate from the large orchestration/proxy function.
  -- Engine node resolution and every returned target/matrix remain checked.
  function pose_capture.build_target_map(unit,profile,source_names,root_q,root_p,
      target_nodes,target_model,returned,node_offset,node_count)
    local target_flag_set=pose_capture.target_flag_set
    local explicit, target_order, target_name_by_node = {}, {}, {}
    local target_source_by_node = {}
    local diagnostic_by_node = {}
    local missing_names, missing_count, duplicate_count = {}, 0, 0
    local writable_expected, anchor_count = 0, 0
    for i = 0, returned - 1 do
      local palette_node = tonumber(target_nodes[i])
      if palette_node == nil or palette_node ~= profile.nodes[i + 1] then
        return nil, "C++ target order mismatch"
      end
      local source_index = profile.target_sources[i + 1]
      local source_name = source_index and source_names[source_index + 1] or nil
      local flags = profile.target_flags[i + 1] or 0
      local anchor_only = target_flag_set(flags, 64)
      local direct_index = target_flag_set(flags, 32)
      local node
      if anchor_only then
        anchor_count = anchor_count + 1
      elseif direct_index then
        writable_expected = writable_expected + 1
        node = palette_node + node_offset
      else
        writable_expected = writable_expected + 1
        local has_node = source_name and try(function()
          return U.has_node(unit, source_name)
        end) or false
        node = has_node == true and try(function()
          return U.node(unit, source_name)
        end) or nil
      end
      if anchor_only then
        -- Native profile rows provide the source/rest frame used by C++, but
        -- are intentionally excluded from all Unit scene-graph writes.
      elseif type(node) ~= "number" or node < node_offset or node >= node_count + node_offset then
        missing_count = missing_count + 1
        if #missing_names < 8 then
          missing_names[#missing_names + 1] = direct_index and
            (tostring(source_name) .. "@node" .. tostring(palette_node)) or
            tostring(source_name)
        end
      elseif explicit[node + 1] ~= nil then
        duplicate_count = duplicate_count + 1
      else
        local model_q, model_p = matrix_pose(target_model, i * 12)
        if model_q == nil or model_p == nil then
          return nil, "non-rigid target matrix"
        end
        local world_q, world_p = compose_pose(root_q, root_p, model_q, model_p)
        if world_q == nil or world_p == nil then
          return nil, "target world composition failed"
        end
        explicit[node + 1] = {q = world_q, p = world_p}
        target_name_by_node[node + 1] = direct_index and
          (tostring(source_name) .. "@node" .. tostring(node)) or source_name
        if not target_flag_set(flags, 256) then
          target_source_by_node[node + 1] = source_name
        end
        diagnostic_by_node[node + 1] =
          target_flag_set(flags, 128)
        target_order[#target_order + 1] = node
      end
    end
    return explicit,target_order,target_name_by_node,target_source_by_node,
      diagnostic_by_node,missing_names,missing_count,duplicate_count,writable_expected,anchor_count
  end


  function pose_capture.scene_copy_pose(out,q,p)
    for j=0,3 do out[j]=q[j+1] end
    for j=0,2 do out[j+4]=p[j+1] end
  end
  function pose_capture.scene_layout(profile,source_names,target_nodes,count,node_offset,node_count)
    local cached=profile.scene_layouts and profile.scene_layouts[node_offset]
    local valid=cached and cached.count==count
    if valid then
      for i=1,count do
        local node=tonumber(target_nodes[i-1])
        if node~=profile.nodes[i] then return false,"C++ target order mismatch" end
        if node+node_offset>=node_count+node_offset or node<0 then return nil end
        if cached.palette[i]~=node or cached.flags[i]~=profile.target_flags[i] or
            cached.source_indices[i]~=profile.target_sources[i] or
            cached.source_names[i]~=source_names[(profile.target_sources[i] or -1)+1] then
          valid=false;break
        end
      end
      if valid then return cached end
    end
    local indices,order,names,sources={},{},{},{}
    local palette_nodes,flags_cache,source_indices,source_cache={},{},{},{}
    local flag=pose_capture.target_flag_set
    for i=1,count do
      local flags=profile.target_flags[i] or 0
      if not flag(flags,32) or flag(flags,64) or flag(flags,128) then return nil end
      local palette=tonumber(target_nodes[i-1])
      if palette~=profile.nodes[i] then return false,"C++ target order mismatch" end
      local node=palette+node_offset
      if node<node_offset or node>=node_count+node_offset or indices[node] then return nil end
      indices[node]=i-1;order[i]=node
      local source=profile.target_sources[i]
      local name=source and source_names[source+1] or nil
      names[node+1]=tostring(name).."@node"..tostring(node)
      if not flag(flags,256) then sources[node+1]=name end
      palette_nodes[i],flags_cache[i],source_indices[i],source_cache[i]=palette,profile.target_flags[i],source,name
    end
    cached={indices=indices,order=order,names=names,sources=sources,count=count,
      palette=palette_nodes,flags=flags_cache,source_indices=source_indices,source_names=source_cache}
    profile.scene_layouts=profile.scene_layouts or {};profile.scene_layouts[node_offset]=cached
    return cached
  end
  function pose_capture.prepare_native_scene(api,...)
    if not api then return nil end
    local workspace=pose_capture.scene_workspace
    if not workspace or workspace.busy then
      assert(ffi.sizeof('hd2ir_scene_input_v1')==176 and ffi.sizeof('hd2ir_scene_output_v1')==208)
      workspace={input=ffi.new('hd2ir_scene_input_v1[256]'),root=ffi.new('double[7]')}
      if not pose_capture.scene_workspace then pose_capture.scene_workspace=workspace end
    end
    -- Engine getters may invoke another consumer. A nested call must never
    -- overwrite the suspended call's partly packed input. Release on errors
    -- and unsupported-layout returns as well as successful preparation.
    workspace.busy=true
    local ok,result,err=pcall(pose_capture.prepare_native_scene_impl,workspace,api,...)
    workspace.busy=false
    if not ok then return false,"native scene preparation failed: "..tostring(result) end
    return result,err
  end
  function pose_capture.prepare_native_scene_impl(workspace,api,unit,profile,source_names,root_q,root_p,
      target_nodes,target_model,count,node_offset,node_count,sampled)
    -- Cache only checked profile/node metadata, never engine poses or handles.
    -- Unsupported graph layouts retain the fully checked general driver.
    if not api then return nil end
    local layout,layout_error=pose_capture.scene_layout(profile,source_names,target_nodes,count,node_offset,node_count)
    if not layout then return layout,layout_error end
    local indices,order,names,sources=layout.indices,layout.order,layout.names,layout.sources
    local context={unit=unit,node_count=node_count,node_offset=node_offset,
      current=sampled,desired={},visiting={},explicit={}}
    -- Scratch stores numbers only. There is no yield or retained Unit/pose;
    -- every used row is replaced before the one synchronous native call.
    for i=1,count do
      local data=pose_capture.driver_read(context,order[i])
      if not data then return false,"scene-graph target solve failed" end
      if data.parent>=0 and indices[data.parent]==nil then return nil end
      local row=workspace.input[i-1]
      row.parent=data.parent>=0 and indices[data.parent] or -1
      row.flags=0
      pose_capture.scene_copy_pose(row.local_pose,data.local_q,data.local_p)
      pose_capture.scene_copy_pose(row.world_pose,data.world_q,data.world_p)
      if data.parent<0 and data.native_parent_q and data.native_parent_p then
        row.flags=1;pose_capture.scene_copy_pose(row.parent_pose,data.native_parent_q,data.native_parent_p)
      end
    end
    pose_capture.scene_copy_pose(workspace.root,root_q,root_p)
    local output=ffi.new('hd2ir_scene_output_v1[?]',count)
    if tonumber(api(count,176,workspace.input,workspace.root,target_model,208,output))~=count then
      return false,"native scene pose validation failed"
    end
    -- Keep the owning cdata strongly reachable through the entire commit,
    -- rollback and readback, including forced GC and nested callback tests.
    local writes={numeric_owner=output}
    local raw_r,raw_p,step_r,step_p=0.,0.,0.,0.
    for i=1,count do
      local row=output[i-1];local q,p,e=row.local_q,row.local_p,row.errors
      context.explicit[order[i]+1]={q=row.world_q,p=row.world_p}
      raw_r=math.max(raw_r,e[0]);raw_p=math.max(raw_p,e[1])
      step_r=math.max(step_r,e[2]);step_p=math.max(step_p,e[3])
      writes[i]={node=order[i],q=q,p=p,unchanged=e[2]<=.0001 and e[3]<=.0000001}
    end
    return {context=context,order=order,names=names,sources=sources,writes=writes,
      raw_r=raw_r,raw_p=raw_p,step_r=step_r,step_p=step_p}
  end

  -- Same lifetime rule as the weapon restore_pending path: only owned numbers
  -- and stable identities cross callbacks. Fresh discovery + the current actor
  -- incarnation must authenticate a new handle before any deferred write.
  rawset(_G,'__hd2ir_scene_restore',(function()
    local M,pending={},{}
    local function copy(v,n)local out={};for i=1,n do out[i]=v[i] end;return out end
    local function same(q,p,row)
      return q and p and row and qerror_degrees(q,row.q)<.001 and perror(p,row.p)<.00001
    end
    local function token_key(token)
      if not token or token==0 then return end
      -- Reuse the exact-word format of the PhysBone event logger: the game's
      -- tostring(cdata) treats uint64s as engine objects. Never convert the
      -- complete opaque token to a Lua double or keep an engine-formatted key.
      local owned=ffi.new('uint64_t[1]',token)
      local words=ffi.cast('const unsigned *',owned)
      return string.format('%08x%08x',tonumber(words[1]),tonumber(words[0]))
    end
    local function identity(binding)
      local slot=rawget(_G,'__hd2ir_unit_instance_slot')
      local life=rawget(_G,'__hd2ir_shared_body_lifecycle')
      if not slot or not life or not binding or not binding.avatar or not binding.avatar.unit then return end
      local avatar=slot(binding.avatar.unit)
      local token=token_key(life.token(avatar))
      if not token then return end
      return {slot=slot(binding.unit),world=slot(binding.world),avatar=avatar,
        token=token,hash=binding.profile.hash,count=binding.node_count}
    end
    function M.save(context,writes,restore_all)
      local key=identity(context.binding)
      if not key then log('scene-restore FAILED: stable actor incarnation unavailable; restart required');return false end
      key.offset=context.node_offset;key.rows={};key.refresh=context.restore_refresh_pending==true
      for _,pose in ipairs(writes)do if restore_all or not pose.unchanged then
        local before=pose_capture.driver_read(context,pose.node)
        if before then
          local q,p=pose_numbers(context.unit,pose.node,false)
          key.rows[#key.rows+1]={node=pose.node,parent=before.parent,
            original={q=copy(before.local_q,4),p=copy(before.local_p,3)},
            expected=q and p and {q=copy(q,4),p=copy(p,3)} or nil}
        else key.incomplete=true end
      end end
      pending[key.slot]=key
      log('scene-restore pending unit='..key.hash..' slot='..key.slot..'; same-frame rollback incomplete')
      return true
    end
    function M.clear(binding)
      local key=identity(binding)
      if key then pending[key.slot]=nil end
    end
    local function absent(saved)
      -- An unresolved association is not a despawn. Re-query every current
      -- World by resource before retiring an unbound numeric record; never
      -- dereference a cached handle or guess from an empty bindings list.
      local worlds=App and try(function()return App.worlds()end)
      if type(worlds)~='table' then return false end
      local complete=true
      local slot=rawget(_G,'__hd2ir_unit_instance_slot')
      for _,world in ipairs(worlds)do
        local units=try(function()return W.units_by_resource(world,Id64.from_hex(saved.hash))end)
        if type(units)~='table' or #units>4096 then complete=false
        else for _,unit in ipairs(units)do
          local alive=try(function()return U.alive(unit)end)
          if alive==true and slot(unit)==saved.slot then return false end
          if alive~=true and alive~=false then complete=false end
        end end
      end
      return complete
    end
    -- Conservative whole-feed barrier: any unresolved rollback blocks
    -- the first cold takeover, including an unrelated actor's failed restore.
    function M.native_handoff_clean(scope)
      if not scope then return next(pending)==nil end
      return rawget(_G,'__hd2ir_handoff_scope_clean')(scope,pending,function(r)return r.world,r.avatar end)
    end
    function M.restore_pending(bindings)
      for _,b in ipairs(bindings)do b.scene_restore_blocked=nil end
      if next(pending)==nil then return end
      local slot=rawget(_G,'__hd2ir_unit_instance_slot')
      local life=rawget(_G,'__hd2ir_shared_body_lifecycle')
      local current,attempted,recovering={},{},{}
      for _,b in ipairs(bindings)do current[slot(b.unit)]=b end
      for id,saved in pairs(pending)do
        recovering[saved.avatar]=true
        local b=current[id]
        local token=token_key(life.token(saved.avatar))
        if not token or token~=saved.token then
          pending[id]=nil;log('scene-restore retired actor incarnation; discarded numeric record')
        elseif not b then
          if absent(saved) then
            pending[id]=nil;log('scene-restore Unit absent from complete current World scan; discarded numeric record')
          elseif not saved.reported then
            log('scene-restore current binding unresolved; numeric record retained, affected body assembly withheld');saved.reported=true
          end
        else
          local fresh=identity(b)
          if not fresh or fresh.world~=saved.world or fresh.avatar~=saved.avatar or
              fresh.hash~=saved.hash or fresh.count~=saved.count then
            pending[id]=nil;log('scene-restore changed binding; discarded numeric record without writing')
          else
            local result={}
            local _,why=pcall(function()
              assert(not saved.incomplete,'original rollback snapshot incomplete; restart required')
              assert(U.alive(b.unit)==true and U.alive(b.avatar.unit)==true,'current Unit unavailable')
              assert(U.num_scene_graph_items(b.unit)==saved.count,'current graph changed')
              -- Validate every row before touching this current Unit. A newer
              -- native animation is preserved, never overwritten by an old pose.
              local restore,check={},{}
              for _,row in ipairs(saved.rows)do
                local parent=U.scene_graph_parent(b.unit,row.node)
                if type(parent)~='number' or parent<saved.offset or parent>=saved.count+saved.offset or parent==row.node then parent=-1 end
                assert(parent==row.parent,'current parent graph changed')
                local q,p=pose_numbers(b.unit,row.node,false)
                assert(q and p,'current local pose unavailable')
                if same(q,p,row.original) then check[#check+1]=row
                else
                  assert(row.expected,'failed pose was not readable; cannot authenticate deferred write')
                  if same(q,p,row.expected) then restore[#restore+1]=row;check[#check+1]=row
                  else
                    -- Preserve new animation without writing it, but still
                    -- watch its current value until every sibling refresh is
                    -- finished. This callback-local observation never becomes
                    -- permission to restore an old (or new) animation pose.
                    check[#check+1]={node=row.node,original={q=copy(q,4),p=copy(p,3)}}
                  end
                end
              end
              result.restore,result.check=restore,check
              result.prepared=true
            end)
            attempted[#attempted+1]={binding=b,saved=saved,result=result,why=why}
          end
        end
      end
      -- Observe ALL pending members before the first refresh. pairs/World
      -- order must not let one retry's pollution masquerade as another member's
      -- newly observed native animation.
      for _,attempt in ipairs(attempted)do
        local b,saved,result=attempt.binding,attempt.saved,attempt.result
        if result.prepared then
          local _,why=pcall(function()
            for _,row in ipairs(result.restore)do
              U.set_local_rotation(b.unit,row.node,assert(engine_quaternion(row.original.q),'restore rotation unavailable'))
              U.set_local_position(b.unit,row.node,assert(engine_vector(row.original.p),'restore position unavailable'))
            end
            if #result.restore>0 or saved.refresh then
              saved.refresh=true
              W.update_unit(b.world,b.unit)
              saved.refresh=false
            end
            for _,row in ipairs(result.restore)do
              local q,p=pose_numbers(b.unit,row.node,false)
              assert(same(q,p,row.original),'deferred restoration readback failed')
            end
            result.complete=true
          end)
          if not result.complete then attempt.why=why end
        end
      end
      -- As with scene completion, a later sibling's update may invalidate an
      -- earlier successful restoration. Do not retire it on immediate readback.
      local completed,failed_groups={},{}
      for _,attempt in ipairs(attempted)do
        local b,saved,result=attempt.binding,attempt.saved,attempt.result
        if result.complete then for _,row in ipairs(result.check)do
          local q,p=pose_numbers(b.unit,row.node,false)
          if not same(q,p,row.original) then result.complete=false;attempt.why='completed restoration readback failed';break end
        end end
        completed[saved.slot]=result.complete==true
        if not result.complete then
          -- A partial retry can itself have changed one component. Refresh
          -- only this owned failure snapshot, never the original values.
          for _,row in ipairs(result.restore or {})do
            local q,p=pose_numbers(b.unit,row.node,false)
            if q and p and row.expected then
              local qowned=qerror_degrees(q,row.original.q)<.001 or qerror_degrees(q,row.expected.q)<.001
              local powned=perror(p,row.original.p)<.00001 or perror(p,row.expected.p)<.00001
              if qowned and powned then row.expected={q=copy(q,4),p=copy(p,3)} end
            end
          end
          if not saved.reported then log('scene-restore FAILED: retry pending; affected body assembly withheld: '..tostring(attempt.why));saved.reported=true end
        end
      end
      -- A successful sibling is still a numeric watch member until its whole
      -- Avatar finishes. Otherwise a later callback's retry could pollute it
      -- after its record had already been retired.
      for id,saved in pairs(pending)do if not completed[id] then failed_groups[saved.avatar]=true end end
      for id,saved in pairs(pending)do if not failed_groups[saved.avatar] then
        pending[id]=nil;log('scene-restore completed shared assembly with fresh handles; newer native animation preserved')
      end end
      -- Do not suppress helmets, non-shared groups or another actor. The
      -- shared body's own publication barrier must not bypass a pending member.
      for _,b in ipairs(bindings)do
        if C.shared_body_profile and tonumber(C.shared_body_profile(b.profile.id))==1 then
          local avatar=slot(b.avatar.unit)
          if recovering[avatar] then
            -- Discovery sampled these before recovery. Do not feed stale local
            -- values to the next driver or stale root values to bind_unit.
            b.native_snapshot=nil
            if b.root_node~=nil then
              local q,p=world_pose(b.unit,b.root_node)
              if q and p then b.root_q,b.root_p=q,p
              else b.scene_restore_blocked=true end
            end
          end
          for _,saved in pairs(pending)do if saved.avatar==avatar then b.scene_restore_blocked=true;break end end
        end
      end
    end
    return M
  end)())

  function pose_capture.rollback_verify(context,writes,restore_all)
    for _,pose in ipairs(writes)do if restore_all or not pose.unchanged then
      local before=pose_capture.driver_read(context,pose.node)
      local q,p=pose_numbers(context.unit,pose.node,false)
      if not before or not q or not p or qerror_degrees(q,before.local_q)>=.001 or perror(p,before.local_p)>=.00001 then return false end
    end end
    return true
  end

  function pose_capture.rollback(world,context,writes,restore_all)
    local unit,complete=context.unit,true
    for _,pose in ipairs(writes)do
      local before=pose_capture.driver_read(context,pose.node)
      if before and (restore_all or not pose.unchanged) then
        local q,p=pose_numbers(unit,pose.node,false)
        if not q or not p or qerror_degrees(q,before.local_q)>=.001 or perror(p,before.local_p)>=.00001 then
          local result={}
          pcall(function()
            U.set_local_rotation(unit,pose.node,assert(engine_quaternion(before.local_q),'rollback rotation unavailable'))
            U.set_local_position(unit,pose.node,assert(engine_vector(before.local_p),'rollback position unavailable'))
            result.complete=true
          end)
          if not result.complete then complete=false end
        end
      elseif not before then complete=false end
    end
    context.restore_refresh_pending=not call(W.update_unit,world,unit)
    if context.restore_refresh_pending or not pose_capture.rollback_verify(context,writes,restore_all) then complete=false end
    local recovery=rawget(_G,'__hd2ir_scene_restore')
    if complete then recovery.clear(context.binding)
    else recovery.save(context,writes,restore_all) end
    return complete
  end

  function pose_capture.commit(unit,writes,result)
    local changed,made=0,{}
    for i=1,#writes do
      local pose=writes[i]
      if not pose.unchanged then
        -- Only numbers survive preparation/barriers. Engine math temporaries
        -- are constructed immediately before the setter which consumes them,
        -- matching the weapon transaction's established lifetime boundary.
        local rotation
        if writes.numeric_owner then
          local angle=writes.numeric_owner[i-1].axis_angle
          made.value=nil
          pose_capture.quaternion(angle[0],angle[1],angle[2],angle[3],made)
          rotation=made.value
          made.value=nil
        else rotation=engine_quaternion(pose.q) end
        assert(rotation~=nil,"engine commit rotation unavailable")
        U.set_local_rotation(unit,pose.node,rotation)
        local position=V3Ctor(pose.p[1],pose.p[2],pose.p[3])
        assert(position~=nil,"engine commit position unavailable")
        U.set_local_position(unit,pose.node,position)
        changed=changed+1
      end
    end
    result.changed=changed
    result.complete=true
  end

  -- Rig slots address the serialized scene graph. Resolve its numbering
  -- against the live engine by name; never infer it from an in-range integer.
  -- Custom nodes inherit the same offset only after all mapped nodes agree.
  function pose_capture.names(unit, profile, node_count, names, result)
    local offset, matched = nil, 0
    for i, flags in ipairs(profile.target_flags or {}) do
      if math.floor(flags / 1024) % 2 == 1 then
        local source = profile.target_sources[i]
        local name = source ~= nil and names[source + 1] or nil
        local resolver=rawget(_G,'__hd2ir_topology_node')
        local actual
        if name and resolver then actual=resolver(unit,name,node_count)
        else local has=name and U.has_node(unit,name);actual=has==true and U.node(unit,name) or nil end
        local stored = profile.nodes[i]
        if type(actual) ~= "number" or actual ~= math.floor(actual) or
           actual < 0 or actual > node_count or type(stored) ~= "number" then
          result.error="authored node name missing/out of range: " .. tostring(name);return
        end
        local delta = actual - stored
        if (delta ~= 0 and delta ~= 1) or (offset ~= nil and offset ~= delta) then
          result.error=string.format("authored node index mismatch %s file=%d engine=%d offset=%s",
                                   tostring(name), stored, actual, tostring(offset));return
        end
        offset, matched = delta, matched + 1
      end
    end
    result.offset,result.matched=offset or 0,matched
    result.complete=true
  end
  local function authored_scene_node_offset(unit, profile, node_count, names)
    local result={}
    pcall(pose_capture.names,unit,profile,node_count,names,result)
    if not result.complete then return nil,result.error or "authored node name query failed" end
    return result.offset,nil,result.matched
  end

  -- A numeric snapshot shared only by this callback's proof and write pass.
  -- Never retain engine pose userdata or reuse this after a Unit was written.
  function pose_capture.native(profile,unit,offset,native)
    for i,flags in ipairs(profile.target_flags) do
      if math.floor(flags/1024)%2==1 then
        local node=profile.nodes[i]+offset
        local sample={}
        pose_capture.node(unit,node,sample)
        if not sample.complete then return end
        local parent=sample.parent
        local lq,lp,wq,wp=sample.local_q,sample.local_p,sample.world_q,sample.world_p
        if not (parent==nil or parent==-1 or (offset==1 and parent==0)) then return end
        local iq,ip=inverse_pose(lq,lp)
        local q,p=compose_pose(wq,wp,iq,ip)
        if not q or not p then return end
        native[#native+1]={name=source_names[profile.target_sources[i]+1],source=profile.target_sources[i],q=q,p=p}
        sample.parent=-1
        sample.native_parent_q,sample.native_parent_p=q,p
        native.samples[node+1]=sample
      end
    end
    native.complete=true
  end
  rawset(_G,"__hd2ir_sample_native_links",function(profile,unit,count)
    local offset,err,named=authored_scene_node_offset(unit,profile,count,source_names)
    if offset==nil then return nil,err end
    local native={samples={},offset=offset,named=named,frame=frame,unit=unit,profile=profile,node_count=count}
    pcall(pose_capture.native,profile,unit,offset,native)
    if not native.complete or #native<2 or #native~=named then return nil end
    return native
  end)

  -- Prepare every current authored Unit once before any writes. The same
  -- callback-local snapshot serves ship matching, preview proof and commit.
  rawset(_G,"__hd2ir_prepare_native_snapshots",function(armour_units)
    local meter=rawget(_G,'__hd2ir_scan_meter');if meter then meter('snapshot_begin')end
    local pool={};local bones=0
    for _,armour in ipairs(armour_units) do
      local profile=armour.profile
      if profile.authored and profile.active and not profile.observe_only then
        local count=try(function() return U.num_scene_graph_items(armour.unit) end)
        armour.node_count=count
        if type(count)=="number" and count>1 and count<=256 then
          armour.native_snapshot=rawget(_G,"__hd2ir_sample_native_links")(profile,armour.unit,count)
          if armour.native_snapshot then pool[#pool+1]=armour.native_snapshot;bones=bones+#armour.native_snapshot end
        end
      end
    end
    if meter then meter('snapshot_end');meter('snapshots',#pool);meter('snapshot_bones',bones)end
    return pool
  end)

  -- Sparse torso/hip/arm parts can contain a thigh but no knee/foot. Their
  -- shared leg adaptation needs that foot, which an unrelated zero-root
  -- preview Avatar cannot supply. Complete ONLY a proven continuous native
  -- leg from live clothing in this World: root/boss/hips/thigh plus
  -- every other overlapping channel must agree, and all matches must agree
  -- on the missing foot chain. No Avatar identity or physical state is used.
  rawset(_G,"__hd2ir_complete_preview_legs",function(native,pool)
    local own,extra={},{}
    for _,pose in ipairs(native) do own[pose.name]=pose end
    for _,side in ipairs({"l_","r_"}) do
      local anchors={"root","boss","hips",side.."thigh"}
      local complete=true
      for _,name in ipairs(anchors) do if not own[name] then complete=false end end
      if complete and not own[side.."foot"] then
        local reference,common,ambiguous=nil,{},false
        for _,other in ipairs(pool or {}) do
          if other~=native then
            local by_name={}
            for _,pose in ipairs(other) do by_name[pose.name]=pose end
            local matches=by_name[side.."knee"]~=nil and by_name[side.."foot"]~=nil
            for _,name in ipairs(anchors) do if not by_name[name] then matches=false end end
            if matches then
              for name,pose in pairs(own) do
                local peer=by_name[name]
                if peer and (perror(peer.p,pose.p)>0.0002 or qerror_degrees(peer.q,pose.q)>0.05) then matches=false break end
              end
            end
            if matches then
              if reference then
                for _,suffix in ipairs({"knee","foot","ball","toe"}) do
                  local name=side..suffix
                  local a,b=reference[name],by_name[name]
                  -- A retained optional toe is not a contradictory knee/foot.
                  -- Only export the intersection of unanimously available
                  -- channels; still reject any actual observed disagreement.
                  if not b then common[name]=false end
                  if a and b and (perror(a.p,b.p)>0.0002 or qerror_degrees(a.q,b.q)>0.05) then ambiguous=true break end
                  if not a and b then reference[name]=b end
                end
              else
                reference=by_name
                for _,suffix in ipairs({"knee","foot","ball","toe"}) do common[side..suffix]=by_name[side..suffix]~=nil end
              end
            end
          end
        end
        if reference and not ambiguous then
          for _,suffix in ipairs({"knee","foot","ball","toe"}) do
            local pose=reference[side..suffix]
            if pose and common[pose.name] and not own[pose.name] and type(pose.source)=="number" and
               pose.source==math.floor(pose.source) and pose.source>=0 and
               source_names[pose.source+1]==pose.name then extra[#extra+1]=pose end
          end
        end
      end
    end
    return extra
  end)

  -- Capture the rejected proof, not just successful output. A missing donor,
  -- a conflicting donor and differing driver input need different fixes.
  rawset(_G,"__hd2ir_preview_rejected_proof",function(profile,native,pool,extra,sources,reason)
    if not C.shared_body_profile or not candidate_trace then return end
    local key="preview-rejected-proof|"..profile.hash
    if ambiguity_probe_logged[key] then return end
    ambiguity_probe_logged[key]=true
    local prefix="presentation rejected-proof unit="..profile.hash.." frame="..frame.." "
    local own,completed={},{}
    for _,p in ipairs(native) do own[p.name]=p end
    for _,p in ipairs(extra) do completed[#completed+1]=p.name end
    log(prefix.."reason="..reason.." extras="..table.concat(completed,",").." donors="..#(pool or {}).." sources="..#sources)
    local function poses(label,rows)
      local text={}
      for name,p in pairs(rows) do
        local values={}
        for _,v in ipairs(p.q) do values[#values+1]=string.format("%.9g",v) end
        for _,v in ipairs(p.p) do values[#values+1]=string.format("%.9g",v) end
        text[#text+1]=name.."="..table.concat(values,",")
      end
      table.sort(text)
      for first=1,#text,6 do
        local chunk={};for i=first,math.min(first+5,#text) do chunk[#chunk+1]=text[i] end
        log(prefix..label.." "..table.concat(chunk,";"))
      end
    end
    poses("own",own)
    for index,other in ipairs(pool or {}) do
      if index>64 then log(prefix.."donor-cap-reached");break end
      local rows,differences={},{}
      for _,p in ipairs(other) do
        if p.name=="root" or p.name=="boss" or p.name=="hips" or p.name:find("thigh",1,true) or
           p.name:find("knee",1,true) or p.name:find("foot",1,true) or p.name:find("ball",1,true) or p.name:find("toe",1,true) then rows[p.name]=p end
        local mine=own[p.name]
        if mine then
          local pe,qe=perror(mine.p,p.p),qerror_degrees(mine.q,p.q)
          if pe>0.0002 or qe>0.05 then differences[#differences+1]=string.format("%s:%.9gm/%.9gdeg",p.name,pe,qe) end
        end
      end
      table.sort(differences)
      local label="donor="..index..":"..tostring(other.profile and other.profile.hash or "unknown")
      log(prefix..label.." overlap-differences="..table.concat(differences,","))
      poses(label,rows)
    end
    for index,source in ipairs(sources) do
      local rows={}
      for name,p in pairs(source.by_name) do if not own[name] then rows[name]=p end end
      poses("candidate-missing="..index,rows)
    end
  end)

  -- Candidate-only replay evidence. Numeric copies only, emitted once per
  -- profile/World by the successful-write caller; never retain scene handles.
  rawset(_G,"__hd2ir_preview_numeric_trace",function(profile,rq,rp,input,nodes,output,count)
    if not C.shared_body_profile or not candidate_trace or input==nil then return end
    local root=ffi.new("float[12]");fill_matrix(root,0,rq,rp)
    local function emit(kind,data,n,labels)
      for first=0,n-1,4 do
        local rows={}
        for i=first,math.min(first+3,n-1) do
          local values={}
          for j=0,11 do values[#values+1]=string.format("%.9g",tonumber(data[i*12+j])) end
          rows[#rows+1]=tostring(labels and labels(i) or i).."="..table.concat(values,",")
        end
        log("preview-write snapshot unit="..profile.hash.." frame="..frame.." kind="..kind.." "..table.concat(rows,";"))
      end
    end
    emit("root",root,1)
    emit("input",input,#source_names,function(i)return source_names[i+1]end)
    emit("output",output,count,function(i)return tonumber(nodes[i])end)
  end)

  -- Optional explicitly armed CPU/GPU diagnostic. The companion module is
  -- never loaded here. This successful-write hook is not a once-per-profile
  -- log: late manual capture must see fresh per-instance numeric output.
  do
    local query,record,next_lookup=nil,nil,0
    rawset(_G,"__hd2ir_preview_capture_pose",function(profile,unit,world,rq,rp,input,nodes,output,count,phase)
      if not query and frame>=next_lookup then
        next_lookup=frame+300
        local k32=ffi.load("kernel32")
        local module=k32.GetModuleHandleA("HD2PreviewRuntime.addon64")
        if module==nil or module==ffi.NULL then module=k32.GetModuleHandleA("HD2BodyDrawProbe.addon64") end
        if module~=nil and module~=ffi.NULL then
          local a=k32.GetProcAddress(module,"hd2ir_body_capture_active_v1")
          local b=k32.GetProcAddress(module,"hd2ir_body_capture_pose_v1")
          if a~=nil and a~=ffi.NULL and b~=nil and b~=ffi.NULL then
            query=ffi.cast("unsigned (*)(void)",a)
            record=ffi.cast("unsigned (*)(const char *, const char *, unsigned long long, unsigned long long, unsigned, unsigned, const float *, const float *, unsigned, const unsigned *, const float *)",b)
          end
        end
      end
      if not query or tonumber(query())~=1 then return end
      local root=ffi.new("float[12]");fill_matrix(root,0,rq,rp)
      record(profile.hash,tostring(world),frame,instance_slot(unit),phase,#source_names,root,input,count,nodes,output)
    end)
  end

  -- Candidate delivery audit: handles live only inside one render invocation.
  do
    local queue,seen,profile_counts={},{},{}
    local delivery={}
    local function scale(unit,node)
      if not U or type(U.local_scale)~="function" then return nil end
      local values={}
      pcall(function()
        local x,y,z=V3.to_elements(U.local_scale(unit,node))
        if finite(x) and finite(y) and finite(z) then values={x,y,z} end
      end)
      return values[1] and values or nil
    end
    function delivery.begin() queue={} end
    function delivery.capture(profile,unit,writes,world)
      if not C.shared_body_profile or not candidate_trace or #queue>=32 or (profile_counts[profile.hash] or 0)>=8 then return end
      local slot=instance_slot(unit)
      local key=profile.hash.."|"..slot
      if seen[key] then return end
      seen[key]=true;profile_counts[profile.hash]=(profile_counts[profile.hash] or 0)+1
      local record={hash=profile.hash,instance=slot,unit=unit,nodes={}}
      record.population=world and try(function()return W.num_units(world)end) or -1
      if type(record.population)~="number" then record.population=-1 end
      for _,write in ipairs(writes) do
        local q,p=world_pose(unit,write.node)
        if q and p then record.nodes[#record.nodes+1]={node=write.node,q=q,p=p,scale=scale(unit,write.node)} end
      end
      queue[#queue+1]=record
    end
    function delivery.finish()
      local pending=queue;queue={} -- clear even if a destroyed Unit/getter fails
      for _,record in ipairs(pending) do
        local changes,missing,maximum_r,maximum_p,scale_deviation,scale_reads={},0,0,0,0,0
        for _,before in ipairs(record.nodes) do
          local after_scale=scale(record.unit,before.node)
          for _,s in pairs({before.scale,after_scale}) do
            scale_reads=scale_reads+1
            for i=1,3 do scale_deviation=math.max(scale_deviation,math.abs(s[i]-1)) end
          end
          local q,p=world_pose(record.unit,before.node)
          if q and p then
            local r,d=qerror_degrees(q,before.q),perror(p,before.p)
            maximum_r,maximum_p=math.max(maximum_r,r),math.max(maximum_p,d)
            if (r>.05 or d>.0002) and #changes<8 then
              changes[#changes+1]=string.format("%d:%.6fdeg/%.7fm",before.node,r,d)
            end
          else missing=missing+1 end
        end
        log(string.format("preview-write delivery unit=%s instance=%d frame=%d population=%d nodes=%d missing=%d max=%.6fdeg/%.7fm scale_reads=%d scale_deviation=%.7f changed=%s",
          record.hash,record.instance,frame,record.population,#record.nodes,missing,maximum_r,maximum_p,scale_reads,scale_deviation,table.concat(changes,",")))
      end
    end
    rawset(_G,"__hd2ir_preview_delivery",delivery)
  end
  -- End candidate delivery audit.

  -- Verified stock source families: FS-23 display uses 5b390845; the animated
  -- democracy officer uses 15678e36. Keep their pose source and identity apart
  -- from players. Every custom target must prove ALL native parent links.
  rawset(_G,"__hd2ir_collect_nonplayer_presentations",function(world,scene_sources,armour_units,outputs,owned)
    if not C.retarget_presentation_pose or #scene_sources==0 or #scene_sources>32 then return end
    local sources={}
    local source_reject,authored_count,native_count,output_start="none",0,0,#outputs
    -- This stateless path consumes one Profile, not the global installed Mod
    -- set. Keep missing channels as placeholders, then validate the concrete
    -- target's dependencies after proving its native parent ownership.
    for _,scene_source in ipairs(scene_sources) do
      local unit=scene_source.unit
      if (scene_source.hash=="5b390845a8e3fc29" or scene_source.hash=="15678e360612b805") and
         string.find(debug_name(unit),scene_source.hash,1,true) then
        local count=try(function() return U.num_scene_graph_items(unit) end)
        local root=try(function() if U.has_node(unit,"StingrayEntityRoot") then return U.node(unit,"StingrayEntityRoot") end end)
        if type(count)=="number" and count>=#source_names and count<=256 and type(root)=="number" and root>=1 and root<=count then
          local rq,rp=world_pose(unit,root)
          local poses,packed,complete={},ffi.new("float[?]",#source_names*12),rq~=nil and rp~=nil
          for i,name in ipairs(source_names) do
            local node=try(function() if U.has_node(unit,name) then return U.node(unit,name) end end)
            local q,p
            if type(node)=="number" and node>=1 and node<=count then q,p=world_pose(unit,node) end
            if not q or not p then
              if not rq or not rp then complete=false source_reject="missing-root:"..name break end
              q,p=rq,rp
            else poses[name]={q=q,p=p} end
            fill_matrix(packed,(i-1)*12,q,p)
          end
          if complete then sources[#sources+1]={poses=poses,context={root_q=rq,p=rp,source_bones=packed,
            camera_nearest=false,camera_distance=math.huge,presentation_kind=scene_source.kind,source_resource=scene_source.hash}} end
        else source_reject="count-or-root:"..tostring(count)..":"..tostring(root) end
      else source_reject="resource:"..debug_name(unit) end
    end
    for _,armour in ipairs(armour_units) do
      local profile,unit=armour.profile,armour.unit
      if profile.authored and profile.active and not profile.observe_only and #outputs<256 then
        authored_count=authored_count+1
        local count=armour.node_count or try(function() return U.num_scene_graph_items(unit) end)
        local native=armour.native_snapshot or (type(count)=="number" and rawget(_G,"__hd2ir_sample_native_links")(profile,unit,count) or nil)
        if native then
          local chosen,ambiguous=nil,false
          if #native>=2 then
            native_count=native_count+1
            for _,source in ipairs(sources) do
              local matches=true
              for _,pose in ipairs(native) do
                local expected=source.poses[pose.name]
                if not expected or perror(expected.p,pose.p)>.002 or qerror_degrees(expected.q,pose.q)>.2 then matches=false break end
              end
              if matches then
                -- Once native links prove this is a ship presentation, never
                -- fall back to the nearest player, even if a required channel
                -- is absent or another source makes the pose ambiguous.
                owned[unit]=true
                for _,index in ipairs(profile.target_sources or {}) do
                  if index>=0 and not source.poses[source_names[index+1]] then
                    matches=false source_reject="profile-missing:"..tostring(source_names[index+1]) break
                  end
                end
              end
              if matches then
                if chosen then
                  -- Identical input is safe for a stateless presentation; a
                  -- difference in ANY driver-only channel rejects the match.
                  if perror(chosen.context.p,source.context.p)>.0002 or qerror_degrees(chosen.context.root_q,source.context.root_q)>.05 then ambiguous=true end
                  for name,a in pairs(chosen.poses) do
                    local b=source.poses[name]
                    if not b or perror(a.p,b.p)>.0002 or qerror_degrees(a.q,b.q)>.05 then ambiguous=true break end
                  end
                else chosen=source end
              end
            end
          end
          if chosen and not ambiguous then
            outputs[#outputs+1]={world=world,profile=profile,avatar=chosen.context,unit=unit,node_count=count,pose_only=true,native_snapshot=native}
            owned[unit]=true
            local key="nonplayer-presentation|"..profile.hash.."|"..chosen.context.source_resource
            if not retarget_mapping_logged[key] then
              retarget_mapping_logged[key]=true
              log("authored nonplayer "..profile.hash.." source="..chosen.context.source_resource.." kind="..tostring(chosen.context.presentation_kind).." accepted=native-parent-proof stateless=true")
            end
          end
        end
      end
    end
    -- Bounded read-only diagnostics: distinguish no stand, incomplete source,
    -- and no matching authored clothing before making any broader change.
    local diagnostic=string.format("sources_queried=%d sources=%d authored=%d native=%d matched=%d source_reject=%s",
      #scene_sources,#sources,authored_count,native_count,#outputs-output_start,source_reject)
    local key="nonplayer-diagnostic|"..diagnostic
    local budget=retarget_mapping_logged["nonplayer-diagnostic-count"] or 0
    if not retarget_mapping_logged[key] and budget<12 then
      retarget_mapping_logged[key]=true
      retarget_mapping_logged["nonplayer-diagnostic-count"]=budget+1
      log("authored nonplayer diagnostic "..diagnostic)
    end
  end)

  -- Avatar Units are read-only for this entire callback. Share numeric source
  -- reads across every clothing proof, preview consensus and mailbox push.
  -- The cache itself is replaced at render entry: no previous-frame handles,
  -- topology or poses can establish ownership in a later callback.
  function pose_capture.avatar_index(avatar,name)
    local resolver=rawget(_G,'__hd2ir_topology_node')
    if resolver then return resolver(avatar.unit,name,avatar.node_count)end
    if U.has_node(avatar.unit,name) then return U.node(avatar.unit,name) end
  end
  rawset(_G,"__hd2ir_read_avatar_pose",function(avatar,name)
    local cache=rawget(_G,"__hd2ir_source_reads")
    local rows=cache and cache[avatar]
    if rows and rows[name] then return rows[name].q,rows[name].p end
    local node_ok,node=pcall(pose_capture.avatar_index,avatar,name)
    if not node_ok then return nil,nil end
    if type(node)~="number" or node~=math.floor(node) or node<0 or node>=avatar.node_count then return nil,nil end
    local q,p=world_pose(avatar.unit,node)
    if not q or not p then return nil,nil end
    if cache then
      if not rows then rows={};cache[avatar]=rows end
      rows[name]={q=q,p=p}
    end
    return q,p
  end)

  -- Preview Avatars can share a zero root position. Resolve ownership by the
  -- live native bone poses in that case, never by whichever Avatar is first.
  rawset(_G, "__hd2ir_refine_authored_owner", function(profile, unit, node_count, candidates, snapshot)
    if not profile.authored then return nil end
    local native=snapshot or rawget(_G,"__hd2ir_sample_native_links")(profile,unit,node_count)
    if not native then return nil end
    local best, best_error, second_error = nil, math.huge, math.huge
    -- Every score term is nonnegative. A partial sum above this bound already
    -- proves that the final mean exceeds .04: it can neither own the Unit
    -- (<=.02) nor challenge an accepted owner within the .01 ambiguity margin.
    -- Potential owners/close competitors still read and validate every bone.
    -- This is a same-callback numerical rejection, not a cached identity or a
    -- root-distance heuristic. Leave a .01 gap above the decisive .03 edge.
    local rejection_sum=#native*0.04
    for _, candidate in pairs(candidates) do
      local avatar, score = candidate.avatar, 0
      for _, pose in ipairs(native) do
        local q,p = rawget(_G,"__hd2ir_read_avatar_pose")(avatar,pose.name)
        if not q or not p then return nil end
        -- Mean positional error plus an orientation error expressed in metres.
        score = score + perror(p,pose.p) + qerror_degrees(q,pose.q)*0.002
        if score>rejection_sum then break end
      end
      score=score/#native
      if score < best_error then second_error,best_error,best=best_error,score,candidate
      else second_error=math.min(second_error,score) end
    end
    if best_error <= 0.02 and second_error-best_error > 0.01 then return best end
    -- Matching but identical poses are NOT proof of instance ownership. The
    -- caller may separately prove a stateless presentation input consensus.
    return nil,best_error<=0.02 and native or nil
  end)

  rawset(_G,"__hd2ir_presentation_context",function(candidates,native,cache,profile,native_pool)
    if not native or #native<2 then return nil,"native-link-unproven" end
    if not cache.checked then
      cache.checked=true
      cache.sources={}
      -- Snapshot once per World/callback, but do not demand that unrelated
      -- body/head/cape previews in that World use the same animation.
      for _,candidate in pairs(candidates) do
        if #cache.sources>=32 then cache.error="too-many-candidates" break end
        local avatar=candidate.avatar
        if not avatar or not avatar.root_q or not avatar.p then cache.error="candidate-root-unavailable" break end
        local poses,by_name={},{}
        for i,name in ipairs(source_names) do
          local q,p=rawget(_G,"__hd2ir_read_avatar_pose")(avatar,name)
          if not q or not p then cache.error="candidate-pose-unavailable:"..name break end
          poses[i]={q=q,p=p}
          by_name[name]=poses[i]
        end
        if cache.error then break end
        cache.sources[#cache.sources+1]={poses=poses,by_name=by_name,root_q=avatar.root_q,p=avatar.p}
      end
    end
    if cache.error then return nil,cache.error end
    local extra=profile and rawget(_G,"__hd2ir_complete_preview_legs")(native,native_pool) or {}
    local reference,count,matched_sources,divergence=nil,0,{},nil
    for _,source in ipairs(cache.sources) do
      local matches=true
      for _,pose in ipairs(native) do
        local expected=source.by_name[pose.name]
        if not expected or perror(expected.p,pose.p)>0.002 or qerror_degrees(expected.q,pose.q)>0.5 then matches=false break end
      end
      if matches then
        count=count+1
        matched_sources[#matched_sources+1]=source
        if reference then
          if perror(reference.p,source.p)>0.0002 or qerror_degrees(reference.root_q,source.root_q)>0.05 then
            return nil,"candidate-roots-differ"
          end
          -- Fast path: complete input consensus. If it differs, prove actual
          -- stateless OUTPUT consensus below, including cross-part drivers.
          for i,pose in ipairs(source.poses) do
            local expected=reference.poses[i]
            if perror(expected.p,pose.p)>0.0002 or qerror_degrees(expected.q,pose.q)>0.05 then
              divergence=divergence or source_names[i]
            end
          end
        else reference=source end
      end
    end
    if count==0 then return nil,"native-source-unmatched" end
    -- A transition can fail the coarse unique-owner margin while EXACTLY one
    -- of several complete preview inputs matches this Unit's native parents.
    -- That is enough for stateless pose calculation, not for claiming an Avatar
    -- identity or borrowing its physics. Still reject a single-source caller:
    -- this fallback is only reached for the ambiguous multi-source path.
    if count==1 and #cache.sources<2 then return nil,"not-an-ambiguous-presentation" end
    if divergence or count==1 then
      if not profile or not C.retarget_presentation_pose then return nil,"presentation-output-proof-unavailable" end
      local capacity=profile.target_count
      if type(capacity)~="number" or capacity~=math.floor(capacity) or capacity<1 or capacity>256 then return nil,"invalid-output-capacity" end
      local root=ffi.new("float[12]")
      fill_matrix(root,0,reference.root_q,reference.p)
      local expected,expected_nodes
      for _,source in ipairs(matched_sources) do
        local input=ffi.new("float[?]",#source_names*12)
        for i,pose in ipairs(source.poses) do fill_matrix(input,(i-1)*12,pose.q,pose.p) end
        -- Exactly the same native-parent replacement as the write pass.
        -- Do not discard driver-only channels just because this part lacks them.
        for _,pose in ipairs(native) do
          local index=pose.source
          if type(index)~="number" or source_names[index+1]~=pose.name then return nil,"native-source-unavailable" end
          fill_matrix(input,index*12,pose.q,pose.p)
        end
        for _,pose in ipairs(extra) do fill_matrix(input,pose.source*12,pose.q,pose.p) end
        local nodes,output=ffi.new("unsigned[?]",capacity),ffi.new("float[?]",capacity*12)
        local returned,ok=try(function() return C.retarget_presentation_pose(profile.id,root,#source_names,input,capacity,nodes,output) end)
        if not ok or tonumber(returned)~=capacity then return nil,"presentation-output-unavailable" end
        for i=0,capacity-1 do
          if tonumber(nodes[i])~=profile.nodes[i+1] or (expected_nodes and nodes[i]~=expected_nodes[i]) then return nil,"presentation-output-nodes-differ" end
          for j=0,11 do
            local value=tonumber(output[i*12+j])
            if not finite(value) then return nil,"presentation-output-nonfinite" end
            if expected and math.abs(value-tonumber(expected[i*12+j]))>0.00001 then
              rawget(_G,"__hd2ir_preview_rejected_proof")(profile,native,native_pool,extra,matched_sources,
                "node="..tostring(nodes[i])..":element="..j..":delta="..tostring(value-tonumber(expected[i*12+j])))
              return nil,"candidate-outputs-differ:node="..tostring(nodes[i])..":first-input-diff="..tostring(divergence)
            end
          end
        end
        expected,expected_nodes=output,nodes
      end
    end
    local bones=ffi.new("float[?]",#source_names*12)
    for i,pose in ipairs(reference.poses) do fill_matrix(bones,(i-1)*12,pose.q,pose.p) end
    for _,pose in ipairs(extra) do fill_matrix(bones,pose.source*12,pose.q,pose.p) end
    -- Still no Avatar Unit/id/instance or persistent state. A failed group
    -- cannot poison another Unit's independent consensus in this callback.
    return {root_q=reference.root_q,p=reference.p,source_bones=bones,
      camera_nearest=false,camera_distance=math.huge},count==1 and "native-single-presentation-input" or (#extra>0 and "native-leg-output-consensus" or (divergence and "native-output-consensus" or "native-pose-consensus"))
  end)

  -- Prove FP ownership from this Unit's native arm parents, not from camera
  -- distance, an equipped weapon, or a retained FP Unit. All handles/poses are
  -- callback-local. Stationary aiming stays valid; stale FP poses do not win.
  rawset(_G, "__hd2ir_native_contact_action", function(world, binding, native)
    if not binding.profile.authored or (not pose_capture.local_contact_owner(binding.avatar) and
        not (binding.pose_only and binding.preview_audit and not binding.avatar.presentation_kind)) then
      return 0,"not-local-authored"
    end
    local names = {}
    for _, side in ipairs({"l_", "r_"}) do
      if native[side.."shoulder"] and native[side.."elbow"] and native[side.."hand"] then
        for _, joint in ipairs({"shoulder", "elbow", "hand"}) do names[#names+1]=side..joint end
        for _, joint in ipairs({"shoulder_twist", "hand_twist"}) do
          if native[side..joint] then names[#names+1]=side..joint end
        end
      end
    end
    local partial=false
    if #names == 0 then
      -- A torso can own the skin above the arm's mesh seam while storing no
      -- elbow/hand. Accept TP only after its body anchors and every present
      -- native channel match the already-bound Avatar. Never infer FP from
      -- this partial chain. The receiver separately verifies same-file Rest
      -- compatibility before it can borrow a complete authored arm.
      if not native.boss or not native.chest then return 0,"incomplete-arm" end
      for _,side in ipairs({"l_","r_"}) do
        if native[side.."clavicle"] and native[side.."shoulder"] and native[side.."shoulder_twist"] then partial=true end
      end
      if not partial then return 0,"incomplete-arm" end
      for name,_ in pairs(native) do names[#names+1]=name end
    end
    local function matches(unit)
      for _, name in ipairs(names) do
        local q,p
        -- Reuse this callback's read-only TP source snapshot. The concrete
        -- Avatar object is the cache key; FP/preview probes without that
        -- validated descriptor retain their live per-Unit reader.
        if unit==binding.avatar.unit and binding.avatar.node_count then
          q,p=rawget(_G,"__hd2ir_read_avatar_pose")(binding.avatar,name)
        else
          q,p=pose_capture.fp_pose(unit,name)
        end
        local pose = native[name]
        -- Engine float/recomposition tolerance, not a per-model fit offset.
        if not q or not p or perror(p,pose.p)>0.002 or qerror_degrees(q,pose.q)>0.5 then return false end
      end
      return true
    end
    if binding.avatar.unit and matches(binding.avatar.unit) then return 0,"tp-match",partial end
    if partial then return 0,"partial-arm-not-tp" end
    local candidates=pose_capture.fp_graphs(world)
    if type(candidates) ~= "table" then return 0,"fp-unavailable" end
    local count = 0
    for _, unit in pairs(candidates) do
      if matches(unit) then count=count+1 end
      if count>1 then return 0,"ambiguous-fp" end
    end
    return count==1 and 3 or 0,count==1 and "unique-native-fp" or "fp-not-matched"
  end)

  --@@FIRST_PERSON_PRESENTATIONS_BEGIN@@
  -- Reuse the verified native-parent FP proof before the TP root-distance
  -- gate. Do not invent an Avatar or feed these parts into player physics.
  rawset(_G,"__hd2ir_collect_first_person_presentations",function(world,avatars,armour,outputs,owned)
    if not C.retarget_first_person_pose then return end
    local graphs=pose_capture.fp_graphs(world)
    if type(graphs)~="table" or #graphs~=1 then return end
    local graph=graphs[1]
    local count=try(function()return U.num_scene_graph_items(graph)end)
    if type(count)~="number" or count<1 or count>256 or count~=math.floor(count) then return end
    local rq,rp=world_pose(graph,1)
    if not rq or not rp then return end
    -- Do not read the entire retained FP graph during ordinary TP play. Its
    -- source channels are needed only after a concrete clothing part proves FP.
    local poses
    for _,item in ipairs(armour) do
      local profile,native=item.profile,item.native_snapshot
      if not owned[item.unit] and profile.authored and profile.active and not profile.observe_only and
          native and native.frame==frame and native.unit==item.unit and native.profile==profile and
          native.node_count==item.node_count and
          #outputs<256 then
        local input={};for _,pose in ipairs(native)do input[pose.name]=pose end
        local proof={profile=profile,pose_only=true,preview_audit=true,avatar={}}
        local action=rawget(_G,"__hd2ir_native_contact_action")(world,proof,input)
        -- A matching current TP owner wins even in a World containing a stale
        -- FP graph. Test every actual TP owner, never only the camera-nearest.
        if action==3 then for _,avatar in ipairs(avatars)do
          proof.avatar={unit=avatar.unit,camera_nearest=true}
          if select(2,rawget(_G,"__hd2ir_native_contact_action")(world,proof,input))=="tp-match" then action=0 break end
        end end
        if action==3 then
          owned[item.unit]=true
          if not poses then
            poses={}
            for _,name in ipairs(source_names)do
              local node=try(function()if U.has_node(graph,name)then return U.node(graph,name)end end)
              if type(node)=="number" and node>=0 and node<=count and node==math.floor(node) then
                local q,p=pose_capture.fp_pose(graph,name)
                if q and p then poses[name]={q=q,p=p} end
              end
            end
          end
          local available={};for name,pose in pairs(poses)do available[name]=pose end
          for name,pose in pairs(input)do available[name]=pose end
          local complete=true
          for _,index in ipairs(profile.target_sources or {})do
            if index>=0 and not available[source_names[index+1]] then complete=false break end
          end
          if complete then
            local packed=ffi.new("float[?]",#source_names*12)
            for i,name in ipairs(source_names)do
              local pose=available[name]
              fill_matrix(packed,(i-1)*12,pose and pose.q or rq,pose and pose.p or rp)
            end
            outputs[#outputs+1]={world=world,profile=profile,unit=item.unit,node_count=item.node_count,
              pose_only=true,preview_audit=true,native_snapshot=native,
              avatar={root_q=rq,p=rp,source_bones=packed,camera_nearest=false,camera_distance=math.huge}}
          end
        end
      end
    end
  end)
  --@@FIRST_PERSON_PRESENTATIONS_END@@

  -- TP actions are version-bound native reload states and weapon-pose tuples.
  -- Validate their compressed source chunks ONCE at boot, outside the render
  -- callback; a game update/missing source disables TP only, never FK or FP.
  --@@ANIMATION_LIFECYCLE_GUARD_BEGIN@@
  -- A corpse Unit can remain alive after its animation state machine is gone;
  -- a newly spawned Unit may not have one yet. animation_get_state dereferences
  -- that component without checking it. Lua pcall cannot make that native
  -- pointer access safe. The game's has_animation_state_machine checks the
  -- same virtual getter for NULL and returns a boolean without dereferencing it.
  -- Never cache readiness across frames or carry an old Unit into this query.
  rawset(_G,"__hd2ir_animation_ready",function(unit)
    if unit==nil then return false end
    local ok,ready=pcall(function()
      if type(U.alive)~="function" or type(U.has_animation_state_machine)~="function" then return false end
      return U.alive(unit)==true and U.has_animation_state_machine(unit)==true
    end)
    return ok and ready==true
  end)
  --@@ANIMATION_LIFECYCLE_GUARD_END@@

  rawset(_G, "__hd2ir_tp_contact_action", (function()
    local catalog = {["layer_count"]=31,["source_slices"]={{["file"]="bundles.29.nxa",["offset"]=160640,["size"]=32,["crc32"]=3994772086},{["file"]="bundles.29.nxa",["offset"]=222691328,["size"]=26395,["crc32"]=2110218307},{["file"]="bundles.29.nxa",["offset"]=160672,["size"]=32,["crc32"]=131680458},{["file"]="bundles.29.nxa",["offset"]=222717728,["size"]=15129,["crc32"]=783949465},{["file"]="bundles.29.nxa",["offset"]=160704,["size"]=32,["crc32"]=3706690821},{["file"]="bundles.29.nxa",["offset"]=222732864,["size"]=17409,["crc32"]=4120409842},{["file"]="bundles.29.nxa",["offset"]=160736,["size"]=32,["crc32"]=2945098120},{["file"]="bundles.29.nxa",["offset"]=222750288,["size"]=9380,["crc32"]=2085577539},{["file"]="bundles.29.nxa",["offset"]=160768,["size"]=32,["crc32"]=4034652488},{["file"]="bundles.29.nxa",["offset"]=222759680,["size"]=8309,["crc32"]=3943996291},{["file"]="bundles.29.nxa",["offset"]=160800,["size"]=32,["crc32"]=540470987},{["file"]="bundles.29.nxa",["offset"]=222768000,["size"]=12359,["crc32"]=740874441},{["file"]="bundles.29.nxa",["offset"]=160832,["size"]=32,["crc32"]=2276255784},{["file"]="bundles.29.nxa",["offset"]=222780368,["size"]=7424,["crc32"]=2084344736},{["file"]="bundles.29.nxa",["offset"]=160864,["size"]=32,["crc32"]=3347446154},{["file"]="bundles.29.nxa",["offset"]=222787792,["size"]=14486,["crc32"]=3426498364},{["file"]="bundles.29.nxa",["offset"]=160896,["size"]=32,["crc32"]=2098976443},{["file"]="bundles.29.nxa",["offset"]=222802288,["size"]=14252,["crc32"]=753080270},{["file"]="bundles.29.nxa",["offset"]=160928,["size"]=32,["crc32"]=2013260576},{["file"]="bundles.29.nxa",["offset"]=222816544,["size"]=23502,["crc32"]=2126591035},{["file"]="bundles.29.nxa",["offset"]=160960,["size"]=32,["crc32"]=2147408364},{["file"]="bundles.29.nxa",["offset"]=222840048,["size"]=19465,["crc32"]=3559163598},{["file"]="bundles.29.nxa",["offset"]=160992,["size"]=32,["crc32"]=628028550},{["file"]="bundles.29.nxa",["offset"]=222859520,["size"]=6428,["crc32"]=1148033243},{["file"]="bundles.29.nxa",["offset"]=161024,["size"]=32,["crc32"]=3368567158},{["file"]="bundles.29.nxa",["offset"]=222865952,["size"]=8393,["crc32"]=2859039368},{["file"]="bundles.29.nxa",["offset"]=161056,["size"]=32,["crc32"]=3306115882},{["file"]="bundles.29.nxa",["offset"]=222874352,["size"]=7051,["crc32"]=478862110},{["file"]="bundles.29.nxa",["offset"]=161088,["size"]=32,["crc32"]=1922729532},{["file"]="bundles.29.nxa",["offset"]=222881408,["size"]=13178,["crc32"]=1479091781},{["file"]="bundles.29.nxa",["offset"]=161120,["size"]=32,["crc32"]=4199803494},{["file"]="bundles.29.nxa",["offset"]=222894592,["size"]=10453,["crc32"]=3643822593},{["file"]="bundles.29.nxa",["offset"]=161152,["size"]=32,["crc32"]=2117223262},{["file"]="bundles.29.nxa",["offset"]=222905056,["size"]=7086,["crc32"]=4255684149},{["file"]="bundles.29.nxa",["offset"]=161184,["size"]=32,["crc32"]=158770663},{["file"]="bundles.29.nxa",["offset"]=222912144,["size"]=6969,["crc32"]=2945146914},{["file"]="bundles.29.nxa",["offset"]=161216,["size"]=32,["crc32"]=223901626},{["file"]="bundles.29.nxa",["offset"]=222919120,["size"]=8731,["crc32"]=2825257195},{["file"]="bundles.29.nxa",["offset"]=161248,["size"]=32,["crc32"]=341122649},{["file"]="bundles.29.nxa",["offset"]=222927856,["size"]=8810,["crc32"]=2958245406},{["file"]="bundles.29.nxa",["offset"]=161280,["size"]=32,["crc32"]=4251428711},{["file"]="bundles.29.nxa",["offset"]=222936672,["size"]=9945,["crc32"]=986576780},{["file"]="bundles.29.nxa",["offset"]=161312,["size"]=32,["crc32"]=3529224739},{["file"]="bundles.29.nxa",["offset"]=222946624,["size"]=8740,["crc32"]=1805043139},{["file"]="bundles.29.nxa",["offset"]=161344,["size"]=32,["crc32"]=2257222461},{["file"]="bundles.29.nxa",["offset"]=222955376,["size"]=11369,["crc32"]=706768765},{["file"]="bundles.29.nxa",["offset"]=161376,["size"]=32,["crc32"]=1216155637},{["file"]="bundles.29.nxa",["offset"]=222966752,["size"]=7019,["crc32"]=123117305},{["file"]="bundles.29.nxa",["offset"]=161408,["size"]=32,["crc32"]=3398898461},{["file"]="bundles.29.nxa",["offset"]=222973776,["size"]=10090,["crc32"]=192851079},{["file"]="bundles.29.nxa",["offset"]=161440,["size"]=32,["crc32"]=2983393904},{["file"]="bundles.29.nxa",["offset"]=222983872,["size"]=11090,["crc32"]=2479974300},{["file"]="bundles.29.nxa",["offset"]=161472,["size"]=32,["crc32"]=1807307214},{["file"]="bundles.29.nxa",["offset"]=222994976,["size"]=10731,["crc32"]=1271422014},{["file"]="bundles.29.nxa",["offset"]=161504,["size"]=32,["crc32"]=3141843787},{["file"]="bundles.29.nxa",["offset"]=223005712,["size"]=13832,["crc32"]=2202093004},{["file"]="bundles.29.nxa",["offset"]=161536,["size"]=32,["crc32"]=3174145755},{["file"]="bundles.29.nxa",["offset"]=223019552,["size"]=13557,["crc32"]=1576961679},{["file"]="bundles.29.nxa",["offset"]=161568,["size"]=32,["crc32"]=1997443845},{["file"]="bundles.29.nxa",["offset"]=223033120,["size"]=9687,["crc32"]=1939682161},{["file"]="bundles.29.nxa",["offset"]=161600,["size"]=32,["crc32"]=4220431269},{["file"]="bundles.29.nxa",["offset"]=223042816,["size"]=9547,["crc32"]=3378886795},{["file"]="bundles.29.nxa",["offset"]=161632,["size"]=32,["crc32"]=3080895759},{["file"]="bundles.29.nxa",["offset"]=223052368,["size"]=8912,["crc32"]=3827968682},{["file"]="bundles.29.nxa",["offset"]=161664,["size"]=32,["crc32"]=3542432780},{["file"]="bundles.29.nxa",["offset"]=223061280,["size"]=6226,["crc32"]=3489855060},{["file"]="bundles.29.nxa",["offset"]=161696,["size"]=32,["crc32"]=2133269466},{["file"]="bundles.29.nxa",["offset"]=223067520,["size"]=8159,["crc32"]=3223411340},{["file"]="bundles.29.nxa",["offset"]=161728,["size"]=32,["crc32"]=1545965428},{["file"]="bundles.29.nxa",["offset"]=223075680,["size"]=8496,["crc32"]=2694176967},{["file"]="bundles.29.nxa",["offset"]=161760,["size"]=32,["crc32"]=3725938759},{["file"]="bundles.29.nxa",["offset"]=223084176,["size"]=6858,["crc32"]=2368757452},{["file"]="bundles.29.nxa",["offset"]=161792,["size"]=32,["crc32"]=591086859},{["file"]="bundles.29.nxa",["offset"]=223091040,["size"]=11414,["crc32"]=1427725240},{["file"]="bundles.29.nxa",["offset"]=161824,["size"]=32,["crc32"]=2941205300},{["file"]="bundles.29.nxa",["offset"]=223102464,["size"]=8328,["crc32"]=1017230479},{["file"]="bundles.29.nxa",["offset"]=161856,["size"]=32,["crc32"]=211827282},{["file"]="bundles.29.nxa",["offset"]=223110800,["size"]=7711,["crc32"]=1976463385},{["file"]="bundles.29.nxa",["offset"]=161888,["size"]=32,["crc32"]=2293461439},{["file"]="bundles.29.nxa",["offset"]=223118512,["size"]=10299,["crc32"]=3610222412},{["file"]="bundles.29.nxa",["offset"]=161920,["size"]=32,["crc32"]=798453698},{["file"]="bundles.29.nxa",["offset"]=223128816,["size"]=11656,["crc32"]=522630868},{["file"]="bundles.29.nxa",["offset"]=161952,["size"]=32,["crc32"]=1450630181},{["file"]="bundles.29.nxa",["offset"]=223140480,["size"]=18272,["crc32"]=249689079},{["file"]="bundles.29.nxa",["offset"]=161984,["size"]=32,["crc32"]=2161048313},{["file"]="bundles.29.nxa",["offset"]=223158752,["size"]=26874,["crc32"]=2774898302},{["file"]="bundles.29.nxa",["offset"]=162016,["size"]=32,["crc32"]=238882710},{["file"]="bundles.29.nxa",["offset"]=223185632,["size"]=9857,["crc32"]=875745917},{["file"]="bundles.29.nxa",["offset"]=166976,["size"]=32,["crc32"]=1721684305},{["file"]="bundles.29.nxa",["offset"]=233594160,["size"]=13186,["crc32"]=1680587208}},["gait"]={["layer_count"]=31,["cycle_states"]={1,2,62,63,76,77,78,79,86,87,88,91},["exit_states"]={0,3,4,5,6,7,8,9,10,58,59,60,61,64,65,66,67,68,69,75,80,81,82,83,84,85,89,90,92,93},["safe_main_states"]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539,540,541,542,543,544,545,546,547,548,549,550,551,552,553,554,555,556,557,558,559,560,561,562,563,564,565,566,567,568,569,570,571,572,573,574,575,576,577,578,579,580,581,582,583,584,585,586,587,588,589,592,593,594,595,596,597,598,599,602,603,604,605,606,607,608,609,610,611,612,613,615,616,617,619,621,622,627,628,629,630,631,632,633,634,635,636,637,638,639,640,641,642,643,644,645,646,647,648,649,650,651,652,655,656,657,658,659,660,661,662,665,666,667,668,669,670,671,672,673,674,675,676,677,678,679,681,682,683,684,685,686,687,688,689,690,691,692,693,694,695,696,697,698,699,700,701,702,703,704,705,706,707,708,709,710,711,712,713,714,715,716,717,718,719,720,721,722,723,724,725,726,727,728,729,730,731,732,733,734,735,736,737,738,739,740,741,742,743,744,745,746,747,748,749,750,751,752,753,754,755,756,757,758,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775,776,777,778,779,780,781,782,783,784,785,786,787,788,789,790,791,792,793,794,795,796,797,798,799,800,801,802,803,804,805,806,807,808,809,810,811,812,813,814,815},["main_layer"]=11,["menu_layer"]=4,["menu_states"]={76,77},["speed_variable"]="move_speed",["angle_variable"]="move_angle",["ship_cycle_states"]={1,2},["ship_empty_upper_states"]={76,77},["ship_main_empty"]=585},["holding"]={["layer"]=4,["state"]=59,["main_layer"]=11,["main_empty"]=585,["variable"]="weapon_selected",["name_hash"]="6781754482227844046",["animations"]={"8778887611748987","947445316358919592","8778887611748987","17402224972765070252","10979098471354773629","7062954187811788555","2096303666159990251","437075922768061644","16650915186147380609","7037241561463763509","15158359588407698031","17181683526039706920","6587153277640111597","17933107723877606164","14735842673613115829","6644345261525702099","5591156915164872767","15043445467830100849","17602411894416173014","14144853689640404990","18270605935700749701"},["source_expression_sha256"]="413051ffcf2de90eed4c503b77b548ff7eb29aee8d497c011d1e112e6f2b97b0",["scope"]="Observed native weapon-pose branch only; unknown main actions are not holding.",["lowered"]={["base_layer"]=1,["base_state"]=59,["weapon_layer"]=3,["weapon_states"]={66,67},["layer"]=4,["state"]=67,["evidence"]={{["layer"]=1,["state"]=59,["name_hash"]="10750769400907583795",["blend_mask_index"]=16,["animations"]={"8474657564533102288"}},{["layer"]=3,["state"]=66,["name_hash"]="14071496088518784375",["blend_mask_index"]=72,["animations"]={"1797067629625919901","11481670020133416633","1797067629625919901","11332630966000547982","14114742351602978995","6544321667396176029","6489647569345731420","2123936336564334695"},["source_expression_sha256"]="d5c37dc93f4778053f348c93cd5ba33e8d6ade4521c2408aeb7027f581bb591c"},{["layer"]=3,["state"]=67,["name_hash"]="3112439263510690167",["blend_mask_index"]=38,["animations"]={"1797067629625919901","3419387356875477622","17968617281938693792","12222639308032615688","15711007345106524978","17603218707377282701","4961741789475937163","11332630966000547982","14114742351602978995","12342770143850273221","7314149125004938692","16184482018825463968","4145077395558195672","4034574289414790394","5007672140766539606","5279455255826944244","8223516067945264816"},["source_expression_sha256"]="e71e02f8147e22d7b8853f82369073eb3a7755bc37adf73858de41374873b3bc"},{["layer"]=4,["state"]=67,["name_hash"]="9742279138117260644",["blend_mask_index"]=4294967295,["animations"]={}},{["layer"]=11,["state"]=585,["name_hash"]="14871095612366587540",["blend_mask_index"]=4294967295,["animations"]={}}},["scope"]="Observed standing lowered-weapon posture only; not movement, menu or unknown main actions.",["moving"]={["pairs"]={{["base_state"]=60,["weapon_states"]={66,67}},{["base_state"]=61,["weapon_states"]={69}},{["base_state"]=62,["weapon_states"]={69}},{["base_state"]=63,["weapon_states"]={69}},{["base_state"]=64,["weapon_states"]={66,67}},{["base_state"]=65,["weapon_states"]={66,67}},{["base_state"]=78,["weapon_states"]={71}},{["base_state"]=79,["weapon_states"]={71}},{["base_state"]=80,["weapon_states"]={70}}},["evidence"]={{["layer"]=1,["state"]=60,["name_hash"]="6279613346245738420",["blend_mask_index"]=47,["animations"]={"14921418194918748591","12077799961743137058","3586936218730106199","2344257111654188809"}},{["layer"]=1,["state"]=61,["name_hash"]="12941966778085164537",["blend_mask_index"]=47,["animations"]={"404260333466794186","14367716196231703064","11184640513437482309","12942793904972006299","13296214718053656506"}},{["layer"]=1,["state"]=62,["name_hash"]="4957260806934223634",["blend_mask_index"]=4294967295,["animations"]={"14870562153802622361","8958390548417319837","1122443865040831978","18155868897900355102","15226963369279718671","9451506194983016359","9569947707315173233","11101042682009661715","14208653658175149215"}},{["layer"]=1,["state"]=63,["name_hash"]="14954129355925305825",["blend_mask_index"]=4294967295,["animations"]={"4302498648177064892","2855924516317402099","13661916876549315316","9569947707315173233","9451506194983016359","5481209417149267066","17348760507053463413","15797059602253823574","18218406328322725785"}},{["layer"]=1,["state"]=64,["name_hash"]="14236731749642753717",["blend_mask_index"]=47,["animations"]={"8957640587398542022","9399414926241819310","14684683350877870864","10986091998153543653","1845374511027491328"}},{["layer"]=1,["state"]=65,["name_hash"]="16655646417843356046",["blend_mask_index"]=47,["animations"]={"13373265819562601893","11333773761751473607","8187936784190044264","7453271572804177518","2619642181483281538"}},{["layer"]=1,["state"]=78,["name_hash"]="7867213580165360275",["blend_mask_index"]=4294967295,["animations"]={"1122443865040831978","10881169329784455043","8958390548417319837","11101042682009661715","14208653658175149215","9451506194983016359","9569947707315173233","4928390151762733173","6988994824940484509"}},{["layer"]=1,["state"]=79,["name_hash"]="12553809338533555841",["blend_mask_index"]=4294967295,["animations"]={"18250583294428307555","13661916876549315316","2855924516317402099","630641967620182282","13765229851222828967","17348760507053463413","5481209417149267066","15797059602253823574","18218406328322725785"}},{["layer"]=1,["state"]=80,["name_hash"]="403044778184657426",["blend_mask_index"]=47,["animations"]={"866496412919042478","4662482796386559995","13063405065097536866","10583892554383876649","15669766621273490491"}},{["layer"]=3,["state"]=69,["name_hash"]="2220601617365627069",["blend_mask_index"]=38,["animations"]={"13561384166521644701","6690025164183281809","3415521438537803243","9984780905167678853","5285237422585842174","13077805435769185174","3658049763049871017","10310214131303638176","10291820612025928246","7647872922730750443","654377067942275561","6149180015345016175","16488249332045540410","14873146574928020687","4207326977101996381"},["source_expression_sha256"]="948ef4e1599388668c0a230375f7c2af5e7bfa26ffae3a791ab4350f46d0a7e9"},{["layer"]=3,["state"]=70,["name_hash"]="11498235198031602177",["blend_mask_index"]=38,["animations"]={"14452104032119072430","7619741215357355105","16128834009455170114","7982418532633411632","7314099005397567190","5320118592793924766","6446342405383112714","6377414350937116810","10279280990023295825","3257677034589202461","7621693888217454790","3056090205637458266","5994842317906429889","6117927810805635175","6258356866418483637"},["source_expression_sha256"]="240f3b1bb1807e8700b4986817e072807dd72398d90f82d34ce1ca1edaf881be"},{["layer"]=3,["state"]=71,["name_hash"]="6769162863668086906",["blend_mask_index"]=38,["animations"]={"17320838251264089141","15831961852404770198","17233194964823199076","3161440146531849744","11515344750505471347","2942887748770638429","17604929478434961677","4188736158819132326","11055081662577409824","3865407278526328015","5709999822320597295","16133468699240159462","6780128749234853980"},["source_expression_sha256"]="05ad4499389cce38e4876e2e68490071c66a35d175d7bc752542c5100ed136fd"}},["scope"]="Source-bound moving/turning weapon postures; no unknown main actions or menu idle."}},["general"]={["layer3"]={{["state"]=1,["variables"]={14},["name_hash"]="8933592626221174471",["expression_sha256"]="875c62faceddf67349486aac7479a9e4e5d8d2b93e1d0531a2e0e96fbabc4aa7"},{["state"]=2,["variables"]={14},["name_hash"]="12112859289686991122",["expression_sha256"]="875c62faceddf67349486aac7479a9e4e5d8d2b93e1d0531a2e0e96fbabc4aa7"},{["state"]=3,["variables"]={14},["name_hash"]="1001010762602313668",["expression_sha256"]="77dc56ea344c69c95d9a4acf0ff0543e20a65941492ecf5bcac6ade8d198645f"},{["state"]=4,["variables"]={14},["name_hash"]="11566483812264891072",["expression_sha256"]="19f4f8118c40e1484eefa8e7029d855263fb907c33ab3fc705fa1f7baa162398"},{["state"]=5,["variables"]={14,42},["name_hash"]="13477319899962536101",["expression_sha256"]="7f997dbe442fa2660ac5b8a435c3e3129259edf4698c15e97035ab6a463ea66a"},{["state"]=6,["variables"]={14,42},["name_hash"]="5015389186700807875",["expression_sha256"]="911f5e4f8de1dded69f6fa280b20f5a6b2c322aff3f63ce3c84d666e8aff56b0"},{["state"]=7,["variables"]={14},["name_hash"]="9279786348170223077",["expression_sha256"]="6b27b63284bbae1695291ce378641ac0a66b1c15db7b842e95c8c2a23b4ef280"},{["state"]=10,["variables"]={14},["name_hash"]="10342565069284629629",["expression_sha256"]="b759073b9634307036d20ab14675402bc3fef6105a34f10664c1192d11a41fc3"},{["state"]=11,["variables"]={14},["name_hash"]="9435238883543941682",["expression_sha256"]="3f97142697c72ec1ad4c5c6158229a021f387ad9ec51dce6c242b487ef083d67"},{["state"]=13,["variables"]={1,14},["name_hash"]="10012526055424621496",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=14,["variables"]={1,14},["name_hash"]="7796375345027839139",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=15,["variables"]={1,14},["name_hash"]="4691874871709161973",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=16,["variables"]={14,35},["name_hash"]="16440145578663653561",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=17,["variables"]={14,35},["name_hash"]="11842840139410730903",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=18,["variables"]={14,35},["name_hash"]="670984706018123873",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=19,["variables"]={14,35},["name_hash"]="11280714068129723056",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=20,["variables"]={14,35},["name_hash"]="16969432656727905151",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=21,["variables"]={14,35},["name_hash"]="5865590393539079278",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=22,["variables"]={14,35},["name_hash"]="8222861069330481725",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=23,["variables"]={14,35},["name_hash"]="4726122398094651757",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=24,["variables"]={14,35},["name_hash"]="10434755794535294651",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=25,["variables"]={14,35},["name_hash"]="14298566840214035067",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=26,["variables"]={14,35},["name_hash"]="1566095011751002295",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=27,["variables"]={14,35},["name_hash"]="3759348941047873693",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=28,["variables"]={14,35},["name_hash"]="6563324789730139019",["expression_sha256"]="eec390f6a89e13e90be7b662881291ae195e671b136f4d22bcdd6e535616b307"},{["state"]=29,["variables"]={14,35},["name_hash"]="2661072001155793274",["expression_sha256"]="798e1b8f9c8f011e5814f19c7f96e8c4c369ac2bca1dd8c77c113cfb6b8fd776"},{["state"]=30,["variables"]={1,14},["name_hash"]="14353073366469091138",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=31,["variables"]={1,14},["name_hash"]="17299662306596022725",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=32,["variables"]={1,14},["name_hash"]="9376746810399482110",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=33,["variables"]={1,14},["name_hash"]="17727689348094398820",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=34,["variables"]={1,14},["name_hash"]="14450860553000331305",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=35,["variables"]={1,14},["name_hash"]="16202852330443254305",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=36,["variables"]={1,14},["name_hash"]="4825180704227487241",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=37,["variables"]={1,14},["name_hash"]="13716792019060395845",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=38,["variables"]={1,14},["name_hash"]="11775337918229107405",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=39,["variables"]={1,14},["name_hash"]="1501795528268943876",["expression_sha256"]="86ef1a7d359461c0c6e4711de52a0e30f654f86aef275347f6bd39c2cf2f3539"},{["state"]=40,["variables"]={1,14},["name_hash"]="5680545606573715223",["expression_sha256"]="5a243d930addcbe9211c675ca1abc253fc7411bef7f77941ea5a5bb9b623b619"},{["state"]=41,["variables"]={14,35},["name_hash"]="14723446420755701045",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=42,["variables"]={14,35},["name_hash"]="4099493067930475804",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=43,["variables"]={14,35},["name_hash"]="12861986773894424943",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=44,["variables"]={14,35},["name_hash"]="10716000231728193421",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=45,["variables"]={14,35},["name_hash"]="13872418380558172018",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=46,["variables"]={14,35},["name_hash"]="14308451531053082775",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=47,["variables"]={14,35},["name_hash"]="10106208758582366088",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=48,["variables"]={14,35},["name_hash"]="14644281047788082348",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=49,["variables"]={14,35},["name_hash"]="9479848694248442193",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=50,["variables"]={14,35},["name_hash"]="13756412102488935282",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=51,["variables"]={14,35},["name_hash"]="6325257720624818688",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=52,["variables"]={14,35},["name_hash"]="10845934884654982075",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=53,["variables"]={14,35},["name_hash"]="16739456152742096439",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=54,["variables"]={14,35},["name_hash"]="17648153934204956415",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=55,["variables"]={14,35},["name_hash"]="5016498797026667159",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=56,["variables"]={14,35},["name_hash"]="7338855568273331338",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=57,["variables"]={14,35},["name_hash"]="3277529912372239070",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=58,["variables"]={14,35},["name_hash"]="12737297580256401332",["expression_sha256"]="ec224e06b479490c7f07ad2f8b2203cc9bb66ba5df952476ec3387b95ead131f"},{["state"]=60,["variables"]={14},["name_hash"]="1430375371096862901",["expression_sha256"]="6f87398aef205af383543b90f1567f1f04c7a6395299600787ae9e3b2b596d5f"},{["state"]=61,["variables"]={14},["name_hash"]="9051551098024936346",["expression_sha256"]="6f87398aef205af383543b90f1567f1f04c7a6395299600787ae9e3b2b596d5f"},{["state"]=62,["variables"]={14},["name_hash"]="13860791149769785412",["expression_sha256"]="e5a085e0696baea5facd40f1a9ce6016bea32de744a6060615323234f2632440"},{["state"]=63,["variables"]={14},["name_hash"]="3489884824004805421",["expression_sha256"]="e5a085e0696baea5facd40f1a9ce6016bea32de744a6060615323234f2632440"},{["state"]=64,["variables"]={14},["name_hash"]="13172630152284440821",["expression_sha256"]="e5a085e0696baea5facd40f1a9ce6016bea32de744a6060615323234f2632440"},{["state"]=65,["variables"]={14},["name_hash"]="725940416032934326",["expression_sha256"]="742e9ad82666f7f268ec5c9fafbbbd2fe4ec4d83b14d608e49c693ba18467b72"},{["state"]=66,["variables"]={14},["name_hash"]="14071496088518784375",["expression_sha256"]="d5c37dc93f4778053f348c93cd5ba33e8d6ade4521c2408aeb7027f581bb591c"},{["state"]=67,["variables"]={14},["name_hash"]="3112439263510690167",["expression_sha256"]="e71e02f8147e22d7b8853f82369073eb3a7755bc37adf73858de41374873b3bc"},{["state"]=68,["variables"]={14},["name_hash"]="16652685637389343470",["expression_sha256"]="ade4811054f78a5e37a45092a88f90500e866b0be05fdac8f04b2288b1299895"},{["state"]=69,["variables"]={14},["name_hash"]="2220601617365627069",["expression_sha256"]="948ef4e1599388668c0a230375f7c2af5e7bfa26ffae3a791ab4350f46d0a7e9"},{["state"]=70,["variables"]={14},["name_hash"]="11498235198031602177",["expression_sha256"]="240f3b1bb1807e8700b4986817e072807dd72398d90f82d34ce1ca1edaf881be"},{["state"]=71,["variables"]={14},["name_hash"]="6769162863668086906",["expression_sha256"]="05ad4499389cce38e4876e2e68490071c66a35d175d7bc752542c5100ed136fd"}},["layer4"]={{["state"]=0,["variables"]={14},["name_hash"]="5984687444231610937",["expression_sha256"]="8067826138c0376aceec53f5cc62f25370a1f36ec4afb6730fd40d86c6a14705"},{["state"]=1,["variables"]={14},["name_hash"]="7661479179802000646",["expression_sha256"]="6209d3421f8f6aec113760606b8d950b4c58b0ef74b5d49486a3a43a0f19fda8"},{["state"]=2,["variables"]={14,35},["name_hash"]="3062430443020083652",["expression_sha256"]="e29c5bcf2fe8fbe0e53f1bef490df2bc89e8561d5d88846fc80ca2c7129487e4"},{["state"]=3,["variables"]={14,35},["name_hash"]="10326006452218495822",["expression_sha256"]="e917e6ccd9314921067304bb9dc55c2645761aec8e8c432de392de0ece1b85af"},{["state"]=4,["variables"]={14,35},["name_hash"]="1892082373042465970",["expression_sha256"]="d78cf3a384fb6c453ac6433dc0b47b87cbba55025fde6cbb282307ed32d90744"},{["state"]=5,["variables"]={14,35},["name_hash"]="1858278654762057932",["expression_sha256"]="36f82616e09eb13d2bbd34b7c4bc42951ce117323d57e1ad7ac16792a409335e"},{["state"]=6,["variables"]={14,35},["name_hash"]="8918604678623657255",["expression_sha256"]="3bc8d8f163c1a72475b6652fa086a6153ea048b3e6c820cd29ccd67225e94ce6"},{["state"]=7,["variables"]={14,35},["name_hash"]="16967567141763151525",["expression_sha256"]="6dfe7db474c4869c7af5e211b551a3f642ed059ebb44199c7a0d237eb1a9e061"},{["state"]=11,["variables"]={14},["name_hash"]="2718642975406268841",["expression_sha256"]="8067826138c0376aceec53f5cc62f25370a1f36ec4afb6730fd40d86c6a14705"},{["state"]=12,["variables"]={14},["name_hash"]="2773974403829881463",["expression_sha256"]="6209d3421f8f6aec113760606b8d950b4c58b0ef74b5d49486a3a43a0f19fda8"},{["state"]=17,["variables"]={14},["name_hash"]="3129771896835369220",["expression_sha256"]="b014636255b371cb222e65e24b67ca34a03a430c4e25a8de049921385dfc09fd"},{["state"]=19,["variables"]={14},["name_hash"]="955433074219655387",["expression_sha256"]="a50a41197391b0bfc742a6dcf58040ecca30c204e0d3e7715aef373b603e16d8"},{["state"]=20,["variables"]={14},["name_hash"]="17450240982354757985",["expression_sha256"]="b9b4037b0ced46db7e0afdd40153bd4e08150cecdfa2bdfd71c4d4a2410a599c"},{["state"]=21,["variables"]={14},["name_hash"]="16355334968415536174",["expression_sha256"]="33e82bfe0d882420e632bd3fb82bfc6eb6544470d15bea91a55ac4a0687ae3dd"},{["state"]=22,["variables"]={14},["name_hash"]="10578812628052198447",["expression_sha256"]="55ae71836a53fb75b3d8ef19ebe972eaf94d08476155b1a90788f4cbdd226f87"},{["state"]=23,["variables"]={14,35},["name_hash"]="7561951245960229026",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=24,["variables"]={14,35},["name_hash"]="16420214127508215212",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=25,["variables"]={14,35},["name_hash"]="9559500747716490546",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=26,["variables"]={14,35},["name_hash"]="13464468861400076082",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=27,["variables"]={14,35},["name_hash"]="5007846204831410657",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=28,["variables"]={14,35},["name_hash"]="3048229875979843614",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=29,["variables"]={14,35},["name_hash"]="15262582597663127148",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=30,["variables"]={14,35},["name_hash"]="16426701604533648797",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=31,["variables"]={14,35},["name_hash"]="1935612941213615331",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=32,["variables"]={14,35},["name_hash"]="15871736414178434004",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=33,["variables"]={14,35},["name_hash"]="15508732505713042408",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=34,["variables"]={14,35},["name_hash"]="2925817896658521887",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=35,["variables"]={14,35},["name_hash"]="16905000893134360724",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=36,["variables"]={14,35},["name_hash"]="18110874170965127894",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=37,["variables"]={14,35},["name_hash"]="12678472763273309828",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=38,["variables"]={14,35},["name_hash"]="12063525022607251903",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=39,["variables"]={14,35},["name_hash"]="2868458878587544081",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=40,["variables"]={14,35},["name_hash"]="13526418291907948791",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=41,["variables"]={14,35},["name_hash"]="8643699059652088716",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=42,["variables"]={14,35},["name_hash"]="10366071191905801445",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=43,["variables"]={14,35},["name_hash"]="10931042960688550760",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=44,["variables"]={14,35},["name_hash"]="1647863922490913409",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=45,["variables"]={14,35},["name_hash"]="8670564704731629425",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=46,["variables"]={14,35},["name_hash"]="4006553347501566569",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=47,["variables"]={14,35},["name_hash"]="6188542050163065899",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=48,["variables"]={14,35},["name_hash"]="11048696241086236932",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=49,["variables"]={14,35},["name_hash"]="17403738434447201105",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=50,["variables"]={14,35},["name_hash"]="771791364895705379",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=51,["variables"]={14,35},["name_hash"]="828367297013235248",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=52,["variables"]={14,35},["name_hash"]="7597948233106968844",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=53,["variables"]={14,35},["name_hash"]="15041634616093598371",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=54,["variables"]={14,35},["name_hash"]="4818051289664299047",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=55,["variables"]={14,35},["name_hash"]="10871275564816672343",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=56,["variables"]={14,35},["name_hash"]="5465567711789973600",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=57,["variables"]={14,35},["name_hash"]="10821782533091336095",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=58,["variables"]={14,35},["name_hash"]="18020446105687779310",["expression_sha256"]="c2648e36c3c2491225d00b2c187fc062d340c2e405b0054bebd6321008e45700"},{["state"]=59,["variables"]={14},["name_hash"]="6781754482227844046",["expression_sha256"]="413051ffcf2de90eed4c503b77b548ff7eb29aee8d497c011d1e112e6f2b97b0"},{["state"]=60,["variables"]={14},["name_hash"]="12578185322197723209",["expression_sha256"]="9c80639dd76882c014621a81c6d0237090c7d86f7dc33f9a058dea86dcd9eb5a"},{["state"]=61,["variables"]={14,35},["name_hash"]="10979821357541124854",["expression_sha256"]="e29c5bcf2fe8fbe0e53f1bef490df2bc89e8561d5d88846fc80ca2c7129487e4"},{["state"]=62,["variables"]={14,35},["name_hash"]="4531496717832864754",["expression_sha256"]="53aebd8b707ac28cfcc2a308b96d9e2e06fd7a7cf4de86e4c432e8a859a71883"},{["state"]=63,["variables"]={14,35},["name_hash"]="8982220469405084208",["expression_sha256"]="a68d2a80bc990ea43aa8daa94985c0ae4512b75365a7ab3d2e0d9a2ee43dd072"},{["state"]=64,["variables"]={14,35},["name_hash"]="6450462250649718537",["expression_sha256"]="36f82616e09eb13d2bbd34b7c4bc42951ce117323d57e1ad7ac16792a409335e"},{["state"]=65,["variables"]={14,35},["name_hash"]="2889531448108370020",["expression_sha256"]="3bc8d8f163c1a72475b6652fa086a6153ea048b3e6c820cd29ccd67225e94ce6"},{["state"]=66,["variables"]={14,35},["name_hash"]="7195468546830278775",["expression_sha256"]="6dfe7db474c4869c7af5e211b551a3f642ed059ebb44199c7a0d237eb1a9e061"},{["state"]=70,["variables"]={14},["name_hash"]="8015275182792448185",["expression_sha256"]="f610d0a5423d4be98cca84b765aaabf5f30519fc1266f52498f2d2e9e28c078a"},{["state"]=71,["variables"]={14},["name_hash"]="17440861238371472814",["expression_sha256"]="9c80639dd76882c014621a81c6d0237090c7d86f7dc33f9a058dea86dcd9eb5a"}},["lowered_empty"]={8,18,67}}},["motion_grips"]={{["p"]={0.051216013729572296,-0.006265312433242798,-0.05556453391909599},["q"]={-0.5793707370758057,-0.4373212158679962,-0.44205304980278015,0.5269428491592407}},{["p"]={0.059206679463386536,-0.001960277557373047,-0.046801239252090454},["q"]={0.38654932379722595,0.4877331852912903,-0.6221314072608948,0.4750247895717621}}},["rows"]={{["layer"]=11,["state"]=475,["lengths"]={3.0833332538604736}},{["layer"]=11,["state"]=476,["lengths"]={2.25}},{["layer"]=11,["state"]=477,["lengths"]={3.3333332538604736}},{["layer"]=11,["state"]=478,["lengths"]={1.9166666269302368}},{["layer"]=11,["state"]=479,["lengths"]={2.5}},{["layer"]=11,["state"]=488,["lengths"]={3.0833332538604736}},{["layer"]=11,["state"]=489,["lengths"]={3.0833332538604736}},{["layer"]=11,["state"]=490,["lengths"]={2.25}},{["layer"]=11,["state"]=491,["lengths"]={2.25}},{["layer"]=11,["state"]=499,["lengths"]={3.3333332538604736}},{["layer"]=11,["state"]=500,["lengths"]={3.3333332538604736}},{["layer"]=11,["state"]=501,["lengths"]={2.1666667461395264}},{["layer"]=11,["state"]=502,["lengths"]={2.1666667461395264}},{["layer"]=11,["state"]=510,["lengths"]={2.8333332538604736}},{["layer"]=11,["state"]=511,["lengths"]={2.8333332538604736}},{["layer"]=11,["state"]=592,["lengths"]={3.0}},{["layer"]=11,["state"]=593,["lengths"]={2.0}},{["layer"]=11,["state"]=594,["lengths"]={2.0}},{["layer"]=11,["state"]=595,["lengths"]={3.0}},{["layer"]=11,["state"]=596,["lengths"]={3.6666667461395264}},{["layer"]=11,["state"]=597,["lengths"]={3.6666667461395264}},{["layer"]=11,["state"]=600,["lengths"]={4.983333110809326}},{["layer"]=11,["state"]=601,["lengths"]={4.166666507720947}},{["layer"]=11,["state"]=633,["lengths"]={3.0}},{["layer"]=11,["state"]=634,["lengths"]={3.5833332538604736}},{["layer"]=11,["state"]=635,["lengths"]={2.9166667461395264}},{["layer"]=11,["state"]=636,["lengths"]={1.8333333730697632}},{["layer"]=11,["state"]=637,["lengths"]={0.8333333134651184}},{["layer"]=11,["state"]=638,["lengths"]={0.6666666865348816}},{["layer"]=11,["state"]=639,["lengths"]={0.8333333134651184}},{["layer"]=11,["state"]=640,["lengths"]={0.5}},{["layer"]=11,["state"]=665,["lengths"]={1.75}},{["layer"]=11,["state"]=666,["lengths"]={1.75}},{["layer"]=11,["state"]=681,["lengths"]={3.0}},{["layer"]=11,["state"]=686,["lengths"]={0.6666666865348816}},{["layer"]=11,["state"]=687,["lengths"]={0.8333333134651184}},{["layer"]=11,["state"]=698,["lengths"]={3.1666667461395264}},{["layer"]=11,["state"]=699,["lengths"]={2.25}},{["layer"]=11,["state"]=700,["lengths"]={1.5}},{["layer"]=11,["state"]=701,["lengths"]={1.1666666269302368}},{["layer"]=11,["state"]=702,["lengths"]={1.5}},{["layer"]=11,["state"]=703,["lengths"]={1.1666666269302368}},{["layer"]=11,["state"]=704,["lengths"]={3.1666667461395264}},{["layer"]=11,["state"]=705,["lengths"]={3.1666667461395264}},{["layer"]=11,["state"]=706,["lengths"]={2.0}},{["layer"]=11,["state"]=707,["lengths"]={2.0}},{["layer"]=11,["state"]=725,["lengths"]={2.0}},{["layer"]=11,["state"]=732,["lengths"]={3.3333332538604736}},{["layer"]=11,["state"]=733,["lengths"]={2.1666667461395264}},{["layer"]=11,["state"]=744,["lengths"]={2.1666667461395264}},{["layer"]=11,["state"]=745,["lengths"]={1.5}},{["layer"]=11,["state"]=748,["lengths"]={2.1666667461395264}},{["layer"]=11,["state"]=749,["lengths"]={1.5}},{["layer"]=11,["state"]=767,["lengths"]={3.1666667461395264}},{["layer"]=11,["state"]=768,["lengths"]={2.25}},{["layer"]=11,["state"]=774,["lengths"]={3.5}},{["layer"]=11,["state"]=775,["lengths"]={2.0833332538604736}},{["layer"]=11,["state"]=799,["lengths"]={3.0}},{["layer"]=11,["state"]=800,["lengths"]={2.1666667461395264}}}}
    local function validate_source()
      if not catalog.source_slices or #catalog.source_slices==0 then return false end
      local bit = require("bit")
      local k32 = ffi.load("kernel32")
      local address = k32.GetProcAddress(k32.GetModuleHandleA("kernel32.dll"),"GetModuleFileNameA")
      if address==nil then return false end
      local filename = ffi.cast("unsigned (*)(void *, char *, unsigned)",address)
      local buffer = ffi.new("char[32768]")
      local count = tonumber(filename(nil,buffer,32768))
      if not count or count<=0 or count>=32768 then return false end
      local game = ffi.string(buffer,count):match("^(.*)[/\\][^/\\]+[/\\][^/\\]+$")
      if not game then return false end
      local table_crc={}
      for i=0,255 do
        local value=i
        for _=1,8 do value=bit.bxor(bit.rshift(value,1),bit.band(value,1)==1 and 0xedb88320 or 0) end
        table_crc[i]=value
      end
      local total=0
      for _,slice in ipairs(catalog.source_slices) do
        if not slice.file:match("^bundles%.%d%d%.nxa$") and not slice.file:match("^%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x$") then return false end
        total=total+slice.size
        if slice.size<=0 or slice.offset<0 or total>8*1024*1024 then return false end
        local file=io.open(game.."/data/"..slice.file,"rb")
        if not file then return false end
        local position=file:seek("set",slice.offset)
        local bytes=position and file:read(slice.size) or nil
        file:close()
        if not bytes or #bytes~=slice.size then return false end
        local crc=-1
        for i=1,#bytes do crc=bit.bxor(bit.rshift(crc,8),table_crc[bit.band(bit.bxor(crc,bytes:byte(i)),255)]) end
        if bit.bnot(crc)~=bit.tobit(slice.crc32) then return false end
      end
      return true
    end
    local success,valid=pcall(validate_source)
    local trusted=success and valid==true
    rawset(_G,"__hd2ir_tp_gait_catalog",trusted and catalog.gait or nil)
    log("TP contact catalog source_valid="..tostring(trusted).." enabled=weapon-posture-and-native-hand-motion")
    local by_state={}
    for _,row in ipairs(catalog.rows or {}) do
      if row.layer==11 then by_state[row.state]=row end
    end
    local weapon_layers={{},{},{}}
    for _,row in ipairs((catalog.holding.general or {}).layer3 or {}) do weapon_layers[1][row.state]=true end
    for _,row in ipairs((catalog.holding.general or {}).layer4 or {}) do weapon_layers[2][row.state]=true end
    for _,state in ipairs((catalog.holding.general or {}).lowered_empty or {}) do weapon_layers[3][state]=true end
    rawset(_G,"__hd2ir_tp_motion_grips",trusted and catalog.motion_grips or nil)
    rawset(_G,"__hd2ir_tp_singlehand_state",function(unit)
      if not trusted then return false end
      if not rawget(_G,"__hd2ir_animation_ready")(unit) then return false end
      local tuple={pcall(function() return U.animation_get_state(unit) end)}
      local hold=catalog.holding
      if not hold or not hold.lowered or not tuple[1] or #tuple~=catalog.layer_count+1 or
          tonumber(tuple[hold.main_layer+1])~=hold.main_empty or
          tonumber(tuple[5])==76 or tonumber(tuple[5])==77 then return false end
      -- Weapon ownership is checked separately. Use the same source-verified
      -- holding trees as contact dispatch, independent of the lower-body pair:
      -- running/turning and raised pistol/shield postures must not snap off.
      -- Reload/other main actions, FP, menus and unverified weapons stay out.
      local upper,weapon=tonumber(tuple[5]),tonumber(tuple[4])
      return weapon_layers[2][upper]==true or
          (weapon_layers[3][upper]==true and weapon_layers[1][weapon]==true)
    end)
    return function(unit)
      if not trusted then return 0,"tp-source-unverified" end
      if not rawget(_G,"__hd2ir_animation_ready")(unit) then return 0,"tp-animation-unavailable" end
      local tuple={pcall(function() return U.animation_get_state(unit) end)}
      if not tuple[1] or #tuple~=catalog.layer_count+1 then return 0,"tp-state-unavailable" end
      local row=by_state[tonumber(tuple[12])]
      if not row then
        local hold=catalog.holding
        if not hold then return 0,"tp-action-unclassified" end
        local upper=tonumber(tuple[5])
        if upper==76 or upper==77 then return 0,"tp-menu-pose" end
        local raised=weapon_layers[2][upper]
        local base=weapon_layers[1][tonumber(tuple[4])]
        if not raised and not base then return 0,"tp-action-unclassified" end
        local ok,weapon=pcall(function()
          if not U.animation_has_variable(unit,hold.variable) then return nil end
          return tonumber(U.animation_get_variable(unit,U.animation_find_variable(unit,hold.variable)))
        end)
        if not ok or not weapon or weapon~=weapon or weapon<=0 or weapon==math.huge then
          return 0,"tp-hold-variable-unavailable"
        end
        if tonumber(tuple[hold.main_layer+1])==hold.main_empty and (raised or weapon_layers[3][upper]) then
          return 1,"native-weapon-posture"
        end
        -- Unknown main actions are NOT holding/reload classifications. Follow
        -- each verified native HAND trajectory; never pin a releasing hand to
        -- the moving weapon attachment. Mode 2 is the native-motion IK pass.
        return 2,"native-hand-motion"
      end
      local ok,time,length=pcall(function() return U.animation_layer_info(unit,11) end)
      if not ok or type(time)~="number" or type(length)~="number" or
          time~=time or length~=length or time<0 or time>length+0.025 or length<=0 then
        return 0,"tp-clip-unavailable"
      end
      for _,expected in ipairs(row.lengths) do
        if math.abs(expected-length)<=0.005 then return 2,"verified-native-reload" end
      end
      return 0,"tp-clip-mismatch"
    end
  end)())


  --@@HOLDING_CONTACT_FRAME_BEGIN@@
  -- A held weapon's attachment origin need not be inside the hand. Long
  -- implements can attach at a root far along the shaft (captured hammer:
  -- 65--80 cm). Preserve normal palm-sized contacts exactly; smoothly use
  -- the proven native HAND trajectory when that helper is far outside the
  -- source-calibrated grip envelope. No weapon name, guessed offset or write.
  rawset(_G,"__hd2ir_holding_contact_frame",function(q,p,hand,grip)
    if not q or not p or not hand or not grip then return q,p,0 end
    local radius=math.sqrt(grip.p[1]^2+grip.p[2]^2+grip.p[3]^2)
    local distance=perror(p,hand.p)
    if radius~=radius or radius<0.000001 or radius==math.huge or
        distance~=distance or distance==math.huge then return nil,nil,0 end
    if distance<=3*radius then return q,p,0 end
    local hq,hp=compose_pose(hand.q,hand.p,grip.q,grip.p)
    if not hq or not hp then return nil,nil,0 end
    if distance>=4*radius then return hq,hp,1 end
    local t=(distance-3*radius)/radius
    t=t*t*(3-2*t)
    return qnlerp(q,hq,t),{p[1]+(hp[1]-p[1])*t,p[2]+(hp[2]-p[2])*t,p[3]+(hp[3]-p[3])*t},t
  end)
  --@@HOLDING_CONTACT_FRAME_END@@

  -- Reuse the graph/ownership proof from the generic weapon transaction.
  rawset(_G,"__hd2ir_singlehand_weapon",function(world,binding,contacts,mask)
    if (mask~=1 and mask~=3) or not pose_capture.local_third_person(binding.avatar) or
        not rawget(_G,"__hd2ir_tp_singlehand_state")(binding.avatar.unit) then return false end
    local trial=rawget(_G,"__hd2ir_weapon_root_trial")
    local chosen=trial and trial.find_owned(world,binding,contacts,mask)
    -- Whole-weapon eligibility is broader than the legacy free-hand solver.
    -- Never send a supported two-hand primary through the single-hand fallback.
    return chosen and (chosen.spec.sidearm or (mask==3 and chosen.left and not chosen.possible_support)) or false
  end)


  --@@WHOLE_WEAPON_TRIAL_BEGIN@@
  -- Hold the native weapon graph through the engine's late render consumption;
  -- restore with fresh handles before the next update (or repeated render).
  -- This is an explicit experiment, not proven renderer/ballistics isolation.
  rawset(_G,"__hd2ir_weapon_root_trial",(function()
    local plans,logged={},{}
    local pending={}
    local disabled=false
    local trial={}
    local epoch=0
    -- Generated package membership is a lookup hint, NOT attachment ownership.
    -- No magazine offset/pose is authored here. Real child roots must recover
    -- a current parent frame, then respond to their OWN update_unit call.
    local packages={["03e67a19b07c6523"]={["path"]="content/fac_helldivers/equipment/primary_weapons/marksman_rifle_vigilance/marksman_rifle_vigilance",["sidearm"]=false,["count"]=38,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","17ec6d00","shadow_mesh","2c65a6c2","cb546116","4e9ae4f2","3204b291","skeleton","root","boss","IK_right","IK_left","sight","cog","attach_muzzle","attach_underbarrel","attach_optic","fire_selector","dust_cover","mag_release","bolt_handle","attach_paintjob","attach_ammo","attach_mag","ejector","bolt","collision","c_bodycollisionbot","00a7f137","b8de7a43","game_mesh","3ecdc95a","23793ff5","525177d7","de374642","4bd67a74","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,27,27,27,2,31,31,31,31,31,14},["members"]={{["hash"]="03e67a19b07c6523",["count"]=38},{["hash"]="07d605bd50c98461",["count"]=16},{["hash"]="44a2a59ca08ac865",["count"]=12},{["hash"]="642f2be0417d0beb",["count"]=15},{["hash"]="6d54652ee217d712",["count"]=12},{["hash"]="6e68194b95d60145",["count"]=38},{["hash"]="7b153e02ad22d12c",["count"]=12},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="9b30d4ac39ddff10",["count"]=16},{["hash"]="bd4245dcfd4b832f",["count"]=11},{["hash"]="bdbefa6543a75942",["count"]=22},{["hash"]="e5796355a8fd67e0",["count"]=39}}},["05d8d8c073b9d502"]={["path"]="content/fac_helldivers/equipment/primary_weapons/pump_shotgun_plasma/pump_shotgun_plasma",["sidearm"]=false,["count"]=51,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","2ab44c21","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_right","acb10a6a","493514d1","86dd3fb2","7d8a61e7","e85c3034","9111ef9b","18094134","pylons_r","pylons_l","attach_optic","attach_mag","cog","sight","ejector","mag_l","9236ee9a","mag_r","80238eb6","attach_muzzle","5f0e5b37","attach_paintjob","attach_ammo","pump","attach_underbarrel","IK_left","fire_selector","bolt","collision","c_culling","0bf48bf9","5dd2c3c7","8755602b","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,26,10,28,10,10,10,10,10,34,34,10,10,2,39,39,39,39,2,44,44,44,44,44,23},["members"]={{["hash"]="05d8d8c073b9d502",["count"]=51},{["hash"]="0c7314742b88806c",["count"]=13},{["hash"]="aca180fc6f846411",["count"]=12},{["hash"]="f9df21c8e52cac95",["count"]=13},{["hash"]="fa6f926a77b78b55",["count"]=12}},["support_envelope"]={["min"]={0.22358697652816772,0.055989187210798264,-0.20172667503356934},["max"]={0.36009639501571655,0.07182314991950989,-0.17793063819408417}}},["05e4e5c2db6e44a2"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/standard_pistol/standard_pistol",["sidearm"]=true,["count"]=33,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","1245b39c","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","attach_underbarrel","IK_right","cog","IK_left","sight","attach_ammo","attach_optic","attach_muzzle","attach_paintjob","ejector","attach_mag","slide","collision","5be474d2","b4afc5cb","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,2,23,23,2,26,26,26,26,26,13},["members"]={{["hash"]="05e4e5c2db6e44a2",["count"]=33},{["hash"]="0ec5ef9ec5cbd1b2",["count"]=5},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="4851d75853622a47",["count"]=15},{["hash"]="4e4a613eb9bf5c24",["count"]=38},{["hash"]="4f839e923046e631",["count"]=15},{["hash"]="52071f49263415e4",["count"]=35},{["hash"]="6b88fea13ec2d78e",["count"]=12},{["hash"]="6b9572ac0f687394",["count"]=6},{["hash"]="77c5d934407114f4",["count"]=17},{["hash"]="8d3d52a3b2f19402",["count"]=60},{["hash"]="9dbc8aa8702ac9e1",["count"]=12},{["hash"]="b5b4395852e871bc",["count"]=6},{["hash"]="b96cc3b704a76464",["count"]=7},{["hash"]="e6b6467135035059",["count"]=13},{["hash"]="e71dbcb6a50f321b",["count"]=158}}},["076dd5d4f4360204"]={["path"]="content/fac_helldivers/equipment/primary_weapons/arc_shotgun/arc_shotgun",["sidearm"]=false,["count"]=32,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","6ffa5ff8","shadow_mesh","ffa550d1","2d609a2a","bcb739b8","55cfee0e","collision","c_culling","5dd2c3c7","8755602b","skeleton","root","boss","IK_right","attach_optic","jiggle_r","jiggle_l","spinner","cog","sight","attach_muzzle","attach_paintjob","pump","IK_left","game_mesh","2b8b7864","5bcbf200","87b462cd","801bf616","ef9c303a"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,2,12,13,14,14,14,14,14,14,14,14,14,14,24,2,26,26,26,26,26},["members"]={{["hash"]="076dd5d4f4360204",["count"]=32},{["hash"]="9dbc8aa8702ac9e1",["count"]=12},{["hash"]="e307b6e78b0a8573",["count"]=3}},["support_envelope"]={["min"]={0.360684335231781,0.015368280932307243,-0.15026862919330597},["max"]={0.47100913524627686,0.015907561406493187,-0.14022578299045563}}},["0b882808c6f498e8"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/caustic_dart_gun/caustic_dart_gun",["sidearm"]=true,["count"]=39,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","206e03f2","shadow_mesh","039fd510","4fed0806","0297cddc","86ed065a","collision","c_collision","skeleton","root","boss","IK_left","cog","sight","IK_right","attach_paintjob","attach_muzzle","attach_underbarrel","attach_optic","latch","ammo_swivel","attach_mag","ammo","bullet_scale_1","bullet_scale_2","bullet_scale_3","bullet_scale_4","bullet_scale_5","bullet_scale_6","stock","trigger","game_mesh","b6ebac0e","db2a95c4","ee5ed7ad","e3632b3d","a65bb60f"},["parents"]={0,0,1,2,3,3,3,3,2,8,2,10,11,12,12,12,12,12,12,12,12,12,12,22,22,24,24,24,24,24,24,12,12,2,33,33,33,33,33},["members"]={{["hash"]="0b882808c6f498e8",["count"]=39},{["hash"]="45be635fb904f4dc",["count"]=12},{["hash"]="7441b048b94491fc",["count"]=12},{["hash"]="bb8e970248330bdb",["count"]=12},{["hash"]="e2177e205d9a7a55",["count"]=26},{["hash"]="e98a9be765e0e236",["count"]=5}}},["0f83639ab8c86165"]={["path"]="content/fac_helldivers/equipment/primary_weapons/battle_rifle_ceremonial/battle_rifle_ceremonial",["sidearm"]=false,["count"]=50,["root"]=15,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","67d74e5b","8e6b565d","a229de6a","c798fb67","df7eff82","64ad879d","f7ad6ed5","0f800be2","f0c04a84","dddb0eb7","42db3f18","af6dd1c0","cc092e72","a523bf82","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","attach_muzzle","fireselector","bolt_extender","bolt","mag_release","attach_mag","trigger","attach_optic","IK_left","IK_right","attach_paintjob","attach_ammo","ejector","cog","sight","5949a6e1","attach_underbarrel","barrel","collision","c_body","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body"},["parents"]={0,0,1,2,3,4,5,4,7,4,9,4,11,4,13,1,15,16,16,16,16,15,21,22,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,15,42,15,44,44,44,44,44},["members"]={{["hash"]="0f83639ab8c86165",["count"]=50},{["hash"]="44a2a59ca08ac865",["count"]=12},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="89cce4d15db88aa8",["count"]=16},{["hash"]="a9a19cffe985c468",["count"]=12},{["hash"]="bf9504e95c0103a1",["count"]=12}}},["11ec8e2296a3d662"]={["path"]="content/fac_helldivers/equipment/primary_weapons/pump_shotgun_02/pump_shotgun_02",["sidearm"]=false,["count"]=74,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","f3375c08","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","collision","c_culling","5dd2c3c7","8755602b","skeleton","root","boss","attach_optic","attach_muzzle","IK_right","acb10a6a","493514d1","86dd3fb2","7d8a61e7","e85c3034","9111ef9b","18094134","cog","sight","ejector","mag_l","9236ee9a","mag_r","80238eb6","eject_hatch","5f0e5b37","attach_paintjob","attach_ammo","feed_hatch_r","feed_hatch_l","mag_r_follower","f616be64","cb85f6fe","8cce08a0","610a417c","36797a16","315b8a8e","ab33b01a","fc9deaaa","mag_l_follower","9e7f8ad1","20251582","d39739e4","2eafa8c7","691b8462","3e8abcfc","c03047ad","36d71d1b","tube_selector","feed_shell","2c05971d","81aab155","pump","attach_underbarrel","IK_left","62910ea8","0708ebc6","fire_selector","bolt","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,2,12,13,14,14,14,14,14,14,14,14,14,14,14,14,14,14,28,14,30,14,14,14,14,14,14,14,38,38,38,38,38,38,38,38,14,47,47,47,47,47,47,47,47,14,14,57,57,14,60,60,14,14,14,14,2,67,67,67,67,67,25},["members"]={{["hash"]="11ec8e2296a3d662",["count"]=74},{["hash"]="3d58ea61b2b485cc",["count"]=12},{["hash"]="7f19d05cd188c768",["count"]=6}},["support_envelope"]={["min"]={0.24113313853740692,0.03339190408587456,-0.17039170861244202},["max"]={0.37786242365837097,0.04940755292773247,-0.14659567177295685}}},["14d5d4506056c7a4"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/smart_pistol_missile/smart_pistol_missile",["sidearm"]=true,["count"]=43,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","a82583a7","shadow_mesh","29841870","a4943571","e052c68d","f14b2e86","skeleton","root","boss","sight","latch","trigger","hinge_pivot","missile","85526904","missile_fin_rear_02","missile_fin_rear_04","missile_fin_rear_03","missile_fin_rear_01","missile_fin_04","missile_fin_03","missile_fin_01","missile_fin_02","IK_right","cog","attach_optic","IK_left","attach_ammo","attach_paintjob","attach_muzzle","collision","c_culling","c_body","5be474d2","game_mesh","e5b6fa26","acf9d3e1","9d7971d3","f87435a4","g_screen","682a9a6c"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,14,15,16,16,16,16,16,16,16,16,10,10,10,10,10,10,10,2,32,32,32,2,36,36,36,36,36,36},["members"]={{["hash"]="14d5d4506056c7a4",["count"]=43},{["hash"]="350168e3fd02b325",["count"]=9},{["hash"]="6b9572ac0f687394",["count"]=6}}},["186ea95de7306b1a"]={["path"]="content/fac_helldivers/equipment/primary_weapons/smg_solvent/smg_solvent",["sidearm"]=false,["count"]=36,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","901c4d83","shadow_mesh","e51c8129","3f934e36","4ac13d05","ae125bd1","skeleton","root","boss","attach_optic","IK_right","cog","bolt_handle","mag_release","IK_left","sight","attach_mag","ejector","attach_ammo","fireselector","bolt","attach_underbarrel","attach_muzzle","attach_paintjob","collision","c_culling","c_collision","game_mesh","d82781e3","a3b7ae21","084c92f0","4af84052","22fa3569","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,26,26,2,29,29,29,29,29,13},["members"]={{["hash"]="186ea95de7306b1a",["count"]=36},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="7b153e02ad22d12c",["count"]=12},{["hash"]="8f141212b0f6f515",["count"]=13},{["hash"]="9d5e0d88df992aa6",["count"]=6},{["hash"]="9dbc8aa8702ac9e1",["count"]=12}}},["1a437158e1b8d2a1"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/magnum_pistol/magnum_pistol",["sidearm"]=true,["count"]=36,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","96d13711","shadow_mesh","ced302ea","ef1d3ed0","34bacd7a","e4cdc04d","skeleton","root","boss","IK_right","slide_lock","cog","IK_left","sight","attach_underbarrel","attach_ammo","attach_optic","attach_muzzle","attach_paintjob","ejector","attach_mag","slide","collision","5be474d2","b4afc5cb","game_mesh","acc4dfac","dfb3d46a","3e0e5fb3","07fdb78e","f77f6ecf","dc0a2993","trigger","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,2,24,24,2,27,27,27,27,27,21,10,13},["members"]={{["hash"]="005c2262f672caf4",["count"]=18},{["hash"]="1a437158e1b8d2a1",["count"]=36},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="6b9572ac0f687394",["count"]=6}}},["1abbff60d26ba391"]={["path"]="content/fac_helldivers/equipment/primary_weapons/marksman_rifle_shark/marksman_rifle_shark",["sidearm"]=false,["count"]=30,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","adfe9a3a","shadow_mesh","f5856de3","21e77aab","2ce8c30f","3244cfdf","collision","c_culling","c_collision2","c_collision1","skeleton","boss","trigger","attach_optic","attach_muzzle","IK_right","IK_left","cog","attach_mag","sight","attach_paintjob","attach_ammo","game_mesh","242312f1","af939945","b845ca03","d55a0421","588ace3e"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,2,12,13,13,13,13,13,13,13,13,13,13,2,24,24,24,24,24},["members"]={{["hash"]="1abbff60d26ba391",["count"]=30},{["hash"]="3a8ad42985c52dc7",["count"]=14},{["hash"]="8a7631bbb4f6f3d8",["count"]=10}}},["27ee1ed8f6fb6356"]={["path"]="content/fac_helldivers/equipment/primary_weapons/laser_rifle/laser_rifle",["sidearm"]=false,["count"]=40,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","c2aeded1","laser_rifle","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","attach_optic","sight","IK_right","cog","attach_muzzle","IK_left","attach_underbarrel","f2e6ef91","033cfd08","0893545f","8a38df10","7e4a3abd","c5a8dba5","attach_ammo","attach_paintjob","attach_mag_2","attach_mag","collision","c_culling","83d334ef","c_body","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","pivot"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,3,29,29,29,3,33,33,33,33,33,15},["members"]={{["hash"]="129e5fb1b13c2018",["count"]=12},{["hash"]="27ee1ed8f6fb6356",["count"]=40},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="50cd7e9f909fe5a1",["count"]=12},{["hash"]="cebd25f8778bfdee",["count"]=14}}},["295beb26dc4f8ff1"]={["path"]="content/fac_helldivers/equipment/primary_weapons/laser_rifle_long_hotshot/laser_rifle_long_hotshot",["sidearm"]=false,["count"]=39,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","dc759958","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","collision","c_collision","skeleton","root","boss","attach_optic","IK_right","IK_left","cog","attach_muzzle","attach_mag","0893545f","f2e6ef91","7e4a3abd","c5a8dba5","033cfd08","8a38df10","mag_compartment","trigger","sight","attach_paintjob","attach_ammo","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","fba13298","g_body","1523169d","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,2,10,11,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,2,30,30,30,30,30,30,12,16},["members"]={{["hash"]="129e5fb1b13c2018",["count"]=12},{["hash"]="295beb26dc4f8ff1",["count"]=39},{["hash"]="80e8335ab4042fcf",["count"]=12}}},["2b28e17ffed05f7c"]={["path"]="content/fac_helldivers/equipment/primary_weapons/triple_barrel_breakshotgun/triple_barrel_breakshotgun",["sidearm"]=true,["count"]=43,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","416a253b","shadow_mesh","df7ef323","7076e098","5b1217ca","7bd3fad0","skeleton","root","IK_left","feed_shell","9f94a812","IK_right","sight","jiggle_02","jiggle_03","break_lever","hinge","extractor","shell_2","9300c315","shell_3","2e53e6f3","shell_1","8e3c8c09","jiggle_01","e85c3034","9111ef9b","18094134","995581ab","015fe933","d9b237bf","game_mesh","80676687","35ff25d1","772e0c4f","9406fb28","814e2eb6","collision","c_culling","c_collision_02","c_collision_01"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,9,11,9,9,9,15,9,9,18,19,20,19,22,19,24,18,18,18,18,18,18,18,2,33,33,33,33,33,2,39,39,39},["members"]={{["hash"]="2b28e17ffed05f7c",["count"]=43},{["hash"]="7f19d05cd188c768",["count"]=6}}},["30061f91af477f5e"]={["path"]="content/fac_helldivers/equipment/primary_weapons/sniper_rifle_helghast/sniper_rifle_helghast",["sidearm"]=false,["count"]=36,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","af348d0c","d184ebf2","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","attach_ammo","attach_muzzle","IK_right","IK_left","cog","sight","clip_02_bottom","clip_02_top","clip_01_bottom","clip_01_top","attach_optic","attach_underbarrel","attach_mag","collision","0a06b157","cbbd9fd8","c_body","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","ejector"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,11,11,11,11,11,11,11,11,11,11,11,11,3,25,25,25,3,29,29,29,29,29,11},["members"]={{["hash"]="30061f91af477f5e",["count"]=36},{["hash"]="7301b3dc5b1bffb8",["count"]=17},{["hash"]="dd8cbbac49f7c628",["count"]=15}}},["3575aabc5f1f9326"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/automatic_pistol/automatic_pistol",["sidearm"]=true,["count"]=35,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","0eaee456","d924d5ef","skeleton","root","boss","IK_right","cog","attach_optic","IK_left","sight","attach_mag","attach_ammo","attach_paintjob","ejector","slide","fireselector","attach_muzzle","shadow_mesh","c4a1d881","27a837b4","c372217f","450a8e24","collision","bd128517","c_body","game_mesh","175f53c9","1a26b734","d69497c1","b41f604d","g_reciever","attach_underbarrel","pivot"},["parents"]={0,0,1,1,3,4,5,6,6,6,6,6,6,6,6,6,6,16,6,3,19,19,19,19,3,24,24,3,27,27,27,27,27,6,8},["members"]={{["hash"]="3575aabc5f1f9326",["count"]=35},{["hash"]="78829731a0563576",["count"]=13},{["hash"]="9d5e0d88df992aa6",["count"]=6},{["hash"]="c891acf9e8dbda97",["count"]=12},{["hash"]="e6b6467135035059",["count"]=13}}},["3c86e871923f3970"]={["path"]="content/fac_helldivers/equipment/primary_weapons/laser_shotgun/laser_shotgun",["sidearm"]=false,["count"]=45,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","6717663d","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_right","attach_underbarrel","6e2375e7","3bf6db80","ad0b9b7f","cog","attach_muzzle","IK_left","attach_optic","attach_mag_3","attach_mag_2","attach_mag","0893545f","f2e6ef91","7e4a3abd","c5a8dba5","033cfd08","8a38df10","trigger","sight","attach_paintjob","attach_ammo","collision","c_culling","451193cc","a2df1bbf","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","1523169d","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,33,33,33,2,37,37,37,37,37,10,16},["members"]={{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="3c86e871923f3970",["count"]=45},{["hash"]="3d58ea61b2b485cc",["count"]=12},{["hash"]="b1bc2b7252ccbc03",["count"]=12}}},["3f92ba65ef65cca9"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/flamer_pistol/flamer_pistol",["sidearm"]=true,["count"]=33,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","78263608","skeleton","root","boss","IK_right","sight","mag_pivot","attach_mag","igniter","cog","IK_left","attach_ammo","attach_muzzle","attach_paintjob","shadow_mesh","e1304f61","bfeb348e","8f494ae1","ea4f5662","collision","c_culling","5be474d2","b4afc5cb","game_mesh","51a79771","825b8794","d24c9325","b4f8eb3c","5dbc554b","trigger","pivot"},["parents"]={0,0,1,2,3,4,5,5,5,8,5,5,5,5,5,5,2,16,16,16,16,2,21,21,21,2,25,25,25,25,25,5,11},["members"]={{["hash"]="3f92ba65ef65cca9",["count"]=33},{["hash"]="a134e110ef4ef865",["count"]=7}}},["416d053372c4e433"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/energy_revolver/energy_revolver",["sidearm"]=true,["count"]=32,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","9bda7e06","shadow_mesh","af23a9ce","cc199442","9d97aad8","844629aa","collision","c_collision_02","c_collision_01","skeleton","boss","02304bb4","attach_optic","IK_left","IK_right","attach_ammo","attach_paintjob","trigger","hinge","attach_underbarrel","sight","attach_mag","attach_muzzle","game_mesh","47398982","8ab773e8","0e5231e4","9063723d","8a97ca64","1523169d"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,2,11,12,12,12,12,12,12,12,12,20,20,20,20,2,25,25,25,25,25,12},["members"]={{["hash"]="416d053372c4e433",["count"]=32},{["hash"]="50cd7e9f909fe5a1",["count"]=12},{["hash"]="78829731a0563576",["count"]=13},{["hash"]="7b06196e90154c88",["count"]=34},{["hash"]="e53e4b0c20563d21",["count"]=5},{["hash"]="e6b6467135035059",["count"]=13}}},["41eac4a03987faa0"]={["path"]="content/fac_helldivers/equipment/primary_weapons/pump_shotgun/pump_shotgun",["sidearm"]=false,["count"]=75,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","5e1afa81","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_right","acb10a6a","493514d1","86dd3fb2","7d8a61e7","e85c3034","9111ef9b","18094134","sight","attach_optic","cog","ejector","mag_l","9236ee9a","mag_r","80238eb6","eject_hatch","attach_muzzle","5f0e5b37","attach_paintjob","attach_ammo","feed_hatch_r","feed_hatch_l","mag_r_follower","f616be64","cb85f6fe","8cce08a0","610a417c","36797a16","315b8a8e","ab33b01a","fc9deaaa","mag_l_follower","9e7f8ad1","20251582","d39739e4","2eafa8c7","691b8462","3e8abcfc","c03047ad","36d71d1b","tube_selector","feed_shell","2c05971d","81aab155","pump","attach_underbarrel","IK_left","62910ea8","0708ebc6","fire_selector","bolt","collision","c_culling","0bf48bf9","5dd2c3c7","8755602b","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,23,10,25,10,10,10,10,10,10,10,10,34,34,34,34,34,34,34,34,10,43,43,43,43,43,43,43,43,10,10,53,53,10,56,56,10,10,10,10,2,63,63,63,63,2,68,68,68,68,68,21},["members"]={{["hash"]="41eac4a03987faa0",["count"]=75},{["hash"]="7f19d05cd188c768",["count"]=6},{["hash"]="8f6f7c8c1e4b9b6d",["count"]=11},{["hash"]="9dbc8aa8702ac9e1",["count"]=12}},["support_envelope"]={["min"]={0.22358697652816772,0.055989187210798264,-0.20172667503356934},["max"]={0.36031630635261536,0.07200483977794647,-0.17793063819408417}}},["46183b50961d1328"]={["path"]="content/fac_helldivers/equipment/primary_weapons/assault_shotgun/assault_shotgun",["sidearm"]=false,["count"]=37,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","70e26d9a","faaf95a1","shadow_mesh","c4a1d881","27a837b4","c372217f","450a8e24","skeleton","root","boss","attach_underbarrel","IK_right","IK_left","cog","attach_mag","attach_optic","99f1744a","sight","bolt_carrier","charging_handle","attach_ammo","attach_muzzle","attach_paintjob","fire_selector","ejector","collision","5be474d2","c_body","game_mesh","175f53c9","1a26b734","d69497c1","b41f604d","g_reciever","pivot"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,3,27,27,3,30,30,30,30,30,15},["members"]={{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="3ddb9d36da22555d",["count"]=36},{["hash"]="45be635fb904f4dc",["count"]=12},{["hash"]="46183b50961d1328",["count"]=37},{["hash"]="6228d0242bde56b6",["count"]=38},{["hash"]="68b8d040421e8a49",["count"]=25},{["hash"]="8cd335a5f711bb59",["count"]=12},{["hash"]="9dbc8aa8702ac9e1",["count"]=12},{["hash"]="b7cd78c71e0a48ed",["count"]=6},{["hash"]="d8cf7fe059b4bf1e",["count"]=12}}},["4ba41b6f9f405cc2"]={["path"]="content/fac_helldivers/equipment/primary_weapons/smg_helghast/smg_helghast",["sidearm"]=false,["count"]=40,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","8ce601bb","e7fd3485","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_left","attach_ammo","release_lever","IK_right","attach_muzzle","cog","ejector","sight","hinge","attach_underbarrel","attach_paintjob","attach_mag","bolt","0708ebc6","62910ea8","collision","cbbd9fd8","b4afc5cb","5be474d2","9851c382","aac0d979","7c6f78ba","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,3,27,27,27,27,27,27,3,34,34,34,34,34},["members"]={{["hash"]="48d2ddc8e9a80b1e",["count"]=14},{["hash"]="4ba41b6f9f405cc2",["count"]=40},{["hash"]="6b9572ac0f687394",["count"]=6}}},["4d58c77087b774c5"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/pistol_nacho/pistol_nacho",["sidearm"]=true,["count"]=36,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","0ec0e8ec","shadow_mesh","0d4e4ebd","4d6420e3","6d1367d6","8c0914dc","skeleton","root","boss","slide_release","trigger","attach_underbarrel","IK_right","cog","IK_left","sight","attach_ammo","attach_muzzle","attach_paintjob","ejector","attach_mag","slide","collision","5be474d2","b4afc5cb","game_mesh","1c31293d","7f7fff3f","9c79fbbe","2df7cf90","4b1330f7","dc0a2993","1523169d","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,2,24,24,2,27,27,27,27,27,21,10,15},["members"]={{["hash"]="4d58c77087b774c5",["count"]=36},{["hash"]="4ffb842ce1093f3f",["count"]=17},{["hash"]="6b9572ac0f687394",["count"]=6},{["hash"]="e69567209a83df39",["count"]=11}}},["4dbd74f49c8ffc13"]={["path"]="content/fac_helldivers/equipment/primary_weapons/assault_rifle_nacho/assault_rifle_nacho",["sidearm"]=false,["count"]=36,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","92bb4760","shadow_mesh","c4a1d881","27a837b4","c372217f","450a8e24","skeleton","root","boss","attach_underbarrel","IK_right","IK_left","cog","attach_mag","sight","bolt_carrier","charging_handle","attach_ammo","attach_muzzle","attach_paintjob","ejector","collision","c_collision","game_mesh","175f53c9","1a26b734","d69497c1","b41f604d","g_backscreen","g_screen","g_reciever","dc0a2993","trigger","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,2,23,2,25,25,25,25,25,25,25,22,10,14},["members"]={{["hash"]="0040c16bd48573e2",["count"]=10},{["hash"]="4dbd74f49c8ffc13",["count"]=36},{["hash"]="7f49b46efdd850ef",["count"]=16},{["hash"]="7fdd884ecd57231b",["count"]=6}}},["4e4a613eb9bf5c24"]={["path"]="content/fac_helldivers/equipment/primary_weapons/personal_defense_weapon/personal_defense_weapon",["sidearm"]=false,["count"]=38,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","5f1db6a1","shadow_mesh","22cbeab1","a3572540","51705c29","4ff4a138","collision","908f5891","cbbd9fd8","skeleton","root","boss","attach_underbarrel","attach_optic","sight","IK_right","IK_left","cog","attach_muzzle","stock","attach_mag","attach_ammo","attach_paintjob","bolt","fireselector","ejector","game_mesh","9c1e86bd","5b36149a","680e2e36","27c7f221","ded61678","dc0a2993","trigger","pivot","fda371a8"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,2,11,12,13,13,13,13,13,13,13,13,13,13,13,13,13,13,2,28,28,28,28,28,27,13,19,12},["members"]={{["hash"]="05e4e5c2db6e44a2",["count"]=33},{["hash"]="0ec5ef9ec5cbd1b2",["count"]=5},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="4851d75853622a47",["count"]=15},{["hash"]="4e4a613eb9bf5c24",["count"]=38},{["hash"]="4f839e923046e631",["count"]=15},{["hash"]="52071f49263415e4",["count"]=35},{["hash"]="6b88fea13ec2d78e",["count"]=12},{["hash"]="6b9572ac0f687394",["count"]=6},{["hash"]="77c5d934407114f4",["count"]=17},{["hash"]="8d3d52a3b2f19402",["count"]=60},{["hash"]="9dbc8aa8702ac9e1",["count"]=12},{["hash"]="b5b4395852e871bc",["count"]=6},{["hash"]="b96cc3b704a76464",["count"]=7},{["hash"]="e6b6467135035059",["count"]=13},{["hash"]="e71dbcb6a50f321b",["count"]=158}}},["4fb0f8c02f55c82b"]={["path"]="content/fac_helldivers/equipment/primary_weapons/flamethrower_ripley/flamethrower_ripley",["sidearm"]=false,["count"]=30,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","6c58bc53","shadow_mesh","4a0b8e6f","ca7ec05b","9ca282db","1f6af22a","skeleton","boss","IK_right","igniter","attach_mag","IK_left","cog","sight","attach_ammo","attach_muzzle","attach_paintjob","collision","c_collision_03","c_collision_02","c_collision_01","game_mesh","1bb15982","d9d312cf","e130bd4f","8c72dfda","5dbccd27","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,9,9,9,9,9,9,9,9,2,19,19,19,2,23,23,23,23,23,14},["members"]={{["hash"]="4fb0f8c02f55c82b",["count"]=30},{["hash"]="511910c41a70122d",["count"]=14}}},["52e4334e6a128caf"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/grenade_pistol/grenade_pistol",["sidearm"]=true,["count"]=32,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","b8bd4644","shadow_mesh","f2b892e8","26074e35","808dc016","e9c0c60e","skeleton","root","boss","IK_right","sight","attach_optic","cog","breach_slide","breach","attach_underbarrel","attach_mag","attach_ammo","attach_muzzle","attach_paintjob","IK_left","collision","c_collision","game_mesh","1a49ece1","661f72f3","379d898a","f7c3ed81","8335e4fd","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,15,16,16,10,10,10,10,2,23,2,25,25,25,25,25,14},["members"]={{["hash"]="52e4334e6a128caf",["count"]=32},{["hash"]="5f4b129d947d79d7",["count"]=13},{["hash"]="78829731a0563576",["count"]=13}}},["53eebe75cd6e26df"]={["path"]="content/fac_helldivers/equipment/primary_weapons/pump_shotgun_slug/pump_shotgun_slug",["sidearm"]=false,["count"]=75,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","c379162c","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_right","acb10a6a","493514d1","86dd3fb2","7d8a61e7","e85c3034","9111ef9b","18094134","sight","attach_optic","cog","ejector","mag_l","9236ee9a","mag_r","80238eb6","eject_hatch","attach_muzzle","5f0e5b37","attach_paintjob","attach_ammo","feed_hatch_r","feed_hatch_l","mag_r_follower","f616be64","cb85f6fe","8cce08a0","610a417c","36797a16","315b8a8e","ab33b01a","fc9deaaa","mag_l_follower","9e7f8ad1","20251582","d39739e4","2eafa8c7","691b8462","3e8abcfc","c03047ad","36d71d1b","tube_selector","feed_shell","2c05971d","81aab155","pump","IK_left","attach_underbarrel","62910ea8","0708ebc6","fire_selector","bolt","collision","c_culling","0bf48bf9","5dd2c3c7","8755602b","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,23,10,25,10,10,10,10,10,10,10,10,34,34,34,34,34,34,34,34,10,43,43,43,43,43,43,43,43,10,10,53,53,10,56,56,10,10,10,10,2,63,63,63,63,2,68,68,68,68,68,21},["members"]={{["hash"]="3d58ea61b2b485cc",["count"]=12},{["hash"]="53eebe75cd6e26df",["count"]=75},{["hash"]="8f6f7c8c1e4b9b6d",["count"]=11},{["hash"]="e6caddc3ed05dd7e",["count"]=4}},["support_envelope"]={["min"]={0.22358697652816772,0.055989187210798264,-0.20172667503356934},["max"]={0.36031630635261536,0.07200483977794647,-0.17793063819408417}}},["5fecab819f96a3e8"]={["path"]="content/fac_helldivers/equipment/primary_weapons/battle_rifle/battle_rifle",["sidearm"]=false,["count"]=37,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","e1090323","shadow_mesh","ecf3b892","40f8d2e6","ce45e94a","1604b654","collision","5be474d2","c_body","skeleton","root","boss","attach_underbarrel","IK_right","attach_optic","IK_left","cog","attach_mag","5949a6e1","ejector","mag_release","sight","attach_ammo","attach_paintjob","barrel","attach_muzzle","bolt","fireselector","game_mesh","40e62628","4ec28537","35818cf6","6f2eabf9","ab5ce15e","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,2,11,12,13,13,13,13,13,13,13,13,13,13,13,13,13,26,13,13,2,30,30,30,30,30,18},["members"]={{["hash"]="129e5fb1b13c2018",["count"]=12},{["hash"]="5fecab819f96a3e8",["count"]=37},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="c245c696e80677ed",["count"]=20},{["hash"]="ffc18b2ce10ca381",["count"]=11}}},["708ea298c82093d0"]={["path"]="content/fac_helldivers/equipment/primary_weapons/assault_rifle_whisper/assault_rifle_whisper",["sidearm"]=false,["count"]=38,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","assault_rifle_whisper","shadow_mesh","c4846e6b","1d8a6f58","66acf2b1","199d951f","skeleton","root","boss","charging_pin","attach_underbarrel","mag_release","bolt_handle","IK_right","cog","IK_left","sight","attach_optic","bolt_cover","attach_mag","attach_muzzle","attach_paintjob","fire_selector","ejector","ejection_port","collision","16f6a0c3","game_mesh","6651bc24","8f0fa4be","713ebe31","1aa3a27c","d5ef6d73","dc0a2993","trigger","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,27,2,29,29,29,29,29,25,10,16},["members"]={{["hash"]="45be635fb904f4dc",["count"]=12},{["hash"]="708ea298c82093d0",["count"]=38},{["hash"]="7441b048b94491fc",["count"]=12},{["hash"]="7be1e04a7738e673",["count"]=18},{["hash"]="7fdd884ecd57231b",["count"]=6}}},["72170a55a1f37ff1"]={["path"]="content/fac_helldivers/equipment/primary_weapons/shotgun_double_freedom/shotgun_double_freedom",["sidearm"]=false,["count"]=38,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","246b1468","shadow_mesh","fc6daa6a","7ab58c05","d7cf4089","ad849817","collision","c_collision","skeleton","root","boss","fire_selector","IK_right","hammer_right","hammer_left","trigger","break_lever","barrel_pivot","IK_left","ejector","shell_right","55935647","shell_left","3870f6b7","attach_underbarrel","6e2375e7","3bf6db80","sight","attach_paintjob","attach_ammo","game_mesh","49568633","310a0d72","cf1bdcdd","86abc80c","af696430"},["parents"]={0,0,1,2,3,3,3,3,2,8,2,10,11,12,12,12,12,12,12,12,19,19,21,22,21,24,19,19,19,12,12,12,2,32,32,32,32,32},["members"]={{["hash"]="72170a55a1f37ff1",["count"]=38},{["hash"]="91eb62e0a02302ba",["count"]=5}},["support_envelope"]={["min"]={0.2423786073923111,0.04661067575216293,-0.14965541660785675},["max"]={0.250683456659317,0.06574837863445282,-0.14877109229564667}}},["7b06196e90154c88"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/laser_pistol/laser_pistol",["sidearm"]=true,["count"]=34,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","7ef2030b","2015781c","shadow_mesh","e1d5ef83","9a3e993d","c8ca64c8","c648c049","skeleton","root","boss","IK_right","attach_optic","cog","ejector","attach_mag","7c52f939","IK_left","sight","attach_muzzle","attach_paintjob","attach_ammo","collision","c_bodycollisionbot","c_bodycollisiontop","game_mesh","01f4ae2d","a4d6339c","8a312a46","1f314837","885fb30d","attach_underbarrel","pivot"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,11,11,11,15,15,11,11,11,11,11,3,23,23,3,26,26,26,26,26,11,14},["members"]={{["hash"]="416d053372c4e433",["count"]=32},{["hash"]="50cd7e9f909fe5a1",["count"]=12},{["hash"]="78829731a0563576",["count"]=13},{["hash"]="7b06196e90154c88",["count"]=34},{["hash"]="e53e4b0c20563d21",["count"]=5},{["hash"]="e6b6467135035059",["count"]=13}}},["7b75e5132ffd4ca6"]={["path"]="content/fac_helldivers/equipment/primary_weapons/bolt_action_rifle/bolt_action_rifle",["sidearm"]=false,["count"]=42,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","d8d9c291","shadow_mesh","9b9e048d","7bd738d0","8b7a88bd","de7721d5","skeleton","root","boss","stripper_clip","stripper_clip_bullet","stripper_clip_bullet_scale","stripper_clip_bot_bullets","stripper_clip_top_bullet","stripper_clip_scale","attach_muzzle","ejector","IK_left","bolt","feed_bullet","e90b0925","bullet_01","bullet_01_scale","IK_right","cog","trigger","sight","attach_paintjob","attach_ammo","collision","c_culling","c_collision","game_mesh","3755735c","9c313461","4f1512b0","2f2dcbec","52619f5f","pivot","attach_underbarrel"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,11,12,13,13,11,10,10,10,10,10,21,10,23,10,10,10,10,10,10,2,31,31,2,34,34,34,34,34,26,10},["members"]={{["hash"]="206cb0dd1696ceaa",["count"]=5},{["hash"]="7b75e5132ffd4ca6",["count"]=42},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="8a35c1dc19f41870",["count"]=10},{["hash"]="a9a19cffe985c468",["count"]=12}},["support_envelope"]={["min"]={0.20177042484283447,0.09659955650568008,-0.19674789905548096},["max"]={0.4060055613517761,0.1558298021554947,-0.12271896004676819}}},["7e3145a5baa4b948"]={["path"]="content/fac_helldivers/equipment/primary_weapons/laser_rifle_charge/laser_rifle_charge",["sidearm"]=false,["count"]=32,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","5d024763","shadow_mesh","3016c493","collision","f44ab049","5be474d2","cbbd9fd8","9851c382","skeleton","root","boss","magazine_tilt","attach_mag","attach_ammo","IK_right","cog","IK_left","attach_underbarrel","sight","attach_optic","attach_paintjob","attach_muzzle","game_mesh","77a7bb3d","ac20abfb","cc03c16e","c7edf01c","5701c359","7e4a3abd","033cfd08"},["parents"]={0,0,1,2,3,2,5,5,5,5,2,10,11,12,13,12,12,12,12,12,12,12,12,12,2,24,24,24,24,24,2,2},["members"]={{["hash"]="129e5fb1b13c2018",["count"]=12},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="7dc6dda584cc5223",["count"]=11},{["hash"]="7e3145a5baa4b948",["count"]=32},{["hash"]="d44c25420aa3e2ff",["count"]=26}}},["80f1a156d9fa1e36"]={["path"]="content/fac_helldivers/equipment/primary_weapons/jet_rifle/jet_rifle",["sidearm"]=false,["count"]=38,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","1aef913c","db8694d3","shadow_mesh","a07cd367","6049154c","edb07227","bfa710d2","collision","c_collision2","c_collision1","skeleton","boss","IK_right","bolt_handle","IK_left","cog","attach_optic","attach_mag","mag_release","attach_underbarrel","sight","upper_reciever","barrel","attach_muzzle","fire_selector","bolt","ejector","attach_paintjob","attach_ammo","game_mesh","cae65bb5","8978c675","ed5cb4cc","8c449616","250e6276","pivot"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,9,3,12,13,13,13,13,13,13,13,13,13,13,23,24,13,13,13,13,13,3,31,31,31,31,31,17},["members"]={{["hash"]="1ec5f54265a91c83",["count"]=16},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="3d58ea61b2b485cc",["count"]=12},{["hash"]="80f1a156d9fa1e36",["count"]=38},{["hash"]="ab9e1ad1597d5d9e",["count"]=6}}},["84354339522c932d"]={["path"]="content/fac_helldivers/equipment/primary_weapons/assault_rifle_large_calibre_01/assault_rifle_large_calibre_01",["sidearm"]=false,["count"]=36,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","05ffc1c7","shadow_mesh","ca60a00c","56887987","8f31db0e","6cb6e582","skeleton","root","boss","IK_right","cog","attach_mag","ejector","attach_muzzle","IK_left","sight","attach_underbarrel","attach_optic","attach_paintjob","fire_selector","bolt","ejection_port","trigger","collision","c_collision","game_mesh","c15007ff","4cd3443d","580dc614","dbdd115b","3ce6e752","dc0a2993","1523169d","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,25,2,27,27,27,27,27,14,10,12},["members"]={{["hash"]="5d268a6f943792d4",["count"]=10},{["hash"]="84354339522c932d",["count"]=36},{["hash"]="963aca558cd906bc",["count"]=17},{["hash"]="cf907add37bfa9be",["count"]=6}}},["8645f167b3c813a2"]={["path"]="content/fac_helldivers/equipment/primary_weapons/laser_rifle_long/laser_rifle_long",["sidearm"]=false,["count"]=37,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","29daa6d4","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","collision","c_collision","skeleton","root","boss","attach_optic","IK_left","IK_right","cog","attach_muzzle","attach_mag","0893545f","f2e6ef91","7e4a3abd","c5a8dba5","033cfd08","8a38df10","mag_compartment","trigger","sight","attach_paintjob","attach_ammo","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,2,10,11,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,2,30,30,30,30,30,16},["members"]={{["hash"]="129e5fb1b13c2018",["count"]=12},{["hash"]="8645f167b3c813a2",["count"]=37},{["hash"]="e3541de70b7ec1c0",["count"]=13}}},["8a307bd1811a5fe9"]={["path"]="content/fac_helldivers/equipment/primary_weapons/smg_flamer/smg_flamer",["sidearm"]=false,["count"]=34,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","5db85e74","shadow_mesh","f7c8a577","2a016c7b","2b911c2c","cb058ec9","collision","eb7d2210","skeleton","root","boss","attach_underbarrel","attach_optic","sight","IK_right","IK_left","cog","attach_muzzle","stock","attach_mag","attach_ammo","attach_paintjob","bolt","fireselector","ejector","game_mesh","7cf338b3","d269aa79","c9b563dc","5a2b2659","85376f75","fda371a8"},["parents"]={0,0,1,2,3,3,3,3,2,8,2,10,11,12,12,12,12,12,12,12,12,12,12,12,12,12,12,2,27,27,27,27,27,12},["members"]={{["hash"]="1b1fcc0e025c1f7d",["count"]=14},{["hash"]="6b9572ac0f687394",["count"]=6},{["hash"]="72fe4b13f726c344",["count"]=24},{["hash"]="7b153e02ad22d12c",["count"]=12},{["hash"]="8a307bd1811a5fe9",["count"]=34},{["hash"]="d5cb9b5401b261f9",["count"]=11}}},["8d3d52a3b2f19402"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/revolver_pistol/revolver_pistol",["sidearm"]=true,["count"]=60,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","f78c0076","31e509f0","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","IK_right","cog","IK_left","sight","attach_ammo","attach_paintjob","feed_bullet","e90b0925","attach_underbarrel","cylinder_swivel","attach_mag","cylinder","eject_rod","bullet_1","63708b37","99971250","bullet_2","5711b417","3417ea15","bullet_3","bullet_3_fired","9afc7b8c","61973ece","bullet_4","18ea54f1","0dc35982","bullet_5","41f9cc7c","fc63429a","bullet_6","da3b60a4","dd72e985","hammer","attach_muzzle","collision","c_culling","5be474d2","c_body","game_mesh","9f458637","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","abc6b6e1","d0f250ae","7de4e240","g_body","pivot"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,10,10,10,10,10,10,17,10,10,20,20,22,23,24,24,23,27,27,23,30,31,30,23,34,34,23,37,37,23,40,40,10,10,3,45,45,45,3,49,49,49,49,49,49,49,49,49,12},["members"]={{["hash"]="05e4e5c2db6e44a2",["count"]=33},{["hash"]="0ec5ef9ec5cbd1b2",["count"]=5},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="4851d75853622a47",["count"]=15},{["hash"]="4e4a613eb9bf5c24",["count"]=38},{["hash"]="4f839e923046e631",["count"]=15},{["hash"]="52071f49263415e4",["count"]=35},{["hash"]="6b88fea13ec2d78e",["count"]=12},{["hash"]="6b9572ac0f687394",["count"]=6},{["hash"]="77c5d934407114f4",["count"]=17},{["hash"]="8d3d52a3b2f19402",["count"]=60},{["hash"]="9dbc8aa8702ac9e1",["count"]=12},{["hash"]="b5b4395852e871bc",["count"]=6},{["hash"]="b96cc3b704a76464",["count"]=7},{["hash"]="e6b6467135035059",["count"]=13},{["hash"]="e71dbcb6a50f321b",["count"]=158}}},["8dc91f277c6096ee"]={["path"]="content/fac_helldivers/equipment/primary_weapons/jet_rifle_phoenix/jet_rifle_phoenix",["sidearm"]=false,["count"]=38,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","1aef913c","a408c99e","skeleton","boss","IK_right","IK_left","cog","attach_optic","attach_mag","mag_release","bolt_handle","attach_underbarrel","sight","upper_reciever","barrel","attach_muzzle","fire_selector","bolt","ejector","attach_paintjob","attach_ammo","collision","c_collision2","c_collision1","shadow_mesh","a07cd367","6049154c","edb07227","bfa710d2","game_mesh","cae65bb5","8978c675","ed5cb4cc","8c449616","250e6276","pivot"},["parents"]={0,0,1,1,3,4,5,5,5,5,5,5,5,5,5,5,15,16,5,5,5,5,5,3,23,23,3,26,26,26,26,3,31,31,31,31,31,8},["members"]={{["hash"]="029cfc4c193211c3",["count"]=16},{["hash"]="6d54652ee217d712",["count"]=12},{["hash"]="719f42b7d137789c",["count"]=11},{["hash"]="8dc91f277c6096ee",["count"]=38},{["hash"]="ab9e1ad1597d5d9e",["count"]=6}}},["90ddc374f4e3d756"]={["path"]="content/fac_helldivers/equipment/primary_weapons/shotgun_nacho/shotgun_nacho",["sidearm"]=false,["count"]=38,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","c4fb2256","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","trigger","feed_ramp","attach_muzzle","IK_right","cog","sight","ejector","attach_paintjob","attach_ammo","feed_shell","9f94a812","pump","attach_underbarrel","IK_left","bolt","collision","c_collision_01","c_collision_02","c_culling","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","dc0a2993","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,20,10,22,22,10,2,26,26,26,2,30,30,30,30,30,17,15},["members"]={{["hash"]="0040c16bd48573e2",["count"]=10},{["hash"]="36e235816805c17e",["count"]=5},{["hash"]="90ddc374f4e3d756",["count"]=38}},["support_envelope"]={["min"]={0.2740059792995453,0.012318783439695835,-0.16067638993263245},["max"]={0.3630208671092987,0.02264377474784851,-0.1451594978570938}}},["94bd931b5fb4ee95"]={["path"]="content/fac_helldivers/equipment/primary_weapons/smg_rhino/smg_rhino",["sidearm"]=false,["count"]=39,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","833e5c16","shadow_mesh","0b24d031","efa7e000","9850e955","8607fa5e","skeleton","root","boss","sight","attach_optic","attach_muzzle","trigger","IK_left","attach_underbarrel","sling_attach","IK_right","cog","bolt_handle","mag_release","attach_mag","ejector","attach_ammo","fireselector","bolt","attach_paintjob","collision","c_collision","game_mesh","69eeac6f","134e1de8","17965e6c","42764004","071f1d64","dc0a2993","1523169d","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,28,2,30,30,30,30,30,23,10,19},["members"]={{["hash"]="16051937941bb709",["count"]=11},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="6b9572ac0f687394",["count"]=6},{["hash"]="7372947782b91123",["count"]=17},{["hash"]="94bd931b5fb4ee95",["count"]=39},{["hash"]="fa6f926a77b78b55",["count"]=12}}},["9571ca51f0daf35b"]={["path"]="content/fac_helldivers/equipment/primary_weapons/smg_defender/smg_defender",["sidearm"]=false,["count"]=35,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","c83d8e8c","shadow_mesh","8ee24e91","36a82cf6","5d2de36f","fc4f5636","skeleton","root","boss","attach_optic","IK_right","cog","bolt_handle","mag_release","IK_left","sight","attach_mag","ejector","attach_ammo","fireselector","bolt","attach_underbarrel","attach_muzzle","attach_paintjob","collision","c_collision","game_mesh","52b6e403","3cf464a9","e0d2802c","992e0382","8f699f15","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,26,2,28,28,28,28,28,13},["members"]={{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="7b153e02ad22d12c",["count"]=12},{["hash"]="9571ca51f0daf35b",["count"]=35},{["hash"]="9d5e0d88df992aa6",["count"]=6},{["hash"]="9dbc8aa8702ac9e1",["count"]=12},{["hash"]="be4590c2f615c441",["count"]=14}}},["968211c0033dce64"]={["path"]="content/fac_helldivers/equipment/primary_weapons/assault_rifle/assault_rifle",["sidearm"]=false,["count"]=43,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","e81e9a8c","shadow_mesh","c4a1d881","27a837b4","c372217f","450a8e24","skeleton","root","boss","attach_underbarrel","IK_right","attach_mag","attach_muzzle","IK_left","cog","fire_selector","sight","attach_optic","bolt_carrier","ejection_cover","0708ebc6","62910ea8","attach_paintjob","attach_ammo","ejector","bolt","collision","20b6c93b","b8de7a43","00a7f137","c_bodycollisionbot","c_bodycollisiontop","game_mesh","175f53c9","1a26b734","d69497c1","b41f604d","g_reciever","dc0a2993","trigger","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,28,28,28,28,28,2,34,34,34,34,34,26,10,16},["members"]={{["hash"]="129e5fb1b13c2018",["count"]=12},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="756e3fdaca41cfca",["count"]=12},{["hash"]="7be1e04a7738e673",["count"]=18},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="968211c0033dce64",["count"]=43},{["hash"]="a1a026c8bb37a96e",["count"]=19},{["hash"]="cb8d6dbe2ad74be4",["count"]=58}}},["9eb160830321bfd6"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/pistol_cricket/pistol_cricket",["sidearm"]=true,["count"]=33,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","5498d714","e680568e","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_right","IK_left","cog","sight","attach_underbarrel","attach_ammo","attach_optic","attach_muzzle","attach_paintjob","bullet_01","bullet_01_scale","slide","collision","5be474d2","b4afc5cb","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,11,11,11,11,11,11,11,11,11,21,11,3,24,24,3,27,27,27,27,27},["members"]={{["hash"]="9dbc8aa8702ac9e1",["count"]=12},{["hash"]="9eb160830321bfd6",["count"]=33},{["hash"]="b3bf071f477fc155",["count"]=3}}},["a6a735accb4a327f"]={["path"]="content/fac_helldivers/equipment/primary_weapons/lmg_stalwart/lmg_stalwart",["sidearm"]=false,["count"]=41,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","09e4b54b","shadow_mesh","ea1992f0","4d8e73ed","0f682ece","9e5d13eb","skeleton","root","boss","IK_right","attach_optic","cog","IK_left","sight","attach_underbarrel","attach_ammo","ejector","top_cover","attach_barrel","barrel_grip","attach_muzzle","attach_mag","f528bc44","bolt","fire_selector","attach_paintjob","collision","c_collision_03","c_collision_02","c_collision_01","game_mesh","6708bce4","4f444fdc","d3f6acbf","b81ff7a5","g_mesh","50b98e76","31eabe41","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,20,20,10,10,10,10,10,2,28,28,28,2,32,32,32,32,32,18,18,13},["members"]={{["hash"]="028a1ed2394fb808",["count"]=6},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="45be635fb904f4dc",["count"]=12},{["hash"]="73a5ecad32ba599b",["count"]=35},{["hash"]="756e3fdaca41cfca",["count"]=12},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="a6a735accb4a327f",["count"]=41}}},["a7ee1ebf58fcdf1f"]={["path"]="content/fac_helldivers/equipment/primary_weapons/assault_rifle_patriot/assault_rifle_patriot",["sidearm"]=false,["count"]=43,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","8f54a45b","shadow_mesh","25839681","7cddb544","e5170aed","49e7b1bd","skeleton","root","boss","IK_left","attach_underbarrel","attach_muzzle","attach_optic","IK_right","cog","sight","fire_selector","bolt_carrier","ejection_cover","0708ebc6","62910ea8","attach_paintjob","attach_ammo","attach_mag","ejector","bolt","collision","c_culling","20b6c93b","b8de7a43","00a7f137","c_bodycollisionbot","c_bodycollisiontop","game_mesh","511be368","148087a6","9f845d48","77d343cf","26476669","trigger","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,28,28,28,28,28,28,2,35,35,35,35,35,10,16},["members"]={{["hash"]="2d761a80bcbfe792",["count"]=18},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="45be635fb904f4dc",["count"]=12},{["hash"]="756e3fdaca41cfca",["count"]=12},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="a7ee1ebf58fcdf1f",["count"]=43}}},["aa69a60d74a3ec54"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/plasma_pistol/plasma_pistol",["sidearm"]=true,["count"]=43,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","96368e53","8f5e5351","shadow_mesh","9fdbf9b8","f473646f","b7f4da8e","963bc551","skeleton","root","boss","IK_left","IK_right","cog","attach_underbarrel","mag_tilt","attach_mag","base_r_occelator","r_occelator_01","r_occelator_02","r_occelator_03","base_l_occelator","l_occelator_01","l_occelator_02","l_occelator_03","f024cb8e","sight","attach_ammo","attach_paintjob","attach_muzzle","collision","c_bodycollisionbot","c7276d2a","c_bodycollisiontop","game_mesh","84c6eed0","0b0fd07e","9d3d8ee9","83612eb6","138169a4","trigger","pivot"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,11,11,11,11,16,11,18,18,18,11,22,22,22,11,11,11,11,11,3,31,31,31,3,35,35,35,35,35,11,14},["members"]={{["hash"]="aa69a60d74a3ec54",["count"]=43},{["hash"]="aca180fc6f846411",["count"]=12}}},["bc29613666df696b"]={["path"]="content/fac_helldivers/equipment/primary_weapons/assault_rifle_karbin/assault_rifle_karbin",["sidearm"]=false,["count"]=38,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","9ee3edd7","shadow_mesh","ba39e67c","76415641","8cbf9ba6","c4a26c6d","collision","c_collision","skeleton","root","boss","IK_right","cog","mag_release","sight","attach_paintjob","IK_left","barrel","attach_muzzle","attach_optic","attach_underbarrel","attach_mag","stock","trigger","bolt_cover","bolt","fireselector","game_mesh","dfff7269","6810eea8","ac4380f1","56a5cf98","cab5f476","1523169d","pivot","dc0a2993"},["parents"]={0,0,1,2,3,3,3,3,2,8,2,10,11,12,12,12,12,12,12,12,19,12,12,12,12,12,12,12,12,2,29,29,29,29,29,12,14,12},["members"]={{["hash"]="16ab263bc03b4f96",["count"]=18},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="756e3fdaca41cfca",["count"]=12},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="9dbc8aa8702ac9e1",["count"]=12},{["hash"]="bc29613666df696b",["count"]=38},{["hash"]="bfe35746f5084222",["count"]=3}}},["be70ee0d8d44028e"]={["path"]="content/fac_helldivers/equipment/primary_weapons/smg_nacho/smg_nacho",["sidearm"]=false,["count"]=35,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","c820f2f4","shadow_mesh","7224fe4a","5f799636","274c3510","624f13cd","skeleton","root","boss","attach_muzzle","trigger","grip_hinge","IK_left","attach_underbarrel","IK_right","cog","bolt_handle","sight","attach_mag","attach_ammo","attach_paintjob","collision","c_culling","c_collision_02","c_collision_01","game_mesh","c7efb19e","3d148f5a","6f222b47","7cb875b6","g_lens","59d25b58","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,13,10,10,10,10,10,10,10,10,2,23,23,23,2,27,27,27,27,27,27,17},["members"]={{["hash"]="0040c16bd48573e2",["count"]=10},{["hash"]="43639dc374b75c5f",["count"]=15},{["hash"]="be70ee0d8d44028e",["count"]=35}},["support_envelope"]={["min"]={0.1960674673318863,0.0005412283353507519,-0.16253933310508728},["max"]={0.20447151362895966,0.06301527470350266,-0.15895295143127441}}},["c12a34f375bd5a87"]={["path"]="content/fac_helldivers/equipment/primary_weapons/assault_shotgun_incendiary/assault_shotgun_incendiary",["sidearm"]=false,["count"]=39,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","70e26d9a","3bac79f1","shadow_mesh","c4a1d881","27a837b4","c372217f","450a8e24","skeleton","root","boss","IK_left","attach_underbarrel","IK_right","attach_mag","cog","attach_optic","99f1744a","sight","bolt_carrier","charging_handle","attach_ammo","attach_muzzle","attach_paintjob","fire_selector","ejector","collision","5be474d2","c_body","game_mesh","175f53c9","1a26b734","d69497c1","b41f604d","g_reciever","dc0a2993","trigger","pivot"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,3,27,27,3,30,30,30,30,30,26,11,16},["members"]={{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="3ddb9d36da22555d",["count"]=36},{["hash"]="b7cd78c71e0a48ed",["count"]=6},{["hash"]="c12a34f375bd5a87",["count"]=39},{["hash"]="cdf733b0106a23c3",["count"]=11},{["hash"]="fa6f926a77b78b55",["count"]=12}}},["c4232a0e62166d91"]={["path"]="content/fac_helldivers/equipment/primary_weapons/personal_defense_weapon_pepper/personal_defense_weapon_pepper",["sidearm"]=false,["count"]=38,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","07c508f9","shadow_mesh","22cbeab1","a3572540","51705c29","4ff4a138","skeleton","root","boss","attach_underbarrel","attach_optic","sight","IK_left","IK_right","ejector","attach_muzzle","cog","stock","attach_mag","attach_ammo","attach_paintjob","bolt","fireselector","collision","908f5891","cbbd9fd8","game_mesh","9c1e86bd","5b36149a","680e2e36","27c7f221","ded61678","dc0a2993","trigger","pivot","fda371a8"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,25,25,2,28,28,28,28,28,16,10,18,9},["members"]={{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="6b88fea13ec2d78e",["count"]=12},{["hash"]="6b9572ac0f687394",["count"]=6},{["hash"]="9dbc8aa8702ac9e1",["count"]=12},{["hash"]="c4232a0e62166d91",["count"]=38},{["hash"]="fa6c1158a93b8ec4",["count"]=17}}},["c780bcd79547da0f"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/pistol_broomhandle/pistol_broomhandle",["sidearm"]=true,["count"]=44,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","pistol_broomhandle","shadow_mesh","54e1c0cf","c4b695a0","10b4ecc9","4cb8efb0","skeleton","root","boss","laser","trigger","bullet_01","bullet_01_scale","577913e9","f09f76c4","toggle_01","toggle_02","toggle_03","IK_right","cog","IK_left","sight","attach_ammo","attach_muzzle","attach_paintjob","ejector","attach_mag","42d3625a","bullet_feed","cfadea01","collision","c_culling","5be474d2","b4afc5cb","game_mesh","cfb67078","c291cc8e","fc89b6fd","a331ac6c","44abc411","dc0a2993","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,13,10,10,10,17,18,10,10,10,10,10,10,10,10,10,28,28,30,2,32,32,32,2,36,36,36,36,36,27,21},["members"]={{["hash"]="6b9572ac0f687394",["count"]=6},{["hash"]="7441b048b94491fc",["count"]=12},{["hash"]="bcbbe9bb1a49c7fd",["count"]=5},{["hash"]="c780bcd79547da0f",["count"]=44}}},["cdf28be026bb7d84"]={["path"]="content/fac_helldivers/equipment/primary_weapons/assault_rifle_helghast/assault_rifle_helghast",["sidearm"]=false,["count"]=44,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","92cd5826","0e1acf8c","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","spring_start","spring_end","IK_right","attach_mag","attach_muzzle","ejector","IK_left","cog","fire_selector","sight","feed_tray_cover","0708ebc6","62910ea8","attach_underbarrel","attach_paintjob","attach_ammo","attach_optic","bolt","collision","2fd3e0ab","e49dc817","844d8f31","1a1a631b","419adae5","da7ca8d3","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","dc0a2993"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,12,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,3,30,30,30,30,30,30,3,37,37,37,37,37,17},["members"]={{["hash"]="7f0e355dedbdf3d5",["count"]=17},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="83970097f3d997ad",["count"]=12},{["hash"]="cdf28be026bb7d84",["count"]=44},{["hash"]="e6b6467135035059",["count"]=13}}},["ce063aa33d95a812"]={["path"]="content/fac_helldivers/equipment/primary_weapons/assault_rifle_rico/assault_rifle_rico",["sidearm"]=false,["count"]=38,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","43a46be8","shadow_mesh","2c65a6c2","cb546116","4e9ae4f2","3204b291","skeleton","root","boss","IK_right","IK_left","mag_release","attach_muzzle","cog","sight","attach_optic","bolt_carrier","attach_underbarrel","attach_paintjob","attach_ammo","attach_mag","ejector","bolt","collision","20b6c93b","00a7f137","c_bodycollisionbot","game_mesh","3ecdc95a","23793ff5","525177d7","de374642","4bd67a74","dc0a2993","trigger","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,25,25,25,2,29,29,29,29,29,23,10,15},["members"]={{["hash"]="129e5fb1b13c2018",["count"]=12},{["hash"]="2383b0439f0bc465",["count"]=11},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="89cce4d15db88aa8",["count"]=16},{["hash"]="ce063aa33d95a812",["count"]=38}}},["cf8934ff6567a42d"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/smart_pistol/smart_pistol",["sidearm"]=true,["count"]=44,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","smart_pistol","shadow_mesh","89e93a33","a38ff90b","5e8b4e9a","d3e3396e","skeleton","root","boss","IK_right","cog","IK_left","sight","attach_underbarrel","attach_ammo","attach_muzzle","attach_paintjob","ejector","c01bab52","6adbf6fa","816cb1fe","868c726e","safety","trigger","attach_mag","slide","extractor","scope","g_lens","collision","5be474d2","b4afc5cb","game_mesh","e78ce0be","5f90c6cd","141c8c53","a5c34325","eacdd203","dc0a2993","1523169d","pivot","eye"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,27,27,29,2,31,31,2,34,34,34,34,34,19,10,12,14},["members"]={{["hash"]="11eccafa4b56a49c",["count"]=6},{["hash"]="6b9572ac0f687394",["count"]=6},{["hash"]="cf8934ff6567a42d",["count"]=44},{["hash"]="fc1f0a3b3fc97238",["count"]=15}}},["d323de60855898ac"]={["path"]="content/fac_helldivers/equipment/primary_weapons/pump_shotgun_dragon/pump_shotgun_dragon",["sidearm"]=false,["count"]=75,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","ab48a76f","shadow_mesh","a907eaf9","dc0336de","e0f74e53","33e297ee","skeleton","root","boss","IK_right","acb10a6a","493514d1","86dd3fb2","7d8a61e7","e85c3034","9111ef9b","18094134","sight","attach_optic","cog","ejector","mag_l","9236ee9a","mag_r","80238eb6","eject_hatch","attach_muzzle","5f0e5b37","attach_paintjob","attach_ammo","feed_hatch_r","feed_hatch_l","mag_r_follower","f616be64","cb85f6fe","8cce08a0","610a417c","36797a16","315b8a8e","ab33b01a","fc9deaaa","mag_l_follower","9e7f8ad1","20251582","d39739e4","2eafa8c7","691b8462","3e8abcfc","c03047ad","36d71d1b","tube_selector","feed_shell","2c05971d","81aab155","pump","IK_left","attach_underbarrel","62910ea8","0708ebc6","fire_selector","bolt","collision","c_culling","0bf48bf9","5dd2c3c7","8755602b","game_mesh","f11ad31c","9384dec7","d1f3e254","b5c2cf4e","43f9d5c4","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,23,10,25,10,10,10,10,10,10,10,10,34,34,34,34,34,34,34,34,10,43,43,43,43,43,43,43,43,10,10,53,53,10,56,56,10,10,10,10,2,63,63,63,63,2,68,68,68,68,68,21},["members"]={{["hash"]="9dbc8aa8702ac9e1",["count"]=12},{["hash"]="d323de60855898ac",["count"]=75},{["hash"]="e0e097b347bdfe6c",["count"]=11},{["hash"]="f401191f6b5a7879",["count"]=5}},["support_envelope"]={["min"]={0.22358697652816772,0.055989187210798264,-0.20172667503356934},["max"]={0.36031630635261536,0.07200483977794647,-0.17793063819408417}}},["d6b1fb05b9109353"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/stim_pistol_01/stim_pistol",["sidearm"]=true,["count"]=46,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","f163d17b","shadow_mesh","f5a50305","009c5461","cef7e5c7","3064bd1a","skeleton","root","IK_left","IK_right","cog","sight","attach_ammo","attach_paintjob","feed_bullet","e90b0925","cylinder_swivel","cylinder","eject_rod","bullet_1","99971250","bullet_2","3417ea15","bullet_3","61973ece","bullet_4","0dc35982","bullet_5","fc63429a","bullet_6","dd72e985","attach_mag","hammer","attach_muzzle","collision","c_collision_02","c_collision_01","game_mesh","fe38ebe2","5e6c91a9","c64b88c1","6ae86668","5f96413c","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,9,9,9,9,9,9,16,9,18,19,20,21,20,23,20,25,20,27,20,29,20,31,18,9,9,2,36,36,2,39,39,39,39,39,12},["members"]={{["hash"]="4431931242cbcd54",["count"]=5},{["hash"]="7de84a343186671f",["count"]=11},{["hash"]="d6b1fb05b9109353",["count"]=46},{["hash"]="e98a9be765e0e236",["count"]=5}}},["dbb6c961c59fadc1"]={["path"]="content/fac_helldivers/equipment/sidearm_weapons/pistol_shark/pistol_shark",["sidearm"]=true,["count"]=32,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","13363b98","shadow_mesh","e506e6e4","d345bbc0","4bf00024","ac0ee5df","skeleton","root","boss","extractor","bolt_handle","trigger","IK_right","cog","IK_left","sight","attach_ammo","attach_muzzle","attach_paintjob","ejector","attach_mag","collision","c_culling","c_collision","game_mesh","3af68ab2","4b9c4b00","6ab79752","9421190e","a0cad59e"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,2,23,23,2,26,26,26,26,26},["members"]={{["hash"]="20e05bca458a39e8",["count"]=5},{["hash"]="619795f79ceda1b3",["count"]=15},{["hash"]="dbb6c961c59fadc1",["count"]=32}}},["dcd1c835407ef7ba"]={["path"]="content/fac_helldivers/equipment/primary_weapons/pump_shotgun_trench/pump_shotgun_trench",["sidearm"]=false,["count"]=38,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","304f91d7","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","collision","65132739","skeleton","root","boss","7d8a61e7","e85c3034","9111ef9b","18094134","IK_right","sight","attach_optic","cog","ejector","shell","704f9a15","trigger","attach_muzzle","attach_underbarrel","attach_paintjob","feed_hatch","pump","IK_left","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","dc0a2993"},["parents"]={0,0,1,2,3,3,3,3,2,8,2,10,11,12,12,12,12,12,12,12,12,12,12,22,12,12,12,12,12,12,29,2,31,31,31,31,31,21},["members"]={{["hash"]="36e235816805c17e",["count"]=5},{["hash"]="8a35c1dc19f41870",["count"]=10},{["hash"]="dcd1c835407ef7ba",["count"]=38},{["hash"]="f40dea68b213b005",["count"]=11}},["support_envelope"]={["min"]={0.2065672129392624,-0.0005329856649041176,-0.17406418919563293},["max"]={0.2848285734653473,0.008544680662453175,-0.16042183339595795}}},["e5796355a8fd67e0"]={["path"]="content/fac_helldivers/equipment/primary_weapons/marksman_rifle_drake/marksman_rifle_drake",["sidearm"]=false,["count"]=39,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","eec71426","shadow_mesh","2c65a6c2","cb546116","4e9ae4f2","3204b291","skeleton","root","boss","trigger","IK_right","IK_left","sight","cog","attach_muzzle","attach_underbarrel","attach_optic","fire_selector","dust_cover","mag_release","bolt_handle","attach_paintjob","attach_ammo","attach_mag","ejector","bolt","collision","c_bodycollisionbot","00a7f137","b8de7a43","game_mesh","3ecdc95a","23793ff5","525177d7","de374642","4bd67a74","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,28,28,28,2,32,32,32,32,32,15},["members"]={{["hash"]="03e67a19b07c6523",["count"]=38},{["hash"]="07d605bd50c98461",["count"]=16},{["hash"]="44a2a59ca08ac865",["count"]=12},{["hash"]="642f2be0417d0beb",["count"]=15},{["hash"]="6d54652ee217d712",["count"]=12},{["hash"]="6e68194b95d60145",["count"]=38},{["hash"]="7b153e02ad22d12c",["count"]=12},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="9b30d4ac39ddff10",["count"]=16},{["hash"]="bd4245dcfd4b832f",["count"]=11},{["hash"]="bdbefa6543a75942",["count"]=22},{["hash"]="e5796355a8fd67e0",["count"]=39}}},["e6d932be83729076"]={["path"]="content/fac_helldivers/equipment/primary_weapons/lever_action_rifle_01/lever_action_rifle_01",["sidearm"]=false,["count"]=41,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","9362111a","shadow_mesh","2c65a6c2","cb546116","4e9ae4f2","3204b291","skeleton","root","boss","attach_optic","ejector","IK_left","IK_right","cog","bolt","lever","bullet_04","bullet_03","bullet_02","bullet_01","feed_ramp","hammer","attach_muzzle","feed_round","e90b0925","trigger","sight","attach_paintjob","attach_ammo","collision","c_collision","game_mesh","3ecdc95a","23793ff5","525177d7","de374642","4bd67a74","pivot","attach_underbarrel"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,25,10,10,10,10,2,31,2,33,33,33,33,33,15,10},["members"]={{["hash"]="44a2a59ca08ac865",["count"]=12},{["hash"]="cda482684a202fd2",["count"]=4},{["hash"]="e6d932be83729076",["count"]=41}}},["eea5e3cef1e12c14"]={["path"]="content/fac_helldivers/equipment/primary_weapons/plasma_rifle/plasma_rifle",["sidearm"]=false,["count"]=46,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","1e1a3264","shadow_mesh","6204432b","aa6e37ef","70f28c4f","b5fb6bea","skeleton","root","boss","trigger","IK_right","cog","magazine_tilt","attach_mag","IK_left","attach_underbarrel","sight","attach_optic","base_l_occelator","l_occelator_01","l_occelator_02","l_occelator_03","l_occelator_04","l_occelator_05","base_r_occelator","r_occelator_05","r_occelator_04","r_occelator_03","r_occelator_02","r_occelator_01","attach_ammo","attach_paintjob","attach_muzzle","collision","b8de7a43","c_bodycollisionbot","c_bodycollisiontop","game_mesh","8fad8181","63484386","2511323a","0632e8b0","dcc6f9b6","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,14,10,10,10,10,10,20,20,20,20,20,10,26,26,26,26,26,10,10,10,2,35,35,35,2,39,39,39,39,39,13},["members"]={{["hash"]="193becdf64aa66a9",["count"]=12},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="3d58ea61b2b485cc",["count"]=12},{["hash"]="80f0a339e905d2d3",["count"]=12},{["hash"]="bc9182001d0312bd",["count"]=13},{["hash"]="eea5e3cef1e12c14",["count"]=46},{["hash"]="efdcef306cea63fe",["count"]=47}}},["efdcef306cea63fe"]={["path"]="content/fac_helldivers/equipment/primary_weapons/plasma_rifle_charge/plasma_rifle_charge",["sidearm"]=false,["count"]=47,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","7c61752a","shadow_mesh","21480989","b8d7027c","214966ea","84281931","skeleton","root","boss","IK_right","cog","magazine_tilt","attach_mag","IK_left","attach_underbarrel","sight","attach_optic","base_l_occelator","l_occelator_01","l_occelator_02","l_occelator_03","l_occelator_04","l_occelator_05","base_r_occelator","r_occelator_05","r_occelator_04","r_occelator_03","r_occelator_02","r_occelator_01","attach_ammo","attach_paintjob","attach_muzzle","collision","c_culling","b8de7a43","c_bodycollisionbot","c_bodycollisiontop","game_mesh","c93c88dc","dd66efc6","47b55711","115dec15","cc328150","trigger","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,13,10,10,10,10,10,19,19,19,19,19,10,25,25,25,25,25,10,10,10,2,34,34,34,34,2,39,39,39,39,39,10,12},["members"]={{["hash"]="193becdf64aa66a9",["count"]=12},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="3d58ea61b2b485cc",["count"]=12},{["hash"]="80f0a339e905d2d3",["count"]=12},{["hash"]="bc9182001d0312bd",["count"]=13},{["hash"]="eea5e3cef1e12c14",["count"]=46},{["hash"]="efdcef306cea63fe",["count"]=47}}},["f0338468dcdb6a6c"]={["path"]="content/fac_helldivers/equipment/primary_weapons/marksman_rifle_justice/marksman_rifle_justice",["sidearm"]=false,["count"]=35,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","ea2d968c","shadow_mesh","20912c1a","87fc1acf","30607087","4a538ecf","collision","57188444","skeleton","root","boss","attach_underbarrel","mag_release","bolt_handle","IK_right","cog","IK_left","sight","attach_optic","bolt_cover","attach_mag","attach_muzzle","attach_paintjob","attach_ammo","fire_selector","ejector","bolt","game_mesh","8479b5bd","36639934","cbe07d5e","7b5d86fb","c327e1b0"},["parents"]={0,0,1,2,3,3,3,3,2,8,2,10,11,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,2,29,29,29,29,29},["members"]={{["hash"]="44a2a59ca08ac865",["count"]=12},{["hash"]="462fc89d4903b33d",["count"]=18},{["hash"]="7441b048b94491fc",["count"]=12},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="f0338468dcdb6a6c",["count"]=35}}},["f49227a0630a3f7f"]={["path"]="content/fac_helldivers/equipment/primary_weapons/crossbow_greyfax/crossbow_greyfax",["sidearm"]=false,["count"]=50,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","6b56207c","shadow_mesh","2afee033","669003b8","412d305c","fc0fbda9","collision","c_culling","e86b94d0","07f40e32","cbbd9fd8","c_body","skeleton","root","boss","IK_right","sight","motor","stringwrangler_l","stringwrangler_r","bow_l","bow_mid_l","bow_tip_l","wheel_l","anchorstring_l","bow_r","bow_mid_r","bow_tip_r","wheel_r","anchorstring_r","sear","attach_muzzle","IK_left","cog","attach_optic","launch","1e960311","attach_underbarrel","attach_paintjob","attach_ammo","attach_mag","feed_lever","game_mesh","b078eff1","b16bd4ff","9d69abab","6fcf7daf","9f3ef7e6"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,8,8,2,14,15,16,16,16,16,16,16,22,23,24,25,16,27,28,29,30,16,16,16,16,16,16,37,16,16,16,16,16,2,44,44,44,44,44},["members"]={{["hash"]="3d58ea61b2b485cc",["count"]=12},{["hash"]="820ac4b5db9b2585",["count"]=20},{["hash"]="8f063c5d3929316e",["count"]=6},{["hash"]="f49227a0630a3f7f",["count"]=50}}},["f992ce97577c8a7f"]={["path"]="content/fac_helldivers/equipment/primary_weapons/volley_gun/volley_gun",["sidearm"]=false,["count"]=40,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","07f0c69e","shadow_mesh","e104edae","236710c1","b37d0f4a","725b519d","collision","c_collision_03","c_collision_02","c_collision_01","skeleton","root","boss","hinge","IK_left","b193e9e2","f5c2ebc6","152c80cb","muzzle_04","muzzle_03","muzzle_02","attach_optic","51c7f869","attach_mag","IK_right","cog","sight","attach_ammo","trigger","game_mesh","7ea7cf42","0eaacc9f","2d5fce92","dc85cb65","d8a430b8","1523169d","pivot","38ba3d76"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,2,12,13,14,15,15,15,15,15,15,15,15,15,15,14,14,14,14,14,2,31,31,31,31,31,14,27,28},["members"]={{["hash"]="129e5fb1b13c2018",["count"]=12},{["hash"]="618c00f2f115c1fe",["count"]=26},{["hash"]="f992ce97577c8a7f",["count"]=40}},["support_envelope"]={["min"]={0.3563593626022339,0.017001451924443245,-0.12178836762905121},["max"]={0.38178011775016785,0.053007762879133224,-0.11664652824401855}}},["02eecd0b1fa49630"]={["path"]="content/fac_helldivers/equipment/support_weapons/grenade_launcher/grenade_launcher",["sidearm"]=false,["count"]=40,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","8712a95b","shadow_mesh","d6aa7c38","8a19dbbd","b22f7c93","56d7d038","skeleton","root","boss","IK_right","b232fef2","attach_optic","sight","cog","IK_left","5334cb8a","attach_ammo","attach_paintjob","barrel","attach_muzzle","bolt","attach_mag","topcover","9a4d6951","5c4f429f","charging_handle","collision","c_collision_04","c_collision_03","c_collision_02","c_collision_01","game_mesh","47c6d6cd","516b2964","b9f4d620","0e125e74","ec4cc978","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,20,10,10,10,24,24,10,2,28,28,28,28,2,33,33,33,33,33,15},["members"]={{["hash"]="02eecd0b1fa49630",["count"]=40},{["hash"]="68513d59bafa8c7a",["count"]=6},{["hash"]="b98f2b3d1bde24b0",["count"]=48},{["hash"]="fa6f926a77b78b55",["count"]=12}}},["11c27d3babb38956"]={["path"]="content/fac_helldivers/equipment/support_weapons/machinegun/machinegun",["sidearm"]=false,["count"]=46,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","e994e9e9","shadow_mesh","8f998342","97fcfe68","817d30f2","83c9fe1a","game_mesh","da874826","b34be51e","3e2c3cb2","16092557","bdae5555","skeleton","root","boss","IK_right","ejector","cog","IK_left","sight","feed_plate","bipod_swivel","r_bipod","l_bipod","attach_mag","attach_ammo","attach_paintjob","f528bc44","bolt","barrel","barrel_handle","attach_muzzle","topcover","attach_optic","feed_arm","bolthandle","bolthandle_pivot","collision","20b6c93b","b8de7a43","c_bodycollisionbot","c_bodycollisiontop","12cda115","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,8,8,2,14,15,16,16,16,16,16,16,16,23,23,16,16,16,16,16,16,31,31,16,34,34,16,37,2,39,39,39,39,0,19},["members"]={{["hash"]="11c27d3babb38956",["count"]=46},{["hash"]="3d58ea61b2b485cc",["count"]=12},{["hash"]="66cb402846eaaa31",["count"]=6},{["hash"]="7b153e02ad22d12c",["count"]=12},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="9d81323b153dc429",["count"]=43}}},["2152d5147b0ac418"]={["path"]="content/fac_helldivers/equipment/support_weapons/heavy_mg/heavy_mg",["sidearm"]=false,["count"]=39,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","c2209e32","shadow_mesh","c8da1a4c","ff081e80","f7b9e637","9f33d270","collision","15efc995","a590479a","d0925e93","c_collision_body","skeleton","root","IK_right","7d99cc77","sight","b232fef2","attach_muzzle","cog","IK_left","attach_underbarrel","eject_port","bolt","bolt_lever","feed_tray","attach_optic","bipod_r","bipod_l","attach_mag","game_mesh","f5f49ab5","3dd34639","3f57e4a4","9c297c53","ed55ab61","12cda115","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,8,2,13,14,14,14,14,14,14,14,14,14,14,14,14,26,14,14,14,2,31,31,31,31,31,0,20},["members"]={{["hash"]="085c1edb038ec24e",["count"]=39},{["hash"]="17c6e9bafcd646d2",["count"]=6},{["hash"]="2152d5147b0ac418",["count"]=39},{["hash"]="45be635fb904f4dc",["count"]=12},{["hash"]="66cb402846eaaa31",["count"]=6},{["hash"]="b7cd35e0edc15cd7",["count"]=38}}},["25aa2fd4643cf4ee"]={["path"]="content/fac_helldivers/equipment/support_weapons/faf_missile_launcher/faf_missile_launcher",["sidearm"]=false,["count"]=32,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","0b03553b","shadow_mesh","d6aa7c38","8a19dbbd","b22f7c93","56d7d038","collision","5be474d2","c_body","skeleton","boss","IK_right","cog","muzzle","attach_optic","foregrip","IK_left","IK_right_assisted","IK_left_assisted","attach_mag","sight","attach_ammo","game_mesh","47c6d6cd","516b2964","b9f4d620","0e125e74","ec4cc978","eye","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,2,11,12,12,12,12,12,17,12,12,12,12,12,2,24,24,24,24,24,12,14},["members"]={{["hash"]="1f012c3a0fa74fe2",["count"]=10},{["hash"]="25aa2fd4643cf4ee",["count"]=32},{["hash"]="48fd06b465e8b681",["count"]=15},{["hash"]="8666e5f49f440d44",["count"]=12},{["hash"]="8ec3026b5f2e579a",["count"]=47}}},["26e40437ea275296"]={["path"]="content/fac_helldivers/equipment/support_weapons/air_burst_rocket_launcher/air_burst_rocket_launcher",["sidearm"]=false,["count"]=38,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","66133053","shadow_mesh","d6aa7c38","8a19dbbd","b22f7c93","56d7d038","game_mesh","47c6d6cd","516b2964","b9f4d620","0e125e74","ec4cc978","collision","c_culling","c_collision_03","c_collision_02","c_collision_01","skeleton","root","boss","IK_right","attach_optic","sight","attach_ammo","cog","IK_right_assisted","IK_left_assisted","handgrip","frontgrip_hinge","frontgrip","IK_left","shoulder_rest","muzzle","63527181","rocket","deacc868"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,8,8,2,14,14,14,14,2,19,20,21,21,21,21,21,21,21,21,21,30,31,21,21,21,21,36},["members"]={{["hash"]="2457b559aa341cc1",["count"]=12},{["hash"]="26e40437ea275296",["count"]=38},{["hash"]="36ab9a3dcae3d562",["count"]=7}}},["2e9d0bdc48b09e60"]={["path"]="content/fac_helldivers/equipment/support_weapons/railgun/railgun",["sidearm"]=false,["count"]=39,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","09997a41","771afd31","shadow_mesh","de3a2b1d","28ec037a","4a6d0369","b347d762","skeleton","root","boss","IK_right","attach_optic","cog","flange_l_bot","flange_l_top","flange_r_bot","flange_r_top","IK_left","a96eb126","b232fef2","sight","d772cd8c","attach_mag","attach_ammo","muzzle","attach_paintjob","collision","7b758e16","770a9c34","game_mesh","12b31a5f","f8cc6c83","68dd3285","87f75745","fba13298","ab8ca866","pivot"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,3,28,28,3,31,31,31,31,31,31,14},["members"]={{["hash"]="2e9d0bdc48b09e60",["count"]=39},{["hash"]="503c0e01fbafa86a",["count"]=15},{["hash"]="b2d5147255a12545",["count"]=6},{["hash"]="e8ffad77b73c221c",["count"]=7},{["hash"]="f5e1e4bd4ecdc192",["count"]=13}}},["35a61296619cc47e"]={["path"]="content/fac_helldivers/equipment/support_weapons/laser_pulse_cannon/laser_pulse_cannon",["sidearm"]=false,["count"]=41,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","1a1fcacf","shadow_mesh","bd6f92b2","d34e67aa","7db44f6a","ab402dc7","skeleton","root","boss","IK_right","attach_mag","attach_muzzle","spinner","IK_left","attach_optic","cog","attach_ammo","attach_paintjob","0893545f","8a38df10","c5a8dba5","f2e6ef91","033cfd08","7e4a3abd","collision","c_collision_06","c_collision_05","c_collision_04","c_collision_03","c_collision_02","c_collision_01","game_mesh","4110cd9f","bd76db3a","9e746249","41e99707","90d5d749","fba13298","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,26,26,26,26,26,26,2,33,33,33,33,33,33,17},["members"]={{["hash"]="2457b559aa341cc1",["count"]=12},{["hash"]="35a61296619cc47e",["count"]=41},{["hash"]="612f7f6193fb1b2b",["count"]=9},{["hash"]="b2d5147255a12545",["count"]=6},{["hash"]="d54b9505c0f72873",["count"]=37}}},["3828e2051aa9e897"]={["path"]="content/fac_helldivers/equipment/support_weapons/harpoon_gun/harpoon_gun",["sidearm"]=false,["count"]=47,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","c8810b52","shadow_mesh","3a5ecd77","67698c28","2cbf61a0","7480436e","skeleton","root","boss","attach_underbarrel","muzzle","IK_right","cog","sight","attach_optic","attach_paintjob","attach_ammo","IK_left","teeth_R7","teeth_R6","teeth_R5","teeth_R4","teeth_R3","teeth_R2","teeth_R1","teeth_L7","teeth_L6","teeth_L5","teeth_L4","teeth_L3","teeth_L2","teeth_L1","feed_bullet","feed_bullet_scale","trigger","0989d007","collision","c_collision","game_mesh","a0e2059e","1e63883f","932f39e0","21d16fbb","498ef13f","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,34,10,10,2,38,2,40,40,40,40,40,14},["members"]={{["hash"]="3828e2051aa9e897",["count"]=47},{["hash"]="3d58ea61b2b485cc",["count"]=12},{["hash"]="503c0e01fbafa86a",["count"]=15},{["hash"]="f21e8dd5e27fef7c",["count"]=3}}},["39ab99895147a3bf"]={["path"]="content/fac_helldivers/equipment/support_weapons/flamethrower/flamethrower",["sidearm"]=false,["count"]=33,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","22f196c0","6bbbded7","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","cog","IK_right","igniter","muzzle","IK_left","grip_hinge","trigger","sight","mag_seater_collar","mag_seater_handle","mag_attach","collision","c_body","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","attach_mag","pivot"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,11,11,11,11,11,11,11,11,20,11,3,23,3,25,25,25,25,25,22,12},["members"]={{["hash"]="39ab99895147a3bf",["count"]=33},{["hash"]="444880f62ca7eae8",["count"]=40},{["hash"]="9c22a90da9c79de3",["count"]=11}}},["43a58cb89cfa197c"]={["path"]="content/fac_helldivers/equipment/support_weapons/minigun/minigun",["sidearm"]=false,["count"]=33,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","19f51b02","shadow_mesh","39733d43","ea397304","3d0ef161","8e6edcf7","collision","31d6186b","c_culling","c_collision","skeleton","root","boss","trigger","barrel_rotator","hose_connector","IK_right","IK_left","attach_muzzle","cog","sight","attach_paintjob","attach_ammo","attach_mag","ejector","game_mesh","ca8871b5","f82c30f2","7c674184","e1e669bf","2abe6b3c"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,2,12,13,14,14,14,14,14,14,14,14,14,14,14,14,2,27,27,27,27,27},["members"]={{["hash"]="056de1c5e21e723e",["count"]=27},{["hash"]="43a58cb89cfa197c",["count"]=33},{["hash"]="66cb402846eaaa31",["count"]=6},{["hash"]="7fdd884ecd57231b",["count"]=6},{["hash"]="9ba9f700137c6325",["count"]=26}}},["52071f49263415e4"]={["path"]="content/fac_super_earth/equipment/support_weapons/shotgun_doublebarrel/shotgun_doublebarrel",["sidearm"]=false,["count"]=35,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","8abdda19","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_right","trigger","break_lever","barrel_pivot","IK_left","ejector","attach_mag","attach_mag_2","attach_underbarrel","attach_optic","b005baed","4748e782","sight","attach_paintjob","attach_ammo","collision","451193cc","a2df1bbf","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,14,14,16,16,14,14,14,14,10,10,10,2,26,26,2,29,29,29,29,29},["members"]={{["hash"]="0ec5ef9ec5cbd1b2",["count"]=5},{["hash"]="52071f49263415e4",["count"]=35}}},["5990123d142b16cb"]={["path"]="content/fac_helldivers/equipment/support_weapons/laser_guided_missile_launcher/laser_guided_missile_launcher",["sidearm"]=false,["count"]=42,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","063feab2","shadow_mesh","d6aa7c38","8a19dbbd","b22f7c93","56d7d038","skeleton","root","boss","puller_t_r","cover_t_r","puller_t_l","cover_t_l","puller_b_l","cover_b_l","puller_b_r","cover_b_r","muzzle_04","muzzle_03","muzzle_02","muzzle","IK_right","cog","IK_left","sight","attach_optic","attach_paintjob","collision","15efc995","63d003f4","c_collision","game_mesh","47c6d6cd","516b2964","b9f4d620","0e125e74","ec4cc978","cffa3f22","51c7f869","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,11,10,13,10,15,10,17,10,10,10,10,10,10,10,10,10,10,2,29,29,29,2,33,33,33,33,33,10,22,24},["members"]={{["hash"]="2457b559aa341cc1",["count"]=12},{["hash"]="5990123d142b16cb",["count"]=42},{["hash"]="afd03c31434b6ee5",["count"]=12}}},["6cfcc7f8801a0266"]={["path"]="content/fac_helldivers/equipment/support_weapons/energy_weapon_shark/energy_weapon_shark",["sidearm"]=false,["count"]=36,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","8eda8216","shadow_mesh","1bd41161","7c63b8ed","7edb8506","34fda05d","collision","c_culling","28de584b","e587b4f4","c_collision2","c_collision1","skeleton","boss","hose_jiggle_01","hose_jiggle_02","attach_mag","trigger","mag_hinge","front_grip_hinge_01","front_grip_hinge_02","IK_left","attach_muzzle","IK_right","sight","cog","attach_ammo","attach_paintjob","game_mesh","043b139e","be8c9092","e992022d","7b25405b","cc14247d"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,8,8,2,14,15,16,15,15,15,15,21,22,15,15,15,15,15,15,2,30,30,30,30,30},["members"]={{["hash"]="076692fd83a83c5c",["count"]=10},{["hash"]="2457b559aa341cc1",["count"]=12},{["hash"]="6cfcc7f8801a0266",["count"]=36}}},["7617642765ac38c7"]={["path"]="content/fac_helldivers/equipment/support_weapons/expendable_massive_rocket_launcher/expendable_massive_rocket_launcher",["sidearm"]=false,["count"]=32,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","6ac4a87c","shadow_mesh","d96a6f52","4010cce4","48ecaf2f","98bef142","skeleton","root","boss","trigger","arming_latch","right_grip_pivot","IK_right","left_grip_pivot","IK_left","48b9ebdd","d6f9fd2b","cog","sight","attach_ammo","muzzle","collision","c_culling","c_collision","game_mesh","01c5f14c","7c47c6cd","e15b658e","82907b11","4fa4bd35"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,13,10,15,10,10,10,10,10,10,2,23,23,2,26,26,26,26,26},["members"]={{["hash"]="0511db0bca94fa78",["count"]=7},{["hash"]="7617642765ac38c7",["count"]=32}}},["78a8185f63a70795"]={["path"]="content/fac_helldivers/equipment/support_weapons/heavy_flamethrower/heavy_flamethrower",["sidearm"]=false,["count"]=31,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","77048df4","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","collision","c_culling","c_collision","31d6186b","skeleton","root","boss","cog","IK_right","igniter","muzzle","IK_left","dial","trigger","sight","hose_connect","valve","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,2,12,13,14,14,14,14,14,14,14,14,14,14,2,25,25,25,25,25},["members"]={{["hash"]="23d09a05d1574ec9",["count"]=27},{["hash"]="43eb1c3c1a1860e0",["count"]=26},{["hash"]="78a8185f63a70795",["count"]=31}}},["80932fa0ed6901d3"]={["path"]="content/fac_helldivers/equipment/support_weapons/lat_oneshot/lat_oneshot",["sidearm"]=false,["count"]=33,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","4d969f91","shadow_mesh","f54cce52","0148e8f6","85850599","792e2995","collision","c_collision","skeleton","root","boss","IK_right","cog","sight","muzzle","IK_left","attach_ammo","attach_paintjob","rear_sight_hinge","rear_sight","attach_optic","rear_sightcover","rear_tube","44480b24","game_mesh","dd250664","cfbd84f0","2b96586b","30394b74","e6578cb7","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,2,10,11,12,12,12,12,12,12,12,12,20,21,12,12,24,2,26,26,26,26,26,14},["members"]={{["hash"]="692eb345969d368e",["count"]=5},{["hash"]="80932fa0ed6901d3",["count"]=33}}},["88c2d09ad85a7c9f"]={["path"]="content/fac_helldivers/equipment/support_weapons/belt_fed_grenade_launcher/belt_fed_grenade_launcher",["sidearm"]=false,["count"]=38,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","4a2892d7","shadow_mesh","8050987d","24b2314c","9258047b","ab5be11d","collision","31d6186b","c_culling","c_collision","skeleton","root","boss","hose_connector","charge_lever_base","charge_lever_01","charge_lever_02","hook","bolt","top_cover","trigger","IK_right","IK_left","attach_muzzle","cog","sight","attach_paintjob","attach_ammo","attach_mag","ejector","game_mesh","f1a0fadf","e955300d","e15fa617","5ebc92bd","58716ee2"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,2,12,13,14,14,16,17,14,14,14,14,14,14,14,14,14,14,14,14,14,2,32,32,32,32,32},["members"]={{["hash"]="88c2d09ad85a7c9f",["count"]=38},{["hash"]="bb4b15b588f974fd",["count"]=27},{["hash"]="bf7082f0287c254f",["count"]=27},{["hash"]="cba5983612dace3f",["count"]=5}}},["89c5493e08ca4207"]={["path"]="content/fac_helldivers/equipment/support_weapons/sniper_rifle/sniper_rifle",["sidearm"]=false,["count"]=39,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","d28122d2","shadow_mesh","c4a1d881","27a837b4","c372217f","450a8e24","skeleton","root","boss","IK_right","attach_optic","sight","cog","bipod_leg_l","bipod_leg_r","bipod","IK_left","attach_muzzle","ejector","mag_release","attach_mag","attach_ammo","attach_paintjob","barrel","barrel_jiggle","bolt","fireselector","collision","968ff500","c_body","game_mesh","175f53c9","1a26b734","d69497c1","b41f604d","g_reciever","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,25,10,10,2,29,29,2,32,32,32,32,32,14},["members"]={{["hash"]="17c6e9bafcd646d2",["count"]=6},{["hash"]="6d54652ee217d712",["count"]=12},{["hash"]="6e165f05a49233f6",["count"]=14},{["hash"]="89c5493e08ca4207",["count"]=39}}},["96de9cd50f7306e6"]={["path"]="content/fac_helldivers/equipment/support_weapons/arc_thrower/arc_thrower",["sidearm"]=false,["count"]=44,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","7aa1d925","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_right","turbine","cog","attach_optic","IK_left","trigger","sight","prong_arm_right_01","prong_arm_right_02","ead5bed3","2efc8aa0","prong_arm_left_01","prong_arm_left_02","b3a437b2","38cc9373","prong_arm_bot_01","prong_arm_bot_02","08a07cfd","7d2d8d7d","attach_muzzle","a96eb126","attach_paintjob","collision","bba5edef","06f9e096","c_body","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,18,19,19,10,22,23,23,10,26,27,27,10,30,10,2,33,33,33,2,37,37,37,37,37,13},["members"]={{["hash"]="96de9cd50f7306e6",["count"]=44},{["hash"]="f5e1e4bd4ecdc192",["count"]=13}}},["9f80d67a12a7e40f"]={["path"]="content/fac_helldivers/equipment/support_weapons/recoilless_rifle/recoilless_rifle",["sidearm"]=false,["count"]=42,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","63023a8f","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_right","IK_left","cog","attach_optic","IK_right_assisted","IK_left_assisted","sight","attach_ammo","carry_handle","port_lock","loadport","ejector","babc9a10","7c52f939","muzzle","collision","c0978950","950d0d7f","de3732c0","c_bodycollisionbot","b15f6467","7ca89f21","1b1e49e6","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","attach_mag","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,22,22,10,2,26,26,26,26,26,26,26,2,34,34,34,34,34,22,13},["members"]={{["hash"]="2457b559aa341cc1",["count"]=12},{["hash"]="9f80d67a12a7e40f",["count"]=42},{["hash"]="db50297b40133d12",["count"]=13}}},["a8cffb316f0b5c5f"]={["path"]="content/fac_helldivers/equipment/support_weapons/automatic_cannon/automatic_cannon",["sidearm"]=false,["count"]=63,["root"]=3,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","4afbeb29","17135ab9","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_right","cog","attach_optic","IK_right_assisted","IK_left_assisted","b232fef2","sight","attach_mag","front_grip","IK_left","bullet_6","bullet_7","bullet_8","bullet_9","bullet_10","797b003f","a435ec46","e8d00c85","b4e1c704","3fb40b75","bullet_1","bullet_2","bullet_3","bullet_4","bullet_5","7dce0876","da9057f5","e16b79a2","2398aee7","451f2b0d","attach_ammo","attach_paintjob","toggle_lock_01","toggle_lock_02","breach","extractor","barrel_shroud","attach_muzzle","bolt_handle","bolt_handle_swivel","collision","5be474d2","02df96b4","8698affb","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","pivot"},["parents"]={0,0,1,1,3,4,4,4,4,3,9,10,11,11,11,11,11,11,11,11,11,20,11,22,23,24,25,26,25,24,23,22,11,32,33,34,35,36,35,34,33,32,11,11,11,44,45,46,11,48,11,50,3,52,52,52,3,56,56,56,56,56,13},["members"]={{["hash"]="2457b559aa341cc1",["count"]=12},{["hash"]="9bc319730887bdd8",["count"]=5},{["hash"]="a8cffb316f0b5c5f",["count"]=63},{["hash"]="a91e4527859ada75",["count"]=5}}},["b16c9d490aa59b77"]={["path"]="content/fac_helldivers/equipment/support_weapons/expendable_machinegun/expendable_machinegun",["sidearm"]=false,["count"]=51,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","86a8ef9c","shadow_mesh","10c3e9d9","4dd0de8e","2f47811d","2060885e","collision","c_culling","c_collision_03","c_collision_02","skeleton","root","boss","fa4eecfc","47430228","11f9bafc","0c0d1871","82a6c59f","8250b8b4","1225c281","79ed7f9e","6d3b1803","0136f47c","bd0cd405","dba0e8d5","eafe2bd7","bcc0f8a6","e64e4b2e","842cacb2","e736dd53","51c7f869","muzzle_02","muzzle_03","muzzle_04","152c80cb","f5c2ebc6","b193e9e2","IK_left","IK_right","cog","sight","attach_ammo","trigger","game_mesh","fb69240e","9b19f5c3","4d9d6c8e","62977043","ff1abefa"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,2,12,13,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,2,45,45,45,45,45},["members"]={{["hash"]="b16c9d490aa59b77",["count"]=51}}},["b2b5e0d185605f9e"]={["path"]="content/fac_helldivers/equipment/support_weapons/expendable_napalm_launcher/expendable_napalm_launcher",["sidearm"]=false,["count"]=40,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","633ba988","shadow_mesh","c3df0e2d","2fb8d5d5","0cce99bd","3e4de950","skeleton","root","boss","IK_right","IK_left","cog","attach_optic","IK_right_assisted","IK_left_assisted","sight","attach_ammo","carry_handle","port_lock","loadport","ejector","babc9a10","7c52f939","muzzle","collision","c0978950","950d0d7f","de3732c0","c_bodycollisionbot","game_mesh","64d546af","1ff01c41","43a86089","bdc92d01","77d3a88d","dc0a2993","trigger","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,22,22,10,2,26,26,26,26,2,31,31,31,31,31,22,10,13},["members"]={{["hash"]="2457b559aa341cc1",["count"]=12},{["hash"]="b2b5e0d185605f9e",["count"]=40}}},["cc786f6491fe7e65"]={["path"]="content/fac_helldivers/equipment/support_weapons/faf_missile_launcher_helghast/faf_missile_launcher_helghast",["sidearm"]=false,["count"]=39,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","fa6611f4","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_right_assisted","IK_left_assisted","ammo_carrier","loading_rotate","release_handle","release_rot","lock_latch","IK_right","attach_optic","sight","cog","foregrip","IK_left","attach_ammo","attach_paintjob","muzzle","attach_mag","collision","8247c2a9","9851c382","c_body","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","eye"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,14,15,10,10,10,10,10,10,22,10,10,10,10,2,28,28,28,2,32,32,32,32,32,10},["members"]={{["hash"]="46427f2630a80d88",["count"]=12},{["hash"]="6a4c2138009b625e",["count"]=18},{["hash"]="b8feb0cc191c1ef3",["count"]=30},{["hash"]="be0ac4e655b2e19f",["count"]=19},{["hash"]="cc786f6491fe7e65",["count"]=39},{["hash"]="ffb0f21dcc7b5e15",["count"]=10}}},["d54b9505c0f72873"]={["path"]="content/fac_helldivers/equipment/support_weapons/laser_cannon/laser_cannon",["sidearm"]=false,["count"]=37,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","209c90de","shadow_mesh","g_body_shadow_LOD3","g_body_shadow_LOD2","g_body_shadow_LOD1","g_body_shadow","skeleton","root","boss","IK_right","IK_left","attach_optic","cog","attach_ammo","attach_paintjob","attach_muzzle","attach_mag","0893545f","8a38df10","c5a8dba5","f2e6ef91","033cfd08","7e4a3abd","hinge_magwell","collision","c_body","43046ac4","efa421d8","game_mesh","g_body_LOD4","g_body_LOD3","g_body_LOD2","g_body_LOD1","g_body","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2,26,26,26,2,30,30,30,30,30,14},["members"]={{["hash"]="2457b559aa341cc1",["count"]=12},{["hash"]="35a61296619cc47e",["count"]=41},{["hash"]="612f7f6193fb1b2b",["count"]=9},{["hash"]="b2d5147255a12545",["count"]=6},{["hash"]="d54b9505c0f72873",["count"]=37}}},["e8d5f49ad7780e54"]={["path"]="content/fac_helldivers/equipment/support_weapons/plasma_blaster/plasma_blaster",["sidearm"]=false,["count"]=37,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","f419d5a6","shadow_mesh","9fe99bf8","d92964e8","ae5f5c00","66f89355","skeleton","boss","IK_right","greeblies_r","greeblies_l","grip_hinge_01","grip_hinge_02","IK_left","rods_r","rods_l","cog","attach_optic","sight","attach_ammo","attach_mag","attach_muzzle","collision","c_culling","c_collision_01","c_collision_02","c_collision_03","game_mesh","9fe36495","10857bc1","250eae23","515d98dd","fba13298","b502c386","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,9,9,9,13,14,9,9,9,9,9,9,9,9,2,24,24,24,24,2,29,29,29,29,29,29,18},["members"]={{["hash"]="2457b559aa341cc1",["count"]=12},{["hash"]="52ff81fcba0c059d",["count"]=12},{["hash"]="e8d5f49ad7780e54",["count"]=37}}},["fe3b29b2cfa63f9b"]={["path"]="content/fac_helldivers/equipment/support_weapons/grenade_launcher_tactical/grenade_launcher_tactical",["sidearm"]=false,["count"]=55,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","026452d1","shadow_mesh","8b3549f1","2a7272de","d9e867d6","426db226","collision","c_collision","skeleton","root","boss","feed_grenade","3707a7e8","trigger","IK_right","front_part","ammo","extractor","grenade_1","99971250","2d682b57","grenade_2","3417ea15","ba6ed864","grenade_3","61973ece","bcd8ec2a","grenade_4","0dc35982","1b52862d","grenade_5","fc63429a","9e778c11","grenade_6","dd72e985","6cbfb27e","locker","barrel","attach_muzzle","IK_left","cog","sight","attach_paintjob","safety","game_mesh","733f520f","51c70441","437cc61e","51c245f1","f8c8966c","1523169d","pivot","attach_optic"},["parents"]={0,0,1,2,3,3,3,3,2,8,2,10,11,12,13,12,12,12,17,18,19,20,21,19,23,24,19,26,27,19,29,30,19,32,33,19,35,36,17,17,39,12,12,12,12,12,2,46,46,46,46,46,12,42,38},["members"]={{["hash"]="adc87d576c20ad57",["count"]=6},{["hash"]="b98f2b3d1bde24b0",["count"]=48},{["hash"]="fa6f926a77b78b55",["count"]=12},{["hash"]="fe3b29b2cfa63f9b",["count"]=55}}},["a8a91eb54892b6b2"]={["path"]="",["sidearm"]=false,["count"]=43,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","27de5b31","shadow_mesh","16eda938","fde05496","068adae5","869793f1","skeleton","root","boss","button","trigger_lower","pump","attach_underbarrel","attach_mag","trigger","IK_left","cog","attach_optic","shell","shell_scale","sight","bolt_carrier","charging_handle","attach_ammo","attach_muzzle","attach_paintjob","fire_selector","ejector","collision","c_culling","c_body","5be474d2","game_mesh","3671310f","164191d1","64fe506c","41a330ac","43d14e76","dc0a2993","1523169d","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,9,10,10,10,10,10,10,10,10,10,10,20,10,10,10,10,10,10,10,10,2,30,30,30,2,34,34,34,34,34,29,10,18},["members"]={{["hash"]="129e5fb1b13c2018",["count"]=12},{["hash"]="20c03774d6e1d87f",["count"]=13},{["hash"]="7f19d05cd188c768",["count"]=6},{["hash"]="a8a91eb54892b6b2",["count"]=43},{["hash"]="b9c209b4f99b5335",["count"]=24}}},["e91f569c2ad8af01"]={["path"]="",["sidearm"]=true,["count"]=36,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","5b81046c","shadow_mesh","db66530e","11cce350","780549a3","1c3d2a5a","collision","c_culling","c_body","5be474d2","skeleton","root","boss","release_latch","sight","trigger","hinge_pivot","missile","missile_scale","IK_right","cog","attach_optic","IK_left","attach_ammo","attach_paintjob","attach_muzzle","game_mesh","9a2a5add","076f3c9a","51c65bb4","60734a26","633eed1e","1523169d","pivot"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,2,12,13,14,14,14,14,18,19,14,14,14,14,14,14,14,2,28,28,28,28,28,14,22},["members"]={{["hash"]="6b9572ac0f687394",["count"]=6},{["hash"]="ccf18b6315a3d67f",["count"]=7},{["hash"]="e91f569c2ad8af01",["count"]=36},{["hash"]="fc1f0a3b3fc97238",["count"]=15}}},["c85f576d5e086147"]={["path"]="",["sidearm"]=false,["count"]=48,["root"]=2,["names"]={"StingrayEntityRoot","FbxAxisSystem_ConvertNode","laser_smg_blaster","shadow_mesh","10ece956","be1abd8f","a02e573c","afe6eb91","collision","f44ab049","5be474d2","9851c382","908f5891","cbbd9fd8","skeleton","root","boss","attach_underbarrel","attach_optic","sight","IK_right","IK_left","cog","attach_muzzle","trigger","attach_mag","attach_ammo","attach_paintjob","bolt","fireselector","ejector","game_mesh","29a74912","f0274281","8d4c8228","a6b68bde","466a9712","dc0a2993","1523169d","pivot","7e4a3abd","f2e6ef91","8a38df10","033cfd08","c5a8dba5","0893545f","98e969dd","fda371a8"},["parents"]={0,0,1,2,3,3,3,3,2,8,8,8,8,8,2,14,15,16,16,16,16,16,16,16,16,16,16,16,16,16,16,2,31,31,31,31,31,30,16,22,2,2,2,2,2,2,2,15},["members"]={{["hash"]="129e5fb1b13c2018",["count"]=12},{["hash"]="6600b5e755a21f1f",["count"]=12},{["hash"]="679e174bb3bcca68",["count"]=10},{["hash"]="a188cbb5913fbd63",["count"]=10},{["hash"]="c85f576d5e086147",["count"]=48}}}}
    local accessory_specs={{["hash"]="07d605bd50c98461",["count"]=16},{["hash"]="0aae32c4479eaa26",["count"]=12},{["hash"]="129e5fb1b13c2018",["count"]=12},{["hash"]="13a5fc03ec21e8fb",["count"]=14},{["hash"]="16ab263bc03b4f96",["count"]=18},{["hash"]="1b1fcc0e025c1f7d",["count"]=14},{["hash"]="1ec5f54265a91c83",["count"]=16},{["hash"]="2383b0439f0bc465",["count"]=11},{["hash"]="2457b559aa341cc1",["count"]=12},{["hash"]="26ec4f9513fc6525",["count"]=12},{["hash"]="28aee9c6a2282aa3",["count"]=13},{["hash"]="2d761a80bcbfe792",["count"]=18},{["hash"]="2e7f91374c0b471c",["count"]=12},{["hash"]="2ed76d29ce509a74",["count"]=12},{["hash"]="309f7e645a8d2b56",["count"]=14},{["hash"]="316a396d1939a997",["count"]=12},{["hash"]="369b53e850e72ba9",["count"]=18},{["hash"]="37c2891774b38c87",["count"]=18},{["hash"]="3ae1f60c5efd2b43",["count"]=14},{["hash"]="3ae8ba6377efe3ae",["count"]=12},{["hash"]="3d58ea61b2b485cc",["count"]=12},{["hash"]="411c4fd07740a7dd",["count"]=13},{["hash"]="44a2a59ca08ac865",["count"]=12},{["hash"]="45be635fb904f4dc",["count"]=12},{["hash"]="4851d75853622a47",["count"]=15},{["hash"]="4f839e923046e631",["count"]=15},{["hash"]="5c1e075cba68340b",["count"]=12},{["hash"]="6b88fea13ec2d78e",["count"]=12},{["hash"]="6b9572ac0f687394",["count"]=6},{["hash"]="6d54652ee217d712",["count"]=12},{["hash"]="6f5afa606a4400d1",["count"]=17},{["hash"]="7301b3dc5b1bffb8",["count"]=17},{["hash"]="74b9289347cc3503",["count"]=12},{["hash"]="756e3fdaca41cfca",["count"]=12},{["hash"]="75713afac474d9c4",["count"]=12},{["hash"]="77c5d934407114f4",["count"]=17},{["hash"]="78829731a0563576",["count"]=13},{["hash"]="7b153e02ad22d12c",["count"]=12},{["hash"]="7be1e04a7738e673",["count"]=18},{["hash"]="8039834a4b7489b9",["count"]=11},{["hash"]="8cd335a5f711bb59",["count"]=12},{["hash"]="9237ccec8fe86d22",["count"]=14},{["hash"]="9549ff64ba3fd5a1",["count"]=14},{["hash"]="963aca558cd906bc",["count"]=17},{["hash"]="990b06bf5c26bd01",["count"]=12},{["hash"]="9dbc8aa8702ac9e1",["count"]=12},{["hash"]="a0b52d203e689d18",["count"]=13},{["hash"]="a4fa3ef43a8cecaf",["count"]=18},{["hash"]="a9a19cffe985c468",["count"]=12},{["hash"]="aca180fc6f846411",["count"]=12},{["hash"]="b191a4f26558a9cc",["count"]=12},{["hash"]="b1bc2b7252ccbc03",["count"]=12},{["hash"]="b571e0428ca83b9e",["count"]=12},{["hash"]="bd4245dcfd4b832f",["count"]=11},{["hash"]="be4590c2f615c441",["count"]=14},{["hash"]="bfe35746f5084222",["count"]=3},{["hash"]="c70345c3342ca205",["count"]=12},{["hash"]="c891acf9e8dbda97",["count"]=12},{["hash"]="cc4cd9593abb87be",["count"]=17},{["hash"]="d8cf7fe059b4bf1e",["count"]=12},{["hash"]="e6b6467135035059",["count"]=13},{["hash"]="e8de5e95b9635c21",["count"]=18},{["hash"]="ec824b9d8b7f7b58",["count"]=13},{["hash"]="ee89d98cbe33e976",["count"]=18},{["hash"]="f40dea68b213b005",["count"]=11},{["hash"]="f9c6092b665018b8",["count"]=12},{["hash"]="f9df21c8e52cac95",["count"]=13},{["hash"]="f9f37dcce764fad6",["count"]=13},{["hash"]="fa6f926a77b78b55",["count"]=12},{["hash"]="ffc18b2ce10ca381",["count"]=11}}
    local function note(key,message)
      if not logged[key] then logged[key]=true;log("whole-weapon-trial "..message) end
    end
    local function graph_base(unit,count)
      if try(function()return U.alive(unit)end)~=true or
          try(function()return U.num_scene_graph_items(unit)end)~=count then return nil end
      local base=try(function()if U.has_node(unit,"StingrayEntityRoot")then return U.node(unit,"StingrayEntityRoot")end end)
      if base~=0 and base~=1 then return nil end
      return base
    end
    local function graph_snapshot(unit,count)
      local base=graph_base(unit,count)
      if base==nil then return nil end
      local result={unit=unit,base=base,count=count,poses={}}
      for node=base,base+count-1 do
        local p=node_pose_numbers(unit,node)
        if not p then return nil end
        local parent=p.parent
        p.external=parent==nil or parent==-1 or (base==1 and parent==0)
        if not p.external and (type(parent)~="number" or parent~=math.floor(parent) or parent<base or parent>=node) then return nil end
        result.poses[node]=p
      end
      return result
    end
    local function descendants(s,roots)
      local affected={}
      for node=s.base,s.base+s.count-1 do
        local p=s.poses[node]
        if roots[node] or (not p.external and affected[p.parent]) then affected[node]=true end
      end
      return affected
    end
    local function verified_graph(unit,spec)
      local s=graph_snapshot(unit,spec.count)
      if not s then return nil end
      for i,name in ipairs(spec.names) do
        local node=i-1+s.base
        local parent=spec.parents[i]
        if i>1 and parent~=65535 and s.poses[node].parent~=parent+s.base then return nil end
        -- Unresolved hashes are not literal engine node names. Known labels
        -- plus the complete parent topology authenticate their numeric slots.
        if not name:match("^%x%x%x%x%x%x%x%x$") and
            try(function()return U.has_node(unit,name) and U.node(unit,name)end)~=node then return nil end
      end
      s.affected=descendants(s,{[spec.root+s.base]=true})
      return s
    end
    -- A valid graph can have an external parent only at its first row or a
    -- serialized external-parent row. Probe those few current frames before
    -- reading every bone of a dropped/foreign gun. This is rejection only:
    -- possible owners still require the complete original graph verification.
    local function possible_owner(unit,spec,gq,gp)
      local base=graph_base(unit,spec.count)
      if base==nil then return false end
      for i,parent in ipairs(spec.parents) do
        if i==1 or parent==65535 then
          local pose=node_pose_numbers(unit,i-1+base)
          if pose and (pose.parent==nil or pose.parent==-1 or (base==1 and pose.parent==0)) then
            local iq,ip=inverse_pose(pose.local_q,pose.local_p)
            local q,p=compose_pose(pose.world_q,pose.world_p,iq,ip)
            if q and qerror_degrees(q,gq)<0.15 and perror(p,gp)<0.002 then return true end
          end
        end
      end
      return false
    end
    local function support_weight(distance,inner,outer)
      local t=math.max(0,math.min(1,(outer-distance)/(outer-inner)))
      return t*t*(3-2*t)
    end
    local function possible_primary_support(spec,s,right,point)
      local envelope=not spec.sidearm and spec.support_envelope
      if not envelope or not right or not point then return false end
      local r=s.poses[right]
      if not r then return false end
      local iq,ip=inverse_pose(r.world_q,r.world_p)
      if not iq then return false end
      local _,p=compose_pose(iq,ip,{0,0,0,1},point)
      if not p then return false end
      local squared=0
      for axis=1,3 do
        local distance=math.max(envelope.min[axis]-p[axis],p[axis]-envelope.max[axis],0)
        squared=squared+distance*distance
      end
      -- Native mechanical grips can move between the avatar and weapon pose
      -- samples. Proximity to their audited sweep vetoes "free hand" only;
      -- it never creates a grasp/IK target or expands weapon ownership.
      return squared<0.03*0.03,support_weight(math.sqrt(squared),0.02,0.06)
    end
    local function native_hand_near_support(binding,spec,s,left,right)
      -- IK_left is a weapon control frame, not the Avatar's attach_hand_l
      -- grip centre. A held pump can keep a rigid 11 cm control-to-grip
      -- offset. Do not label a native hand free merely because those origins
      -- differ. Its current palm length supplies a conservative exclusion
      -- radius; this veto never creates an IK target or proves a grasp.
      if spec.sidearm or not left then return false end
      local input=binding.avatar.source_bones
      if not input then return false end
      local hand,palm
      for i,name in ipairs(source_names) do
        if name=="l_hand" then local q,p=matrix_pose(input,(i-1)*12);if q then hand=p end
        elseif name=="l_middle_finger1" then local q,p=matrix_pose(input,(i-1)*12);if q then palm=p end end
      end
      if not hand or not palm then return false end
      local reach=perror(hand,palm)
      if not reach or reach<0.02 or reach>0.2 then return false end
      local distance=perror(hand,s.poses[left].world_p)
      local weight=support_weight(distance,reach,reach+0.04)
      -- For a moving control, compare in its audited right-control frame.
      local envelope=spec.support_envelope
      local r=right and s.poses[right]
      if not envelope or not r then return distance<=reach,weight end
      local iq,ip=inverse_pose(r.world_q,r.world_p)
      local _,p=compose_pose(iq,ip,{0,0,0,1},hand)
      if not p then return distance<=reach,weight end
      local squared=0
      for axis=1,3 do
        local distance=math.max(envelope.min[axis]-p[axis],p[axis]-envelope.max[axis],0)
        squared=squared+distance*distance
      end
      return distance<=reach or squared<=reach*reach,math.max(weight,support_weight(math.sqrt(squared),reach,reach+0.04))
    end
    function trial.find_owned(world,binding,contacts,mask)
      local cached=binding.avatar.held_weapon_graph
      if binding.avatar.held_weapon_epoch==epoch and cached~=nil then return cached or nil end
      binding.avatar.held_weapon_epoch=epoch
      binding.avatar.held_weapon_graph=false
      -- Ownership belongs to the CURRENT native attachment, not the IK target.
      -- holding_contact_frame can smoothly reconstruct a distant helper from
      -- the palm; comparing that target with the original weapon parent made
      -- the strict 2 mm / 0.15 degree proof blink on/off during native motion.
      -- Never relax the proof or retain ownership across frames to hide this.
      local avatar=binding.avatar.unit
      local node=try(function()
        if U.alive(avatar) and U.has_node(avatar,"attach_hand_r") then return U.node(avatar,"attach_hand_r") end
      end)
      if type(node)~="number" or not finite(node) or node~=math.floor(node) or node<0 then return nil end
      local count=try(function()return U.num_scene_graph_items(avatar)end)
      if type(count)~="number" or not finite(count) or count<1 or node>count then return nil end
      local gq,gp=world_pose(avatar,node)
      if not gq or not gp then return nil end
      local chosen,owners=nil,0
      for hash,spec in pairs(packages) do
        local units=try(function()return W.units_by_resource(world,
          spec.path~="" and spec.path or Id64.from_hex(hash))end)
        if type(units)=="table" and #units<=16 then for _,unit in ipairs(units) do
          local s=possible_owner(unit,spec,gq,gp) and verified_graph(unit,spec) or nil
          if s then
            local owned=false
            for _,pose in pairs(s.poses) do if pose.external then
              local iq,ip=inverse_pose(pose.local_q,pose.local_p)
              local q,p=compose_pose(pose.world_q,pose.world_p,iq,ip)
              if q and qerror_degrees(q,gq)<0.15 and perror(p,gp)<0.002 then owned=true break end
            end end
            if owned then
              owners=owners+1
              if owners>1 then note("ambiguous","ambiguous native owner; skipped");return nil end
              local left,right
              for i,name in ipairs(spec.names) do
                if name=="IK_left" then left=i-1+s.base elseif name=="IK_right" then right=i-1+s.base end
              end
              local lq,lp=matrix_pose(contacts,12)
              local support=mask==3 and lq and lp and left and perror(lp,s.poses[left].world_p)<0.03
              local possible_support=support or (mask==3 and lq and lp and
                (possible_primary_support(spec,s,right,lp) or native_hand_near_support(binding,spec,s,left,right)))
              local _,envelope_weight=possible_primary_support(spec,s,right,lp)
              local _,palm_weight=native_hand_near_support(binding,spec,s,left,right)
              -- A support-contact threshold must not switch the whole gun
              -- between corrected/native routes during hip fire. Primaries
              -- still require both valid contacts and a verified left control.
              if spec.sidearm or (mask==3 and lq and lp and left) then
                chosen={unit=unit,world=world,node=spec.root+s.base,offset=s.base,
                  root=s.poses[spec.root+s.base],seed=s,spec=spec,hash=hash,left=left,support=support,possible_support=possible_support,
                  support_weight=math.max(envelope_weight or 0,palm_weight or 0)}
              end
            end
          end
        end end
      end
      binding.avatar.held_weapon_graph=chosen or false
      if chosen then
        local cq,cp=matrix_pose(contacts,0)
        if cq and (perror(cp,gp)>=0.002 or qerror_degrees(cq,gq)>=0.15) then
          note("owner-contact-frame-"..chosen.hash,"weapon="..chosen.hash.." native attachment ownership preserved across adjusted contact; position="..
            string.format("%.5fm",perror(cp,gp)).." angle="..string.format("%.3fdeg",qerror_degrees(cq,gq)))
        end
      end
      return chosen
    end
    function trial.discover_followers(world,seed,specs)
      local awaiting,ordered={},{}
      -- Upgrades are loaded from independent Scope/Attachment/Mag archives.
      -- Native ownership/response below still decides which live instances
      -- follow this gun; catalog inclusion alone never moves a foreign part.
      local candidates,seen={},{}
      for _,group in ipairs({specs,accessory_specs}) do for _,spec in ipairs(group) do
        if not seen[spec.hash] then candidates[#candidates+1]=spec;seen[spec.hash]=spec.count
        elseif seen[spec.hash]~=spec.count then return nil end
      end end
      for _,spec in ipairs(candidates) do
        local resource=try(function()return Id64.from_hex(spec.hash)end)
        local units=resource and try(function()return W.units_by_resource(world,resource)end)
        if type(units)~="table" then
          note("follower-query-"..spec.hash,"child query unavailable resource="..spec.hash.."; gun trial skipped")
          return nil
        end
        if #units>16 then
          note("follower-query-limit-"..spec.hash,"child resource limit exceeded resource="..spec.hash.." limit=16; gun trial skipped")
          return nil
        end
        note("package-"..spec.hash.."-"..#units,"package resource="..spec.hash.." current_instances="..#units)
        for _,unit in ipairs(units) do if unit~=seed.unit and try(function()return U.alive(unit)end)==true then
          local dn=try(function()return string.lower(tostring(U.debug_name(unit)))end)
          if dn and string.find(dn,spec.hash,1,true) then
            local s=graph_snapshot(unit,spec.count)
            if not s then note("follower-invalid-"..spec.hash,"package member graph unsupported resource="..spec.hash.."; gun trial skipped");return nil end
            s.hash=spec.hash;awaiting[#awaiting+1]=s
            if #awaiting>48 then
              note("follower-scene-limit","child scene candidate limit exceeded limit=48; gun trial skipped")
              return nil
            end
          end
        end end
      end
      local parents={seed}
      -- Parent-before-child order is recovered from full frames, not spatial
      -- proximity, package co-membership, node labels, or per-weapon offsets.
      for depth=1,8 do
        local remaining,progress={},false
        for _,s in ipairs(awaiting) do
          local owner,roots,ambiguous=nil,{},false
          local nearest
          for node,p in pairs(s.poses) do if p.external then
            local iq,ip=inverse_pose(p.local_q,p.local_p)
            local q,pos=compose_pose(p.world_q,p.world_p,iq,ip)
            if q and pos then for pi,parent in ipairs(parents) do
              for pn in pairs(parent.affected) do
                local pp=parent.poses[pn]
                local distance,rotation=perror(pos,pp.world_p),qerror_degrees(q,pp.world_q)
                if not nearest or distance<nearest.distance then nearest={node=node,parent_node=pn,distance=distance,rotation=rotation} end
                if distance<0.0002 and rotation<0.05 then
                  if owner and owner~=pi then ambiguous=true end
                  owner=pi;roots[node]=true
                end
              end
            end end
          end end
          if owner and not ambiguous then
            s.affected=descendants(s,roots);s.link_roots=roots
            ordered[#ordered+1]=s;parents[#parents+1]=s;progress=true
            note("follower-"..s.hash,"native child candidate resource="..s.hash.." nodes="..s.count.." depth="..depth.."; own update/readback still required")
          else
            remaining[#remaining+1]=s
            if depth==1 and nearest then
              note("follower-unmatched-"..s.hash,string.format("child not matched resource=%s node=%d nearest_parent_node=%d position_error=%.6fm rotation_error=%.4fdeg ambiguous=%s",
                s.hash,nearest.node,nearest.parent_node,nearest.distance,nearest.rotation,tostring(ambiguous)))
            end
          end
        end
        awaiting=remaining
        if not progress then break end
      end
      return ordered
    end
    function trial.refresh_followers(world,followers,delta)
      for _,s in ipairs(followers or {}) do
        assert(try(function()return U.alive(s.unit)end)==true,"follower destroyed during transaction")
        assert(try(function()return U.num_scene_graph_items(s.unit)end)==s.count,"follower graph changed")
        assert(pcall(function()W.update_unit(world,s.unit)end),"follower update failed")
        if delta then for node,before in pairs(s.poses) do
          local after=node_pose_numbers(s.unit,node)
          assert(after and perror(after.local_p,before.local_p)<0.00001 and
            qerror_degrees(after.local_q,before.local_q)<0.001,"follower local animation changed")
          local d=s.affected[node] and delta or {0,0,0}
          assert(qerror_degrees(after.world_q,before.world_q)<0.05 and
            perror(after.world_p,{before.world_p[1]+d[1],before.world_p[2]+d[2],before.world_p[3]+d[3]})<0.001,
            "follower did not inherit native parent displacement")
        end end
      end
    end
    local function refresh_saved_followers(world,followers)
      -- Only numeric identity/resource records survive a render callback. A
      -- reparented child is merely refreshed from its NEW native parent.
      for _,saved in ipairs(followers or {}) do
        local resource=try(function()return Id64.from_hex(saved.hash)end)
        local units=resource and try(function()return W.units_by_resource(world,resource)end)
        assert(type(units)=="table" and #units<=16,"follower restore query failed")
        for _,unit in ipairs(units) do
          if try(function()return U.alive(unit)end)==true and rawget(_G,"__hd2ir_unit_instance_slot")(unit)==saved.slot then
            assert(try(function()return U.num_scene_graph_items(unit)end)==saved.count,"follower restore graph changed")
            W.update_unit(world,unit)
          end
        end
      end
    end
    function trial.native_handoff_clean(scope)
      if not scope then return not disabled and next(pending)==nil and next(plans)==nil end
      local clean=rawget(_G,'__hd2ir_handoff_scope_clean')
      local function owner(r)return r.handoff_world,r.handoff_owner end
      return not disabled and clean(scope,pending,owner) and clean(scope,plans,owner)
    end
    function trial.begin() plans={};epoch=epoch+1 end
    function trial.prepare(world,binding,contacts,mask)
      if disabled or next(pending)~=nil or type(rawget(_G,"update"))~="function" or not C or not C.weapon_root_offset or not C.weapon_root_trial_enabled or
          tonumber(C.weapon_root_trial_enabled())~=1 or not pose_capture.local_third_person(binding.avatar) or
          (mask~=1 and mask~=3) or
          not rawget(_G,"__hd2ir_tp_singlehand_state")(binding.avatar.unit) then return nil end
      local key=binding.avatar.id
      if not key then return nil end
      if plans[key] then return plans[key] end
      local grip_q,grip_p=matrix_pose(contacts,0)
      if not grip_q or not grip_p then return nil end
      local chosen=trial.find_owned(world,binding,contacts,mask)
      if not chosen then return nil end
      local root=ffi.new("float[12]");fill_matrix(root,0,binding.avatar.root_q,binding.avatar.p)
      local delta=ffi.new("float[3]")
      if tonumber(C.weapon_root_offset(binding.profile.id,root,#source_names,
          binding.avatar.source_bones,contacts,delta))~=1 then return nil end
      local d={tonumber(delta[0]),tonumber(delta[1]),tonumber(delta[2])}
      local distance=perror(d,{0,0,0})
      -- Zero is a valid continuous endpoint, not a reason to switch to the
      -- alternate shoulder-girdle solver for one frame. C++ saturates valid
      -- proposals below 18 cm; this independent safety guard remains strict.
      if not distance or distance~=distance or distance>0.18 then return nil end
      local seed,package=chosen.seed,chosen.spec
      -- find_owned supplies this Avatar's current-epoch seed. All body parts
      -- see the same native weapon graph before trial.apply; a failed proof
      -- is just as reusable as a successful one. Never retain it next frame.
      if not chosen.followers_checked then
        chosen.followers=trial.discover_followers(world,seed,package.members)
        chosen.followers_checked=true
      else
      end
      if not chosen.followers or (#package.members>1 and #chosen.followers==0) then
        note("invalid-followers-"..chosen.hash,"child graph not proved for multipart weapon; no gun or hand offset applied")
        return nil
      end
      chosen.delta=d;chosen.contacts=ffi.new("float[24]");ffi.copy(chosen.contacts,contacts,96)
      fill_matrix(chosen.contacts,0,grip_q,{grip_p[1]+d[1],grip_p[2]+d[2],grip_p[3]+d[3]})
      chosen.mask=1
      if mask==3 and chosen.left then
        local lq,lp=matrix_pose(contacts,12)
        local _,wp=world_pose(chosen.unit,chosen.left)
        if lq and lp and wp then
          local gap=perror(lp,wp)
          local weight=gap<0.03 and 1 or 0
          if not chosen.spec.sidearm then
            -- Preserve the CURRENT native hand trajectory, never snap it to
            -- IK_left (mechanical controls and wrist origins can differ).
            -- Smooth the old 3 cm discontinuity; a remote/free hand keeps its
            -- native target, while the gun/right-hand plan remains active.
            weight=math.max(support_weight(gap,0.02,0.06),chosen.support_weight)
          end
          if weight>0 or not chosen.spec.sidearm then
            chosen.mask=3
            fill_matrix(chosen.contacts,12,lq,{lp[1]+weight*d[1],lp[2]+weight*d[2],lp[3]+weight*d[3]})
          end
          chosen.support_weight=weight
        end
      end
      -- Plans outlive the remaining body/physics work and upstream render.
      -- Keep only owned Lua numbers here; construct engine temporaries at the
      -- setter, including rollback after upstream code has run.
      chosen.original={chosen.root.local_p[1],chosen.root.local_p[2],chosen.root.local_p[3]}
      local iq,ip=inverse_pose(chosen.root.local_q,chosen.root.local_p)
      local parent_q,parent_p=compose_pose(chosen.root.world_q,chosen.root.world_p,iq,ip)
      if not chosen.original or not parent_q then return nil end
      local parent_iq=qconjugate(parent_q)
      local local_delta=qrotate(parent_iq,d)
      chosen.shifted={chosen.root.local_p[1]+local_delta[1],
        chosen.root.local_p[2]+local_delta[2],chosen.root.local_p[3]+local_delta[3]}
      if not chosen.shifted then return nil end
      chosen.handoff_world=rawget(_G,'__hd2ir_unit_instance_slot')(world)
      chosen.handoff_owner=rawget(_G,'__hd2ir_unit_instance_slot')(binding.avatar.unit)
      plans[key]=chosen
      note("prepared-"..chosen.hash,"weapon="..chosen.hash.." whole-root prepared; offset="..string.format("%.4fm",distance).." late-render hold; native muzzle also moves temporarily")
      return chosen
    end
    function trial.restore()
      for _,p in pairs(plans) do if p.applied then
        local ok=pcall(function()
          if not U.alive(p.unit) then return end
          U.set_local_position(p.unit,p.node,assert(engine_vector(p.original),"root restore vector unavailable"));W.update_unit(p.world,p.unit)
          trial.refresh_followers(p.world,p.followers,{0,0,0})
          local now=node_pose_numbers(p.unit,p.node)
          assert(now and perror(now.local_p,p.root.local_p)<0.00001,"root restore mismatch")
        end)
        if not ok then disabled=true;note("restore-failed","RESTORE FAILED; trial disabled; exit game") end
        p.applied=false
      end end
    end
    function trial.defer_restore()
      -- Numbers only cross render -> update. Resolve fresh native handles
      -- from current Worlds before restoring; never keep a Unit userdata.
      for _,p in pairs(plans) do if p.applied then
        local shifted={p.root.local_p[1],p.root.local_p[2],p.root.local_p[3]}
        local _,lp=pose_numbers(p.unit,p.node,false)
        if lp then shifted={lp[1],lp[2],lp[3]} end
        local followers={}
        for _,s in ipairs(p.followers or {}) do followers[#followers+1]={
          hash=s.hash,count=s.count,slot=rawget(_G,"__hd2ir_unit_instance_slot")(s.unit)} end
        pending[rawget(_G,"__hd2ir_unit_instance_slot")(p.unit)]={
          node=p.node,offset=p.offset,hash=p.hash,original=p.root.local_p,q=p.root.local_q,shifted=shifted,followers=followers,
          handoff_world=p.handoff_world,handoff_owner=p.handoff_owner}
        p.applied=false
      end end
    end
    function trial.restore_pending()
      if next(pending)==nil then return true end
      local worlds=try(function()return App.worlds()end)
      if type(worlds)~="table" then return false end
      local found,complete={},true
      local resources={}
      for _,saved in pairs(pending) do resources[saved.hash]=true end
      for _,world in ipairs(worlds) do
        for hash in pairs(resources) do
        local spec=packages[hash]
        local units=try(function()return W.units_by_resource(world,
          spec.path~="" and spec.path or Id64.from_hex(hash))end)
        if type(units)~="table" then complete=false end
        for _,unit in ipairs(type(units)=="table" and units or {}) do
          if try(function()return U.alive(unit)end)==true then
            local slot=rawget(_G,"__hd2ir_unit_instance_slot")(unit)
            local saved=pending[slot]
            if saved then
              found[slot]=true
              local ok=pcall(function()
                assert(saved.hash==hash and verified_graph(unit,spec),"pending graph changed")
                local current=node_pose_numbers(unit,saved.node)
                assert(current,"pending root unavailable")
                -- Engine animation can overwrite our temporary pose. Do not
                -- restore an old transform over a newer animation value.
                if perror(current.local_p,saved.shifted)<0.00001 and qerror_degrees(current.local_q,saved.q)<0.001 then
                  U.set_local_position(unit,saved.node,assert(engine_vector(saved.original)))
                  W.update_unit(world,unit)
                  local _,lp=pose_numbers(unit,saved.node,false)
                  assert(lp and perror(lp,saved.original)<0.00001,"pending restore mismatch")
                else note("overwritten","engine replaced temporary root; preserving newer animation") end
                refresh_saved_followers(world,saved.followers)
              end)
              if not ok then disabled=true;note("pending-failed","pre-update restoration failed; trial disabled; exit game") end
            end
          end
        end
        end
      end
      local remaining={}
      for slot,saved in pairs(pending) do
        if not found[slot] then
          if complete then note("retired","pending weapon no longer in current Worlds; discarded numeric record")
          else remaining[slot]=saved end
        end
      end
      pending=remaining
      note("late-restored","late render pose restored with fresh handles before next update/render")
      return next(pending)==nil
    end
    function trial.apply()
      for _,p in pairs(plans) do if p.right_accepted then
        local ok,err=pcall(function()
          if not U.alive(p.unit) then return end
          local before={}
          for index in pairs(p.seed.poses) do
            local q,pos=world_pose(p.unit,index);assert(q and pos,"missing original child")
            before[index]={q=q,p=pos}
          end
          p.applied=true
          U.set_local_position(p.unit,p.node,assert(engine_vector(p.shifted),"root shift vector unavailable"));W.update_unit(p.world,p.unit)
          trial.refresh_followers(p.world,p.followers,p.delta)
          for index,b in pairs(before) do
            local q,pos=world_pose(p.unit,index)
            local d=p.seed.affected[index] and p.delta or {0,0,0}
            assert(q and pos and qerror_degrees(q,b.q)<0.05 and
              perror(pos,{b.p[1]+d[1],b.p[2]+d[2],b.p[3]+d[3]})<0.001,
              "whole-root child displacement mismatch")
          end
          note("applied-"..p.hash,"weapon="..p.hash.." + "..#p.followers.." separate native child Units refreshed and displacement verified; particles/live pixels still unverified")
        end)
        if not ok then
          note("apply-failed","apply/readback failed; restoring: "..tostring(err));trial.restore()
          if string.find(tostring(err),"follower",1,true) then disabled=true;note("follower-disabled","native child propagation failed; trial disabled for this session") end
        end
      end end
    end
    return trial
  end)())
  --@@WHOLE_WEAPON_TRIAL_END@@
  -- Weapon and hand correction stay together under the user toggle.
  -- No per-resource native-pose bypass or capture-driven mode switching.

  local function retarget_test_unit(world, binding)
    local target_flag_set=pose_capture.target_flag_set
    local profile = binding.profile
    local whole_weapon_plan
    local drives_carrier = profile.hash == CARRIER_RESOURCE_HASH
    local blend, raw_rotation_gate, raw_position_gate,
          step_rotation_gate, step_position_gate = retarget_write_policy(profile)
    local failure_key = retarget_failure_key(binding)
    if binding.scene_restore_blocked then return false end
    if not profile.active or profile.observe_only or
       drive_mode ~= "retarget_test" or
       (RETARGET_TEST_PROFILE ~= nil and
        profile.hash ~= RETARGET_TEST_PROFILE) or
       (binding.instance_id == nil and not binding.pose_only) then
      return false
    end
    retarget_attempts = retarget_attempts + 1

    local capacity = profile.target_count
    if type(capacity) ~= "number" or capacity < 1 or capacity > 256 then
      return reject_retarget(binding, "invalid target capacity")
    end
    local unit, node_count = binding.unit, binding.node_count
    local snapshot=binding.native_snapshot
    binding.native_snapshot=nil -- single-use, callback-local even on rejection
    if snapshot and (snapshot.frame~=frame or snapshot.unit~=unit or snapshot.profile~=profile or snapshot.node_count~=node_count) then snapshot=nil end
    if not binding.preview_update and rawget(_G,'__hd2ir_corpse_freeze_active')==true then
      local freezer=rawget(_G,'__hd2ir_corpse_freeze')
      local ok,err=pcall(freezer.queue_input,world,binding,snapshot)
      if not ok then freezer.report('input',err)end
    end
    local node_offset, node_error, named_nodes
    if snapshot then node_offset,named_nodes=snapshot.offset,snapshot.named
    else node_offset,node_error,named_nodes=authored_scene_node_offset(unit,profile,node_count,source_names) end
    if node_offset == nil then return reject_retarget(binding, node_error) end
    local root_q = qnormalize(binding.avatar.root_q)
    local root_p = binding.avatar.p
    if root_q == nil or root_p == nil then
      return reject_retarget(binding, "invalid avatar root")
    end

    -- HD2 can link each named armour bone to a native animation node outside
    -- this Unit (scene_graph_parent returns nil). Such a node's WORLD is
    -- native_parent * LOCAL; LOCAL contains our last correction, not animation.
    -- Recover the native parent without retaining poses across frames. This
    -- works in ADS/presentation Worlds and cannot accumulate on repeat renders.
    -- Use this input only when EVERY mapped channel proves that link layout.
    local sampled, animation, linked_count, native = {}, nil, 0, {}
    if profile.authored and C.retarget_unit_pose ~= nil and
       binding.avatar.source_bones ~= nil then
      animation = ffi.new("float[?]", #source_names * 12)
      ffi.copy(animation, binding.avatar.source_bones, #source_names * 48)
      if snapshot then
        sampled=snapshot.samples
        for _,pose in ipairs(snapshot) do
          fill_matrix(animation,pose.source*12,pose.q,pose.p)
          native[pose.name]=pose
          linked_count=linked_count+1
        end
      else
      for i, flags in ipairs(profile.target_flags) do
        if target_flag_set(flags, 1024) then
          local node = profile.nodes[i] + node_offset
          local parent, parent_ok = try(function() return U.scene_graph_parent(unit, node) end)
          local lq, lp = pose_numbers(unit,node,false)
          local wq, wp = world_pose(unit, node)
          local external_parent = parent == nil or parent == -1 or
            (node_offset == 1 and parent == 0)
          if not parent_ok or not external_parent or lq == nil or lp == nil or
             wq == nil or wp == nil then
            animation = nil
            break
          end
          local iq, ip = inverse_pose(lq, lp)
          local aq, ap = compose_pose(wq, wp, iq, ip)
          if aq == nil or ap == nil then
            return reject_retarget(binding, "native animation parent is not rigid")
          end
          fill_matrix(animation, profile.target_sources[i] * 12, aq, ap)
          native[source_names[profile.target_sources[i]+1]] = {q=aq,p=ap}
          sampled[node + 1] = {local_q=lq, local_p=lp,
            world_q=wq, world_p=wp, parent=-1,native_parent_q=aq,native_parent_p=ap}
          linked_count = linked_count + 1
        end
      end
      end
      if linked_count ~= named_nodes or linked_count == 0 then animation = nil end
      local layout_key = "animation_layout|" .. profile.hash
      if not retarget_mapping_logged[layout_key] then
        retarget_mapping_logged[layout_key] = true
        log(string.format("authored animation layout %s linked=%d/%d unit_input=%s parent_api=%s",
          profile.hash, linked_count, named_nodes, tostring(animation ~= nil),
          type(get(U, "scene_graph_parent"))))
      end
    end
    local target_nodes = ffi.new("unsigned[?]", capacity)
    local target_model = ffi.new("float[?]", capacity * 12)
    local returned
    if binding.pose_only then
      if animation==nil or C.retarget_presentation_pose==nil then
        return reject_retarget(binding,"presentation input/ABI unavailable")
      end
      local root=ffi.new("float[12]")
      fill_matrix(root,0,root_q,root_p)
      local fp_action,fp_reason=rawget(_G,"__hd2ir_native_contact_action")(world,binding,native)
      local proof_key="fp-presentation-proof|"..profile.hash.."|"..fp_reason
      if not retarget_mapping_logged[proof_key] then
        retarget_mapping_logged[proof_key]=true
        log("retarget binding FP proof "..profile.hash.." action="..fp_action.." reason="..fp_reason)
      end
      if fp_action==3 and C.retarget_first_person_pose then
        returned=tonumber(C.retarget_first_person_pose(profile.id,root,#source_names,
          animation,capacity,target_nodes,target_model)) or 0
        local key="fp-presentation|"..profile.hash.."|"..tostring(returned==capacity)
        if not retarget_mapping_logged[key] then
          retarget_mapping_logged[key]=true
          log("retarget binding FP presentation "..profile.hash.." reason="..fp_reason.." solved="..tostring(returned==capacity))
        end
        if returned~=capacity then return reject_retarget(binding,"FP presentation solve unavailable") end
      end
      if not returned and binding.preview_audit and binding.presentation_world and not binding.preview_update and
          not binding.avatar.presentation_kind and C.retarget_presentation_instance then
        returned=tonumber(C.retarget_presentation_instance(profile.id,binding.presentation_world,
          rawget(_G,'__hd2ir_unit_instance_slot')(binding.unit),frame,root,#source_names,
          animation,capacity,target_nodes,target_model)) or 0
      end
      if not returned or returned==0 then
        returned=tonumber(C.retarget_presentation_pose(profile.id,root,#source_names,
          animation,capacity,target_nodes,target_model)) or 0
      end
    elseif animation ~= nil then
      local contact, contact_reason, partial_tp = 0,"legacy-abi",false
      local contact_mask,contact_route=0,"action"
      if C.retarget_unit_pose_action ~= nil then
        contact,contact_reason,partial_tp = rawget(_G,"__hd2ir_native_contact_action")(world,binding,native)
        if contact==0 and contact_reason=="tp-match" then
          contact,contact_reason=rawget(_G,"__hd2ir_tp_contact_action")(binding.avatar.unit)
        end
        if C.retarget_unit_pose_contacts~=nil and (contact==1 or contact==2) then
          -- TP provenance was established above against this exact binding's
          -- unmodified native arm. Never borrow contacts from a nearby weapon
          -- or another Avatar, and never feed this TP path into accepted FP.
          local contacts=ffi.new("float[24]")
          local mask=0
          for side,name in ipairs({"attach_hand_r","attach_hand_l"}) do
            local node=try(function()
              if U.has_node(binding.avatar.unit,name) then return U.node(binding.avatar.unit,name) end
            end)
            if type(node)=="number" then
              local q,p=world_pose(binding.avatar.unit,node)
              if contact==2 or (contact==1 and side==1) then
                local grips=rawget(_G,"__hd2ir_tp_motion_grips")
                local hand=native[side==1 and "r_hand" or "l_hand"]
                if not hand and partial_tp then
                  local hand_node=try(function()
                    local hand_name=side==1 and "r_hand" or "l_hand"
                    if U.has_node(binding.avatar.unit,hand_name) then return U.node(binding.avatar.unit,hand_name) end
                  end)
                  if type(hand_node)=="number" then
                    local hq,hp=world_pose(binding.avatar.unit,hand_node)
                    if hq and hp then hand={q=hq,p=hp} end
                  end
                end
                local grip=grips and grips[side]
                if contact==2 then
                  q,p=nil,nil
                  if hand and grip then q,p=compose_pose(hand.q,hand.p,grip.q,grip.p) end
                else
                  q,p=rawget(_G,"__hd2ir_holding_contact_frame")(q,p,hand,grip)
                end
              end
              if q and p then
                fill_matrix(contacts,(side-1)*12,q,p)
                mask=mask+(side==1 and 1 or 2)
              end
            end
          end
          local solve=C.retarget_unit_pose_contacts
          if contact==1 then
            whole_weapon_plan=rawget(_G,"__hd2ir_weapon_root_trial").prepare(world,binding,contacts,mask)
            if whole_weapon_plan then contacts,mask=whole_weapon_plan.contacts,whole_weapon_plan.mask end
          end
          if not whole_weapon_plan and contact==1 and C.retarget_unit_pose_singlehand and
              rawget(_G,"__hd2ir_singlehand_weapon")(world,binding,contacts,mask) then
            solve=C.retarget_unit_pose_singlehand
            local key="singlehand-girdle|"..profile.hash
            if not retarget_mapping_logged[key] then retarget_mapping_logged[key]=true;log("singlehand-girdle accepted "..profile.hash.." native-pistol-link=true") end
          end
          returned=tonumber(solve(binding.instance_id,#source_names,
            animation,contact,mask,contacts,capacity,target_nodes,target_model)) or 0
          contact_mask,contact_route=mask,whole_weapon_plan and "whole" or (solve==C.retarget_unit_pose_singlehand and "single" or "contacts")
        else
          returned = tonumber(C.retarget_unit_pose_action(binding.instance_id, #source_names,
            animation, contact, capacity, target_nodes, target_model)) or 0
        end
      else
        returned = tonumber(C.retarget_unit_pose(binding.instance_id, #source_names,
          animation, capacity, target_nodes, target_model)) or 0
      end
      -- One bounded entry per resource/action, not per frame or Unit handle.
      local action_key = "contact_action|"..profile.hash.."|"..contact_reason
      if not retarget_mapping_logged[action_key] then
        retarget_mapping_logged[action_key]=true
        log("retarget binding contact action "..profile.hash.." action="..contact.." reason="..contact_reason.." native-linked=true")
      end
    else
      returned = tonumber(C.retarget_bound(binding.instance_id, capacity,
        target_nodes, target_model)) or 0
    end
    if returned ~= capacity then
      return reject_retarget(binding, "C++ target count mismatch " ..
                             tostring(returned) .. "/" .. tostring(capacity))
    end

    local fast_scene,fast_error
    if animation~=nil and profile.authored and blend==1 and not fp_active[failure_key] then
      fast_scene,fast_error=pose_capture.prepare_native_scene(C.prepare_scene,unit,profile,source_names,
        root_q,root_p,target_nodes,target_model,returned,node_offset,node_count,sampled)
      if fast_scene==false then return reject_retarget(binding,fast_error) end
    end
    local explicit,target_order,target_name_by_node,target_source_by_node,
      diagnostic_by_node,missing_names,missing_count,duplicate_count,writable_expected,anchor_count
    if fast_scene then
      explicit,target_order,target_name_by_node,target_source_by_node=
        fast_scene.context.explicit,fast_scene.order,fast_scene.names,fast_scene.sources
      diagnostic_by_node,missing_names,missing_count,duplicate_count,writable_expected,anchor_count={},{},0,0,returned,0
    else
      explicit,target_order,target_name_by_node,target_source_by_node,
        diagnostic_by_node,missing_names,missing_count,duplicate_count,writable_expected,anchor_count =
        pose_capture.build_target_map(unit,profile,source_names,root_q,root_p,
          target_nodes,target_model,returned,node_offset,node_count)
      if not explicit then return reject_retarget(binding,target_order) end
    end
    if not retarget_mapping_logged[profile.hash] then
      retarget_mapping_logged[profile.hash] = true
      log(string.format(
        "runtime target map %s writable=%d/%d anchors=%d missing=%d duplicate=%d first_missing=%s file_to_engine_offset=%d named_nodes=%d",
        profile.hash, #target_order, writable_expected, anchor_count,
        missing_count, duplicate_count, table.concat(missing_names, ","), node_offset, named_nodes))
    end
    if writable_expected < 1 then
      return reject_retarget(binding, "profile declares no writable targets")
    end
    local minimum_targets = math.max(1,
      math.floor(writable_expected * 0.5 + 0.5))
    if #target_order < minimum_targets then
      return reject_retarget(binding, string.format(
        "runtime target coverage too low %d/%d",
        #target_order, writable_expected))
    end

    local driver_context=fast_scene and fast_scene.context or {unit=unit,node_count=node_count,node_offset=node_offset,
      current=sampled,desired={},visiting={},explicit=explicit}

    local writes = {}
    local fp_arm = not binding.pose_only and first_person_arm_profile(binding) or nil
    local use_fp_proxy = fp_arm ~= nil and fp_active[failure_key] == true
    local fp_triggered = false
    local raw_r, raw_p, step_r, step_p = 0.0, 0.0, 0.0, 0.0
    if fast_scene then
      writes=fast_scene.writes
      raw_r,raw_p,step_r,step_p=fast_scene.raw_r,fast_scene.raw_p,fast_scene.step_r,fast_scene.step_p
    else
    for i = 1, #target_order do
      local node = target_order[i]
      local key = node + 1
      local data = pose_capture.driver_read(driver_context,node)
      local wanted_world = pose_capture.driver_solve(driver_context,node)
      if data == nil or wanted_world == nil then
        return reject_retarget(binding, "scene-graph target solve failed")
      end
      local wanted_local_q, wanted_local_p
      if data.parent >= 0 then
        local wanted_parent = pose_capture.driver_solve(driver_context,data.parent)
        if wanted_parent == nil then
          return reject_retarget(binding, "scene-graph parent solve failed")
        end
        wanted_local_q, wanted_local_p = relative_pose(
          wanted_parent.q, wanted_parent.p, wanted_world.q, wanted_world.p)
      else
        -- A scene-graph root is still relative to the Unit object's hidden
        -- world transform; its local pose is not a world pose. Infer that
        -- virtual parent from current_world * inverse(current_local), then
        -- express the requested world pose in the same parent space.
        -- The callback-local native-link proof already recovered this exact
        -- WORLD * inverse(LOCAL). Reuse its numbers, not a previous frame or
        -- a foreign Unit, instead of repeating the same inverse/composition.
        local unit_parent_q, unit_parent_p = data.native_parent_q,data.native_parent_p
        if unit_parent_q==nil or unit_parent_p==nil then
          local inverse_local_q, inverse_local_p = inverse_pose(data.local_q,data.local_p)
          unit_parent_q,unit_parent_p=compose_pose(data.world_q,data.world_p,inverse_local_q,inverse_local_p)
        end
        if unit_parent_q == nil or unit_parent_p == nil then
          return reject_retarget(binding, "virtual Unit parent solve failed")
        end
        wanted_local_q, wanted_local_p = relative_pose(
          unit_parent_q, unit_parent_p, wanted_world.q, wanted_world.p)
      end
      if wanted_local_q == nil or wanted_local_p == nil then
        return reject_retarget(binding, "target local conversion failed")
      end
      if diagnostic_by_node[key] then
        -- V154 proved that the custom lower-rim node is consumed by all four
        -- helmet LODs. V155 moves only that direct scene-graph node: a slow
        -- +/-3 cm node excursion becomes about +/-1 cm at the most strongly
        -- blended vertices, without touching native head/neck/body nodes.
        local phase = math.sin((frame % 240) * (2.0 * math.pi / 240.0))
        wanted_local_p = {
          wanted_local_p[1],
          wanted_local_p[2] + phase * 0.03,
          wanted_local_p[3],
        }
      end
      local node_raw_r = qerror_degrees(data.local_q, wanted_local_q)
      local node_raw_p = perror(data.local_p, wanted_local_p)
      raw_r, raw_p = math.max(raw_r, node_raw_r), math.max(raw_p, node_raw_p)
      -- A verified native-link input produces an absolute authored correction.
      -- Its distance from the previous render is not an error measurement:
      -- legitimate long limbs and camera cuts exceed the old fixture's 25 cm.
      -- Other layouts still use the original conservative cross-avatar gates.
      if animation == nil and (node_raw_r > raw_rotation_gate or
         node_raw_p > raw_position_gate) then
        local detail_key = "rejected_pose|" .. profile.hash
        if not retarget_mapping_logged[detail_key] then
          retarget_mapping_logged[detail_key] = true
          log(string.format(
            "retarget pose detail %s bone=%s parent=%d current_local=(%.5f,%.5f,%.5f) wanted_local=(%.5f,%.5f,%.5f) current_world=(%.5f,%.5f,%.5f) wanted_world=(%.5f,%.5f,%.5f)",
            profile.hash, tostring(target_name_by_node[key]), data.parent,
            data.local_p[1], data.local_p[2], data.local_p[3],
            wanted_local_p[1], wanted_local_p[2], wanted_local_p[3],
            data.world_p[1], data.world_p[2], data.world_p[3],
            wanted_world.p[1], wanted_world.p[2], wanted_world.p[3]))
        end
        if fp_arm ~= nil then
          use_fp_proxy = true
          fp_triggered = true
        else
          return reject_retarget(binding, string.format(
            "raw gate bone=%s node=%d %.3fdeg/%.5fm",
            tostring(target_name_by_node[key]), node, node_raw_r, node_raw_p))
        end
      end

      if not use_fp_proxy then
        local blended_q = qnlerp(data.local_q, wanted_local_q, blend)
        local blended_p = {
          data.local_p[1] + (wanted_local_p[1] - data.local_p[1]) * blend,
          data.local_p[2] + (wanted_local_p[2] - data.local_p[2]) * blend,
          data.local_p[3] + (wanted_local_p[3] - data.local_p[3]) * blend,
        }
        if blended_q == nil then
          return reject_retarget(binding, "quaternion blend failed")
        end
        local node_step_r = qerror_degrees(data.local_q, blended_q)
        local node_step_p = perror(data.local_p, blended_p)
        step_r, step_p = math.max(step_r, node_step_r), math.max(step_p, node_step_p)
        if animation == nil and (node_step_r > step_rotation_gate or
           node_step_p > step_position_gate) then
          return reject_retarget(binding, string.format(
            "step gate node=%d %.3fdeg/%.5fm", node, node_step_r, node_step_p))
        end

        -- Native-linked bodies/corpses can also retain the exact correction.
        -- Still solve/check every target and validate its resulting world pose;
        -- omit only redundant userdata/setters. Any changed physical node is
        -- written normally, and one changed node still refreshes the Unit.
        local unchanged=(binding.pose_only or (profile.authored and animation~=nil)) and
          node_step_r<=0.0001 and node_step_p<=0.0000001
        writes[#writes + 1] = {
          node = node, q = blended_q, p = blended_p,
          unchanged=unchanged,
        }
      end
    end

    end
    -- The stock third-person model-space target is deliberately not applied
    -- to a first-person arm rig: its boss/root frame is a different camera
    -- presentation space, which is why the ordinary raw gate rejects it by
    -- roughly 0.7 m.  For the two camera-nearest sleeve resources proven by
    -- V16, preserve every current animation rotation and apply only the same
    -- per-side model-space Rest translation represented by the V13 proxy
    -- skeleton. Moving every local arm node would stretch the hierarchy, so
    -- write only the clavicle branch root and express the avatar-model X
    -- delta in that node's actual parent space. Descendants then inherit one
    -- rigid translation. The write memory stores numbers only (never a Unit
    -- userdata) and prevents repeated callbacks from accumulating the step.
    if use_fp_proxy and fp_active[failure_key] and not fp_triggered then
      local safe = (fp_safe_frames[failure_key] or 0) + 1
      fp_safe_frames[failure_key] = safe
      if safe >= FP_PROXY_RELEASE_STABLE_FRAMES then
        fp_active[failure_key] = nil
        fp_pose_memory[failure_key] = nil
        fp_safe_frames[failure_key] = nil
        fp_exits = fp_exits + 1
        log("first-person proxy released " .. profile.hash)
        -- The target loop was intentionally kept in proxy mode during the
        -- hold window, so do not reuse incomplete ordinary writes on this
        -- release frame. The next frame rebuilds them from the engine pose.
        return false
      end
    elseif fp_triggered then
      fp_safe_frames[failure_key] = 0
    end

    if use_fp_proxy then
      writes = {}
      binding_disabled[failure_key] = nil
      binding_failures[failure_key] = 0
      binding_safe_frames[failure_key] = nil
      binding_retrying[failure_key] = nil
      if not fp_active[failure_key] then
        fp_active[failure_key] = true
        fp_entries = fp_entries + 1
        log(string.format(
          "first-person proxy active %s side=%s camera_distance=%.3f",
          profile.hash, fp_arm.side,
          binding.avatar.camera_distance or math.huge))
      end

      local memory = fp_pose_memory[failure_key]
      if memory == nil then
        memory = {}
        fp_pose_memory[failure_key] = memory
      end
      for i = 1, #target_order do
        local node = target_order[i]
        local key = node + 1
        local name = target_source_by_node[key]
        local matching_side =
          (fp_arm.side == "left" and name == "l_clavicle") or
          (fp_arm.side == "right" and name == "r_clavicle")
        if matching_side then
          local data = pose_capture.driver_read(driver_context,node)
          if data == nil then
            return reject_retarget(binding, "first-person proxy read failed")
          end
          local remembered = memory[key]
          local model_delta = {fp_arm.delta_x, 0.0, 0.0}
          local world_delta = qrotate(root_q, model_delta)
          local parent_world_q
          if data.parent >= 0 then
            local parent_data = pose_capture.driver_read(driver_context,data.parent)
            parent_world_q = parent_data and parent_data.world_q or nil
          else
            -- Recover the hidden Unit-object parent orientation from the
            -- current world/local pair, just as the ordinary solver does.
            local inverse_local_q, inverse_local_p = inverse_pose(
              data.local_q, data.local_p)
            parent_world_q = select(1, compose_pose(
              data.world_q, data.world_p,
              inverse_local_q, inverse_local_p))
          end
          if parent_world_q == nil or world_delta == nil then
            return reject_retarget(binding,
                                   "first-person parent frame failed")
          end
          local local_delta = qrotate(qconjugate(parent_world_q),
                                      world_delta)
          local base_p = data.local_p
          if remembered ~= nil and remembered.p ~= nil and
             remembered.delta ~= nil and
             perror(data.local_p, remembered.p) <= 0.0001 then
            -- The engine has not replaced our last output yet. Remove the
            -- previous delta before applying the newly oriented one, so a
            -- moving shoulder basis cannot accumulate or lag its direction.
            base_p = {
              data.local_p[1] - remembered.delta[1],
              data.local_p[2] - remembered.delta[2],
              data.local_p[3] - remembered.delta[3],
            }
          end
          local proxy_p = {
            base_p[1] + local_delta[1],
            base_p[2] + local_delta[2],
            base_p[3] + local_delta[3],
          }
          local proxy_q = {
            data.local_q[1], data.local_q[2],
            data.local_q[3], data.local_q[4],
          }
          local node_step_p = perror(data.local_p, proxy_p)
          step_p = math.max(step_p, node_step_p)
          if node_step_p > RETARGET_STEP_POSITION_GATE then
            return reject_retarget(binding, string.format(
              "first-person proxy step gate node=%d %.5fm",
              node, node_step_p))
          end
          writes[#writes + 1] = {
            node = node, q = proxy_q, p = proxy_p,
            fp_memory_key = key, fp_delta = local_delta,
          }
        end
      end
      if #writes == 0 then
        return reject_retarget(binding,
                               "first-person proxy has no side targets")
      end
    elseif fp_active[failure_key] then
      -- The binding stopped being a camera-nearest arm candidate entirely.
      -- Keep the short generic recovery path for World/camera ownership
      -- changes; raw-gate chatter while it remains a candidate is handled by
      -- FP_PROXY_RELEASE_STABLE_FRAMES above.
      local safe = (fp_safe_frames[failure_key] or 0) + 1
      fp_safe_frames[failure_key] = safe
      if animation == nil and safe < RETARGET_RECOVERY_STABLE_FRAMES then return false end
      fp_active[failure_key] = nil
      fp_pose_memory[failure_key] = nil
      fp_safe_frames[failure_key] = nil
      fp_exits = fp_exits + 1
      log("first-person proxy released " .. profile.hash)
    end

    if binding_disabled[failure_key] then
      local safe = (binding_safe_frames[failure_key] or 0) + 1
      binding_safe_frames[failure_key] = safe
      if animation == nil and safe < RETARGET_RECOVERY_STABLE_FRAMES then return false end
      binding_disabled[failure_key] = nil
      binding_failures[failure_key] = 0
      binding_safe_frames[failure_key] = nil
      binding_retrying[failure_key] = true
    end

    driver_context.binding=binding
    local scene_batch=rawget(_G,"__hd2ir_pose_batch")
    local deferred_readback=false
    if scene_batch then
      local ready,deferred=scene_batch.scene_ready(function(operation)
        if operation=='verify' then return pose_capture.rollback_verify(driver_context,writes,true) end
        if operation=='defer' then return rawget(_G,'__hd2ir_scene_restore').save(driver_context,writes,true) end
        return pose_capture.rollback(world,driver_context,writes,true)
      end)
      if not ready then return false end
      deferred_readback=deferred==true
    end
    local commit_result={}
    -- One guarded transaction, still rollback the whole Unit on a partial
    -- setter failure. Avoid entering the interpreted pcall wrapper per bone.
    -- As with readback, trust an explicit completion marker, not the game's
    -- JIT-sensitive protected-call success return. Partial setters still roll back.
    local _,write_error=pcall(pose_capture.commit,unit,writes,commit_result)
    if not commit_result.complete then
      pose_capture.rollback(world,driver_context,writes)
      return reject_retarget(binding, "Unit local write failed: " .. tostring(write_error))
    end
    local changed_writes=commit_result.changed
    if changed_writes>0 and not call(W.update_unit,world,unit) then
      pose_capture.rollback(world,driver_context,writes)
      return reject_retarget(binding, "World.update_unit failed")
    end

    local residual_r, residual_p = 0.0, 0.0
    -- Shared members are fully checked together after the last sibling update.
    -- The old immediate readback was superseded by that mandatory final pass;
    -- it duplicated every getter and could not prove the completed assembly.
    -- Never defer for an ordinary Unit or an older batch implementation.
    if not deferred_readback then
    if changed_writes>0 then
      local result={}
      pcall(pose_capture.readback,unit,writes,animation~=nil,result)
      if not result.complete then
        pose_capture.rollback(world,driver_context,writes)
        return reject_retarget(binding,result.error or "post-write local read failed")
      end
    end
    for i = 1, #writes do
      local pose = writes[i]
      local after_q,after_p
      if changed_writes==0 then
        local before=pose_capture.driver_read(driver_context,pose.node)
        after_q,after_p=before.local_q,before.local_p
      else
        after_q,after_p=pose.after_q,pose.after_p
      end
      after_q = after_q and qnormalize(after_q) or nil
      if after_q == nil or after_p == nil then
        pose_capture.rollback(world,driver_context,writes)
        return reject_retarget(binding, "post-write local read failed")
      end
      residual_r = math.max(residual_r, qerror_degrees(pose.q, after_q))
      residual_p = math.max(residual_p, perror(pose.p, after_p))
      if animation ~= nil then
        local aq,ap
        if changed_writes==0 then
          local before=pose_capture.driver_read(driver_context,pose.node)
          aq,ap=before.world_q,before.world_p
        else aq,ap=pose.after_world_q,pose.after_world_p end
        local expected = explicit[pose.node + 1]
        if aq == nil or ap == nil or expected == nil or
           qerror_degrees(aq, expected.q) > 0.1 or perror(ap, expected.p) > 0.001 then
          pose_capture.rollback(world,driver_context,writes)
          return reject_retarget(binding, "post-write native-link world residual")
        end
      end
    end
    if residual_r > 0.5 or residual_p > 0.002 then
      pose_capture.rollback(world,driver_context,writes)
      return reject_retarget(binding, string.format(
        "post-write residual %.3fdeg/%.6fm", residual_r, residual_p))
    end
    end
    if drives_carrier and
       not call(function() U.set_unit_visibility(unit, true) end) then
      pose_capture.rollback(world,driver_context,writes)
      return reject_retarget(binding, "carrier visibility commit failed")
    end
    if scene_batch and not scene_batch.scene_written(function()
      local result={}
      pcall(pose_capture.verify_scene_completion,unit,writes,animation~=nil,explicit,result)
      if not result.complete then
        return reject_retarget(binding,result.error or "completed shared scene read failed")
      end
      residual_r,residual_p=result.residual_r,result.residual_p
      return true
    end) then return false end

    if use_fp_proxy then
      local memory = fp_pose_memory[failure_key]
      for i = 1, #writes do
        local pose = writes[i]
        if pose.fp_memory_key ~= nil then
          memory[pose.fp_memory_key] = {
            p = {pose.p[1], pose.p[2], pose.p[3]},
            delta = {
              pose.fp_delta[1], pose.fp_delta[2], pose.fp_delta[3],
            },
          }
        end
      end
      fp_writes = fp_writes + #writes
    end

    binding_failures[failure_key] = 0
    if binding_retrying[failure_key] then
      binding_retrying[failure_key] = nil
      binding_recoveries = binding_recoveries + 1
      log("retarget binding recovered " .. profile.hash)
    end
    if whole_weapon_plan then
      for i,source in ipairs(profile.target_sources) do
        if source_names[source+1]=="r_hand" and not target_flag_set(profile.target_flags[i],64) then
          whole_weapon_plan.right_accepted=true
        end
      end
    end
    retarget_units = retarget_units + 1
    -- Candidate-only, bounded and numeric. Keep successes separate from the
    -- production error filter; never retain a World/Unit handle for capture.
    if C.shared_body_profile then
      local key="preview-write|"..profile.hash.."|"..tostring(world).."|"..tostring(binding.pose_only==true)
      if binding.preview_update then key=key.."|update" end
      if not retarget_mapping_logged[key] then
        retarget_mapping_logged[key]=true
        local rows={}
        for _,name in ipairs(source_names) do
          if name:find("spine",1,true) or name:find("clav",1,true) or name:find("shoulder",1,true) or
             name=="l_arm" or name=="r_arm" or name:find("upperarm",1,true) then
            local pose=native[name]
            if pose and pose.p and pose.q then rows[#rows+1]=string.format("%s=%.5f,%.5f,%.5f/%.5f,%.5f,%.5f,%.5f",
              name,pose.p[1],pose.p[2],pose.p[3],pose.q[1],pose.q[2],pose.q[3],pose.q[4]) end
          end
        end
        log(string.format("preview-write unit=%s frame=%d pose_only=%s phase=%s nodes=%d residual=%.6fdeg/%.7fm native=%s",
          profile.hash,frame,tostring(binding.pose_only==true),binding.preview_update and "update" or "render",
          #writes,residual_r,residual_p,table.concat(rows,";")))
        if binding.preview_audit or binding.preview_update then
          rawget(_G,"__hd2ir_preview_numeric_trace")(profile,root_q,root_p,animation,target_nodes,target_model,returned)
        end
      end
    end
    pcall(rawget(_G,"__hd2ir_preview_capture_pose"),profile,unit,world,root_q,root_p,
      animation,target_nodes,target_model,returned,binding.preview_update and 2 or (binding.pose_only and 1 or 0))
    if binding.preview_audit and rawget(_G,"__hd2ir_preview_delivery") then
      pcall(rawget(_G,"__hd2ir_preview_delivery").capture,profile,unit,writes,world)
    end
    if not binding.preview_update and C.shared_body_profile then rawget(_G,'__hd2ir_shared_body_lifecycle').written(profile,frame,#writes,C,log)end
    retarget_nodes = retarget_nodes + changed_writes
    max_retarget_raw_rotation = math.max(max_retarget_raw_rotation, raw_r)
    max_retarget_raw_position = math.max(max_retarget_raw_position, raw_p)
    max_retarget_step_rotation = math.max(max_retarget_step_rotation, step_r)
    max_retarget_step_position = math.max(max_retarget_step_position, step_p)
    max_retarget_residual_rotation = math.max(max_retarget_residual_rotation,
                                              residual_r)
    max_retarget_residual_position = math.max(max_retarget_residual_position,
                                              residual_p)
    if not binding.preview_update and rawget(_G,'__hd2ir_corpse_freeze_active')==true then
      local freezer=rawget(_G,'__hd2ir_corpse_freeze')
      local ok,err=pcall(freezer.observe,world,binding,node_offset,explicit,writes.numeric_owner,native)
      if not ok then freezer.report('capture',err)end
    end
    return true
  end

  -- Bounded, read-only evidence for action gating and FP frame ownership.
  -- This does NOT enable contact correction or infer an action from a weapon
  -- being equipped. No Unit/World handle or pose survives this callback.
  -- Death/respawn sampling is disabled in the release runtime.
  -- Bounded, read-only actor attribution. No camera-distance identity inference.
rawset(_G,"__hd2ir_physics_identity",(function()
  local states=setmetatable({},{__mode="k"})
  local known,cursor,next_poll,last_session={},0,0,nil
  local session_epoch=0
  local owned_cursor=0
  local remote_cursors={}
  -- Only sorted numeric IDs survive a poll. Ownership, health, Unit and World
  -- evidence are always refreshed; cache hits require exact current membership.
  local local_order,local_order_peer,remote_orders=nil,nil,{}
  local function sorted_owned(set,count,total,previous)
    -- The sum is only a cheap miss filter (8192 uint32 IDs fit exactly in a
    -- double). Equal count/sum NEVER prove membership: check every ID below.
    if previous and previous.total==total and #previous.ids==count then
      local order=previous.ids
      local exact=true
      for i=1,count do
        local id=order[i]
        if type(id)~='number' or not set[id] or
            (i>1 and order[i-1]<=id) then exact=false;break end
      end
      if exact then return order,previous end
    end
    local order={};for id in pairs(set)do order[#order+1]=id end
    table.sort(order,function(a,b)return a>b end)
    return order,{ids=order,total=total}
  end
  local extended_cursor,near_cursor,observed_high,poll=4096,0,4095,0
  -- Accept a bounded 32-bit range for IDs returned by the session, rather
  -- than assuming remote allocations fit our local 24-bit range. Lua numbers
  -- represent this entire range exactly; existence/type are checked below.
  local function valid_id(id)return type(id)=="number" and id>=0 and id<=4294967295 and id==math.floor(id)end
  local function distance(a,b)
    if not a or not b then return math.huge end
    local x,y,z=a[1]-b[1],a[2]-b[2],a[3]-b[3]
    return math.sqrt(x*x+y*y+z*z)
  end
  -- Skip only speculative discovery. The ordinary known-object, self health,
  -- ownership, animation and lifetime refresh below still runs on every poll.
  local function solo_discovery_allowed(avatars,session,peer,owned,complete)
    if #avatars~=1 or not complete or type(peer)~='string' or #peer==0 or #peer>128 then return false end
    local a=avatars[1]
    if type(a)~='table' or not a.unit or not a.world then return false end
    local s=states[a.unit]
    if not s or s.owner~=true or s.dead or not s.network or s.world~=a.world or
        not known[s.network] or not owned[s.network] or last_session~=session then return false end
    -- Both independent member lists must be complete, valid and remote-free.
    -- Missing/throwing/disagreeing APIs retain the original discovery path.
    for _,name in ipairs({'peers','other_peers'})do
      if type(GS[name])~='function' then return false end
      local rows=try(function()return GS[name](session)end)
      if type(rows)~='table' then return false end
      local count=0
      for _,member in pairs(rows)do
        count=count+1
        if count>32 or type(member)~='string' or #member==0 or #member>128 or member~=peer then return false end
      end
    end
    if try(function()return Net.game_session()end)~=session or
        try(function()return Net.peer_id()end)~=peer or
        try(function()return GS.in_session(session)end)~=true or
        try(function()return GS.game_object_exists(session,s.network)end)~=true or
        try(function()return GS.game_object_is_type(session,s.network,'gl7xl2w')end)~=true or
        try(function()return U.alive(a.unit)end)~=true or
        try(function()return U.has_animation_state_machine(a.unit)end)~=true then return false end
    local health=try(function()return GS.game_object_field(session,s.network,'health')end)
    local p=try(function()return v3(GS.game_object_field(session,s.network,'position'))end)
    return type(health)=='number' and health==health and health>0 and health<1.e9 and
      p~=nil and distance(a.p,p)<=1.0
  end

  -- Skip only speculative ID discovery after every currently rendered player
  -- has its own fresh, unique network/owner proof. This never supplies a role,
  -- life or write lease; the unchanged classifier and late guards still run.
  local function squad_discovery_allowed(avatars,session,peer,owned,complete)
    if #avatars<2 or #avatars>4 or not complete or type(peer)~='string' or #peer==0 or #peer>128 or
        type(GS.game_object_owner)~='function' then return false end
    local members
    for _,name in ipairs({'peers','other_peers'})do
      if type(GS[name])~='function' then return false end
      local list=try(function()return GS[name](session)end)
      if type(list)~='table' then return false end
      local found,count={},0
      for _,owner in pairs(list)do
        count=count+1
        if count>4 or type(owner)~='string' or #owner==0 or #owner>128 then return false end
        if owner~=peer then if found[owner]then return false end;found[owner]=true end
      end
      if members then
        for owner in pairs(found)do if not members[owner]then return false end end
        for owner in pairs(members)do if not found[owner]then return false end end
      else members=found end
    end
    local seen,networks,world,self_count={},{},nil,0
    local slot=rawget(_G,'__hd2ir_unit_instance_slot')
    if type(slot)~='function' then return false end
    for _,a in ipairs(avatars)do
      local s=states[a.unit]
      if not s or s.dead or not s.network or not known[s.network] or s.world~=a.world or
          s.instance~=slot(a.unit) or networks[s.network] or (world and world~=a.world) or
          try(function()return U.alive(a.unit)end)~=true or
          try(function()return U.has_animation_state_machine(a.unit)end)~=true then return false end
      world=a.world;networks[s.network]=true
      if try(function()return GS.game_object_exists(session,s.network)end)~=true or
          try(function()return GS.game_object_is_type(session,s.network,'gl7xl2w')end)~=true then return false end
      local owner=try(function()return GS.game_object_owner(session,s.network)end)
      if type(owner)~='string' or #owner==0 or #owner>128 or seen[owner] then return false end
      seen[owner]=true
      if owner==peer then
        if s.owner~=true or not owned[s.network] then return false end
        self_count=self_count+1
      elseif not members[owner] or s.owner~=false or s.friendly~=true or owned[s.network] then return false end
      local health=try(function()return GS.game_object_field(session,s.network,'health')end)
      local p=try(function()return v3(GS.game_object_field(session,s.network,'position'))end)
      if type(health)~='number' or health~=health or health<=0 or health>=1.e9 or not p or
          distance(a.p,p)>1.0 then return false end
    end
    for owner in pairs(members)do if not seen[owner]then return false end end
    return self_count==1 and try(function()return Net.game_session()end)==session and
      try(function()return Net.peer_id()end)==peer and try(function()return GS.in_session(session)end)==true
  end


  local function update(avatars)
    if type(avatars)~="table" or #avatars>32 then return end
    local timing=rawget(_G,'__hd2ir_death_timing')
    local slot=rawget(_G,'__hd2ir_unit_instance_slot')
    if timing and slot then
      local rows={}
      for _,a in ipairs(avatars)do rows[#rows+1]={unit=slot(a.unit),world=slot(a.world)}end
      pcall(timing.seen,rows)
    end
    -- Fresh enumeration, not a cached Unit.alive result, bounds identity.
    -- Invalidate an absence before throttling to reject fast pointer reuse.
    local present={};for _,a in ipairs(avatars)do present[a.unit]=a.world end
    for unit,s in pairs(states)do if present[unit]~=s.world then states[unit]=nil end end
    local now=os.clock();if now<next_poll then return end;next_poll=now+.25
    -- A failed refresh must not leave a stale restrictive class in use.
    for _,s in pairs(states)do s.role=0 end
    local session=Net and try(function()return Net.game_session()end)
    if not session or not GS or try(function()return GS.in_session(session)end)~=true then
      if timing and last_session~=nil then pcall(timing.reset)end
      known={};states=setmetatable({},{__mode="k"});last_session=nil
      extended_cursor,near_cursor,observed_high,poll=4096,0,4095,0
      remote_cursors={};local_order,local_order_peer,remote_orders=nil,nil,{}
      return
    end
    if last_session~=session then
      session_epoch=session_epoch+1
      known={};states=setmetatable({},{__mode="k"});last_session=session
      extended_cursor,near_cursor,observed_high,poll=4096,0,4095,0
      remote_cursors={};local_order,local_order_peer,remote_orders=nil,nil,{}
      if timing then pcall(timing.reset)end
    end
    local peer=try(function()return Net.peer_id()end)
    if local_order_peer~=peer then local_order=nil;remote_orders={};local_order_peer=peer end
    local owned,complete,owned_count,owned_total={},false,0,0
    local list=try(function()return GS.objects_owned_by(session,peer)end)
    if type(list)=="table" then
      complete=true;local count=0
      for _,id in pairs(list)do
        count=count+1
        if count>8192 then complete=false;break end
        if valid_id(id)then
          if not owned[id]then owned[id]=true;owned_count=owned_count+1;owned_total=owned_total+id end
        else complete=false end
      end
    end
    local considered={}
    local function consider(id,refresh)
      if not refresh and considered[id]~=nil then return end
      considered[id]=true
      if try(function()return GS.game_object_exists(session,id)end)==true and
          try(function()return GS.game_object_is_type(session,id,"gl7xl2w")end)==true then known[id]=true
      else known[id]=nil end
    end
    -- Prioritize recent locally-owned allocations, without doing a field/type
    -- query on every enemy/effect object in the host's ownership list.
    local recent,next_order=sorted_owned(owned,owned_count,owned_total,complete and local_order or nil)
    local_order=complete and next_order or nil
    local solo_discovery=solo_discovery_allowed(avatars,session,peer,owned,complete)
    local squad_discovery=not solo_discovery and squad_discovery_allowed(avatars,session,peer,owned,complete)
    if not solo_discovery and not squad_discovery then
    for i=1,math.min(16,#recent)do consider(recent[i])end
    for _=1,math.min(64,#recent)do
      owned_cursor=owned_cursor%#recent+1;consider(recent[owned_cursor])
    end
    for _=1,64 do consider(cursor);cursor=(cursor+1)%4096 end
    end
    -- Enumerate actual remote owners instead of guessing their allocation
    -- range from our own IDs. Both member-list functions are observed engine
    -- exports. A failed/missing one does not disable the original discovery.
    local discovery={peers={},rejected={},peer_sources={},solo_shortcut=solo_discovery,squad_shortcut=squad_discovery}
    if #avatars>1 and not squad_discovery and type(peer)=='string' then
      local members={}
      for _,name in ipairs({'peers','other_peers'})do
        local values=type(GS[name])=='function' and try(function()return GS[name](session)end)
        discovery.peer_sources[#discovery.peer_sources+1]=name..':'..type(values)
        if type(values)=='table' then
          local count=0
          for _,v in pairs(values)do
            count=count+1;if count>32 then break end
            if type(v)=='string' and #v>0 and #v<=128 and v~=peer then members[v]=true end
          end
        end
      end
      local order={};for v in pairs(members)do order[#order+1]=v end;table.sort(order)
      discovery.peer_count=#order
      local active={}
      for i=1,math.min(4,#order)do
        local remote=order[i];active[remote]=true
        local values=try(function()return GS.objects_owned_by(session,remote)end)
        local row={index=i,result=type(values),ids=0,invalid=0};discovery.peers[#discovery.peers+1]=row
        if type(values)=='table' then
          local set,count,unique_count,total={},0,0,0
          for _,id in pairs(values)do
            count=count+1;if count>8192 then row.truncated=true;break end
            if valid_id(id)then
              if not set[id]then set[id]=true;unique_count=unique_count+1;total=total+id end
            else row.invalid=row.invalid+1 end
          end
          local clean=row.invalid==0 and not row.truncated
          local found,next_remote=sorted_owned(set,unique_count,total,clean and remote_orders[remote] or nil)
          remote_orders[remote]=clean and next_remote or nil
          row.ids=#found;row.maximum=found[1];row.minimum=found[#found]
          -- At most 24 existence queries per owner, four owners, per refresh.
          for j=1,math.min(8,#found)do consider(found[j])end
          local c=remote_cursors[remote] or 0
          for _=1,math.min(16,#found)do c=c%#found+1;consider(found[c])end
          remote_cursors[remote]=c
        else remote_orders[remote]=nil end
      end
      for v in pairs(remote_cursors)do if not active[v]then remote_cursors[v]=nil end end
      for v in pairs(remote_orders)do if not active[v]then remote_orders[v]=nil end end
    else remote_orders={} end
    -- Keep the original low-ID scan. Only unresolved multi-actor scenes get
    -- 32 extra existence checks: 16 near observed allocations, 16 progressive.
    -- IDs are bounded game-object identifiers, never process-memory addresses.
    local unresolved=false
    for _,a in ipairs(avatars)do
      local s=states[a.unit];if not s or not s.network then unresolved=true;break end
    end
    observed_high=math.max(observed_high,recent[1] or 0)
    if #avatars>1 and unresolved and observed_high>=4096 then
      local upper=math.min(4294967295,observed_high+256)
      local lower=math.max(4096,observed_high-512)
      for _=1,16 do consider(lower+near_cursor%(upper-lower+1));near_cursor=near_cursor+1 end
      for _=1,16 do
        if extended_cursor>upper then extended_cursor=4096 end
        consider(extended_cursor);extended_cursor=extended_cursor+1
      end
    end
    local ids={};for id in pairs(known)do ids[#ids+1]=id end
    discovery.typed_candidates=#ids
    if #ids>32 then known={};ids={} end
    local objects={}
    for _,id in ipairs(ids)do
      consider(id,true)
      if known[id]then
        local p=try(function()return v3(GS.game_object_field(session,id,"position"))end)
        local health=try(function()return GS.game_object_field(session,id,"health")end)
        if p and type(health)=="number" and health==health and math.abs(health)<1.e9 then
          objects[id]={p=p,health=health,owned=owned[id]==true,ownership_complete=complete}
        else
          discovery.rejected[#discovery.rejected+1]={id=id,position=p~=nil,health_type=type(health)}
        end
      end
    end
    local live={}
    for _,a in ipairs(avatars)do
      if try(function()return U.alive(a.unit)end)==true then
        local s=states[a.unit]
        local instance=type(slot)=='function' and slot(a.unit) or nil
        if not s or s.world~=a.world or s.instance~=instance then s={role=0,instance=instance}end
        states[a.unit]=s;s.world=a.world
        local machine=try(function()return U.has_animation_state_machine(a.unit)end)
        live[#live+1]={a=a,s=s,machine=machine}
        local object=s.network and objects[s.network]
        -- A previously linked actor may ragdoll far from its final network
        -- position. Its known health transition proves death, not immobility
        -- or the absence of an animation state machine by itself.
        if object and object.health<=0 then s.dead=true;s.dead_since=s.dead_since or now end
      end
    end
    for id,object in pairs(objects)do
      if object.health>0 then
        local chosen,best,second=nil,math.huge,math.huge
        for _,item in ipairs(live)do
          if not item.s.dead and item.machine==true then
            local d=distance(item.a.p,object.p)
            if d<best then second,best,chosen=best,d,item elseif d<second then second=d end
          end
        end
        if chosen then
          local s=chosen.s
          -- Acquire at 5 cm with a clear 25 cm competitor margin. Once linked,
          -- allow animation/network interpolation, but do not jump to another
          -- network identity on a near encounter. Ambiguity retains unknown.
          local threshold=s.network==id and 1.0 or .05
          if best<=threshold and second-best>.25 and (not s.network or s.network==id)then
            s.network=id
            if object.owned then s.owner=true
            elseif object.ownership_complete and s.owner~=true then s.owner=false end
          end
        end
      end
    end
    local local_count={}
    for _,item in ipairs(live)do
      local s=item.s
      if s.owner==true and not s.dead and item.machine==true then local_count[s.world]=(local_count[s.world] or 0)+1 end
    end
    -- Backup acquisition only for an unlinked remote actor. Never relax local
    -- identity or corpse evidence. Require four consecutive mutual-unique
    -- observations, <=0.5 m error and >0.5 m competing-candidate margins.
    poll=poll+1
    local claimed={}
    for _,item in ipairs(live)do if item.s.network then claimed[item.s.network]=true end end
    for _,item in ipairs(live)do
      local s=item.s
      if not s.network and not s.dead and item.machine==true and complete and local_count[s.world]==1 then
        local best_id,best,second=nil,math.huge,math.huge
        for id,o in pairs(objects)do if o.health>0 then
          local d=distance(item.a.p,o.p)
          if d<best then second,best,best_id=best,d,id elseif d<second then second=d end
        end end
        local o=best_id and objects[best_id]
        local margin=math.huge
        if o then for _,other in ipairs(live)do
          if other~=item and not other.s.dead and other.machine==true then
            margin=math.min(margin,distance(other.a.p,o.p)-best)
          end
        end end
        if o and not o.owned and not claimed[best_id] and best<=.5 and second-best>.5 and margin>.5 then
          if s.fallback_id==best_id and s.fallback_poll==poll-1 and now-s.fallback_at<=.75 then
            s.fallback_hits=s.fallback_hits+1
          else s.fallback_hits=1 end
          s.fallback_id=best_id;s.fallback_poll=poll;s.fallback_at=now
          if s.fallback_hits>=4 then
            s.network=best_id;s.owner=false;s.match_method='stable-mutual';claimed[best_id]=true
          end
        else s.fallback_hits=0;s.fallback_id=nil end
      else s.fallback_hits=0;s.fallback_id=nil end
    end
    for _,item in ipairs(live)do
      local s=item.s;s.role=0
      if s.dead then s.role=3
      elseif item.machine==true then
        if s.owner==true and local_count[s.world]==1 then s.role=1
        elseif s.owner==false and (local_count[s.world]==1 or
            (local_count[s.world]==nil and s.friendly==true)) then
          -- Acquiring a teammate still needs a unique living local actor in
          -- this World. Once proven for this exact Unit/network identity,
          -- our death/respawn gap must not switch off a living teammate.
          -- Current health, complete ownership and the linked position are
          -- still required; missing/remote data never fabricate a new friend.
          local object=s.network and objects[s.network]
          if object and object.health>0 and object.ownership_complete and not object.owned and
              distance(item.a.p,object.p)<=1.0 then s.role=2;s.friendly=true end
        end
      end
    end
    if timing and slot then
      local rows={}
      for _,item in ipairs(live)do
        local s=item.s;local object=s.network and objects[s.network]
        -- role 1 alone can outlive a missing network refresh. Timing a new
        -- life additionally requires a current positive-health observation.
        local role=s.role==1 and (object and object.health>0 and 1 or 0) or s.role
        rows[#rows+1]={unit=slot(item.a.unit),world=slot(item.a.world),network=s.network,role=role}
      end
      pcall(timing.sample,rows)
    end
    -- Optional local diagnostic consumes only values already read above.
    -- Its failure must never alter classification, physics or death timing.
    local status_sink=rawget(_G,'__hd2ir_teammate_identity_status_sink')
    if type(status_sink)=='function' then
      pcall(status_sink,live,objects,recent,complete,peer,local_count,now,observed_high,extended_cursor,discovery)
    end
  end
  local function shared_life(unit,world)
      local s=states[unit]
      if not s or (s.role~=1 and s.role~=2) or s.dead or not s.network or not last_session or
          (world~=nil and s.world~=world) or try(function()return U.alive(unit)end)~=true then return end
      -- Friendly is the existing network/health/ownership proof, not a new
      -- proximity or appearance heuristic. Recheck its live animation gate
      -- every callback; uncertainty cannot borrow the local actor's token.
      if s.role==2 and (s.friendly~=true or
          try(function()return U.has_animation_state_machine(unit)end)~=true) then return end
      -- Current network life, not only the cached actor class from the 4 Hz
      -- discovery pass. Uncertain session/death evidence disables the pilot.
      if try(function()return Net.game_session()end)~=last_session or
         try(function()return GS.in_session(last_session)end)~=true or
         try(function()return GS.game_object_exists(last_session,s.network)end)~=true then return end
      local health=try(function()return GS.game_object_field(last_session,s.network,'health')end)
      if type(health)~='number' or health~=health or health<=0 or health>=1.e9 then return end
      local slot=rawget(_G,'__hd2ir_unit_instance_slot')
      -- A class transition retires its previous shared solver through the
      -- existing lifecycle kind comparison; self and friendly never share it.
      return {epoch=session_epoch,network=s.network,world=slot(s.world),kind=s.role==2 and 'friendly' or nil}
  end
  -- A dead actor owns an independent, already observed incarnation. A reused
  -- network ID can describe its reinforcement, so it is not a corpse lease.
  -- The caller must supply a Unit freshly enumerated in this render callback.
  local function dead_life(unit,world)
    local s=states[unit]
    local slot=rawget(_G,'__hd2ir_unit_instance_slot')
    if not s or s.role~=3 or not s.dead or not s.dead_since or
       s.owner~=false or s.friendly~=true or not s.network or not last_session or
       s.world~=world or type(slot)~='function' or not s.instance or
       slot(unit)~=s.instance or try(function()return U.alive(unit)end)~=true or
       try(function()return Net.game_session()end)~=last_session or
       try(function()return GS.in_session(last_session)end)~=true then return end
    -- Once the old network endpoint is gone/reused, require the old Unit to
    -- remain non-animated. A living/reused actor never inherits a corpse lease.
    local exists=try(function()return GS.game_object_exists(last_session,s.network)end)
    local health=exists==true and try(function()return GS.game_object_field(last_session,s.network,'health')end)
    local still_dead=type(health)=='number' and health==health and health<=0 and math.abs(health)<1.e9
    if not still_dead and try(function()return U.has_animation_state_machine(unit)end)~=false then return end
    return {epoch=session_epoch,network=s.network,world=slot(world),kind='friendly',instance=s.instance}
  end

  local function presentation_worlds(avatars,contexts,suppressed)
    local result={}
    -- suppressed is the legacy global carrier visibility hint, not FP proof:
    -- armory Worlds have camera-zero Avatars and latch it for the whole menu.
    -- Keep that visibility code unchanged. Physics requires a successful,
    -- empty FP-graph query for its own World, plus the existing actor proofs.
    if type(contexts)~='table' or #contexts<2 or #contexts>32 or
       type(avatars)~='table' or #avatars>32 then return result end
    local network_worlds,scene_worlds,current_worlds={}, {}, {}
    local anchor=false
    for _,context in ipairs(contexts)do
      current_worlds[context.world]=true
      if type(context.scene_sources)~='table' or #context.scene_sources>0 or
         context.fp_graph_absent~=true then scene_worlds[context.world]=true end
    end
    for _,item in ipairs(avatars)do
      local s=states[item.unit]
      -- Even temporarily unresolved/dead network actors exclude their World.
      -- A fresh living local network actor is the positive gameplay witness.
      if s and s.network then network_worlds[item.world]=true end
      if not anchor and s and s.role==1 and shared_life(item.unit,item.world) then anchor=true end
    end
    if not anchor then return result end
    local slot=rawget(_G,'__hd2ir_unit_instance_slot')
    if type(slot)~='function' then return result end
    for world in pairs(current_worlds)do
      if not network_worlds[world] and not scene_worlds[world] then result[world]=slot(world) end
    end
    return result
  end
  local function presentation_lives(avatars,contexts,suppressed)
    local result={};local worlds=presentation_worlds(avatars,contexts,suppressed)
    for _,item in ipairs(avatars or {})do
      local s=states[item.unit]
      if item.needed and worlds[item.world] and (not s or (s.role==0 and not s.network and not s.dead)) and
         try(function()return U.alive(item.unit)end)==true then
        result[item.instance_slot]={epoch=session_epoch,world=worlds[item.world],network=0,kind='presentation'}
      end
    end
    return result
  end
  return {update=update,role=function(unit)local s=states[unit];return s and s.role or 0 end,
    shared_life=shared_life,dead_life=dead_life,presentation_lives=presentation_lives,presentation_worlds=presentation_worlds,
    dead_age=function(unit)
      local s=states[unit]
      if s and s.role==3 and s.dead_since then return math.max(0,os.clock()-s.dead_since)end
    end}
end)())

  -- Optional experimental adapter. Only numeric identities survive a callback;
-- no cached World/Unit handle is dereferenced, and uint64 tokens stay opaque.
rawset(_G,'__hd2ir_shared_body_lifecycle',(function()
  local M={}
  local live={}
  local writes={}
  local function valid(n)return type(n)=='number' and n==math.floor(n) and n>=0 and n<=9007199254740991 end
  function M.observe(avatars,api,evidence)
    if not(api.shared_next_incarnation and api.forget_shared_avatar and api.set_avatar_incarnation) then return end
    local accepted={}
    local ok=pcall(function()
      assert(type(avatars)=='table' and #avatars<=32)
      local seen={}
      for _,item in ipairs(avatars)do
        local id=item.instance_slot
        assert(valid(id) and id>0 and not seen[id]);seen[id]=true
        local e=evidence(item)
        if e~=nil then
          assert(valid(e.epoch) and valid(e.world) and valid(e.network))
          accepted[id]=e
        end
      end
    end)
    if not ok then accepted={} end -- incomplete/ambiguous evidence retires, never guesses
    for id,old in pairs(live)do
      local e=accepted[id]
      if not e or old.epoch~=e.epoch or old.world~=e.world or old.network~=e.network or old.kind~=e.kind then
        api.forget_shared_avatar(id,old.token);live[id]=nil
      end
    end
    for id,e in pairs(accepted)do if not live[id]then
      local token=api.shared_next_incarnation()
      if token~=nil and token~=0 then
        live[id]={epoch=e.epoch,world=e.world,network=e.network,kind=e.kind,token=token}
      end
    end end
  end
  function M.token(id)local value=live[id];return value and value.token end
  function M.written(profile,frame,count,api,report)
    if not(api.shared_body_profile and api.shared_body_solves) or api.shared_body_profile(profile.id)~=1 then return end
    local row=writes[profile.hash] or {units=0,nodes=0,last=-1000}
    writes[profile.hash]=row;row.units=row.units+1;row.nodes=row.nodes+count
    if frame-row.last>=120 then
      row.last=frame
      report('shared-body-write unit='..profile.hash..' frame='..frame..' verified_units='..row.units..
        ' verified_nodes='..row.nodes..' shared_solves='..tostring(api.shared_body_solves()))
    end
  end
  return M
end)())

  rawset(_G,'__hd2ir_corpse_motion',(function()
-- Bounded, visual-only four-second articulated fall. Pure numeric state;
-- no engine Actors, original Units, weapon contacts or network calls.
-- The support plane is an approximation from the last complete living feet,
-- NOT a terrain query. Small terrain penetration is an accepted limitation.
return (function()
  local M={}
  local names={'hips','chest','head','l_shoulder','r_shoulder','l_elbow','r_elbow',
    'l_hand','r_hand','l_thigh','r_thigh','l_knee','r_knee','l_foot','r_foot'}
  M.names=names
  local function finite(v)return type(v)=='number' and v==v and math.abs(v)<1e7 end
  local function vec(v,n)
    assert(type(v)=='table','numeric vector required')
    for i=1,n do assert(finite(v[i]),'nonfinite vector')end
  end
  local function add(a,b)return {a[1]+b[1],a[2]+b[2],a[3]+b[3]}end
  local function sub(a,b)return {a[1]-b[1],a[2]-b[2],a[3]-b[3]}end
  local function scale(a,k)return {a[1]*k,a[2]*k,a[3]*k}end
  local function dot(a,b)return a[1]*b[1]+a[2]*b[2]+a[3]*b[3]end
  local function cross(a,b)return {a[2]*b[3]-a[3]*b[2],a[3]*b[1]-a[1]*b[3],a[1]*b[2]-a[2]*b[1]}end
  local function length(a)return math.sqrt(dot(a,a))end
  local function unit(a)local d=length(a);assert(d>1e-8,'degenerate direction');return scale(a,1/d)end
  local function qm(a,b)
    return {a[4]*b[1]+a[1]*b[4]+a[2]*b[3]-a[3]*b[2],
      a[4]*b[2]-a[1]*b[3]+a[2]*b[4]+a[3]*b[1],
      a[4]*b[3]+a[1]*b[2]-a[2]*b[1]+a[3]*b[4],
      a[4]*b[4]-a[1]*b[1]-a[2]*b[2]-a[3]*b[3]}
  end
  local function qr(q,v)
    local t=scale(cross(q,v),2)
    return add(v,add(scale(t,q[4]),cross(q,t)))
  end
  local function between(a,b)
    a,b=unit(a),unit(b)
    local d=math.max(-1,math.min(1,dot(a,b)))
    if d<-.999999 then
      local side=math.abs(a[1])<.8 and {1,0,0} or {0,1,0}
      local axis=unit(cross(a,side));return {axis[1],axis[2],axis[3],0}
    end
    local v=cross(a,b);local w=1+d;local n=math.sqrt(dot(v,v)+w*w)
    return {v[1]/n,v[2]/n,v[3]/n,w/n}
  end
  local edges={{'hips','chest'},{'chest','head'},
    {'chest','l_shoulder'},{'chest','r_shoulder'},
    {'hips','l_thigh'},{'hips','r_thigh'},
    {'l_shoulder','r_shoulder'},{'l_thigh','r_thigh'},
    {'hips','l_shoulder'},{'hips','r_shoulder'},
    {'chest','l_thigh'},{'chest','r_thigh'},
    {'l_shoulder','l_elbow'},{'l_elbow','l_hand'},
    {'r_shoulder','r_elbow'},{'r_elbow','r_hand'},
    {'l_thigh','l_knee'},{'l_knee','l_foot'},
    {'r_thigh','r_knee'},{'r_knee','r_foot'}}
  local child={hips='chest',chest='head',head='chest',
    l_shoulder='l_elbow',r_shoulder='r_elbow',l_elbow='l_hand',r_elbow='r_hand',
    l_thigh='l_knee',r_thigh='r_knee',l_knee='l_foot',r_knee='r_foot'}
  local terminal={l_hand='l_elbow',r_hand='r_elbow',l_foot='l_knee',r_foot='r_knee'}
  function M.new(anchors,velocity)
    local s={points={},links={},steps=0,initial={}}
    for _,name in ipairs(names)do
      local row=assert(anchors[name],'missing articulated anchor '..name)
      vec(row.p,3);vec(row.q,4)
      local norm=math.sqrt(row.q[1]^2+row.q[2]^2+row.q[3]^2+row.q[4]^2)
      assert(math.abs(norm-1)<.001,'invalid anchor quaternion')
      s.initial[name]={p={unpack(row.p)},q={unpack(row.q)}}
    end
    local height=length(sub(anchors.head.p,anchors.hips.p))+
      .5*(length(sub(anchors.l_foot.p,anchors.hips.p))+length(sub(anchors.r_foot.p,anchors.hips.p)))
    assert(height>.35 and height<3.5,'unsupported articulated size')
    s.floor=math.min(anchors.l_foot.p[3],anchors.r_foot.p[3])-.025*height
    local v=velocity or {0,0,0};vec(v,3)
    if length(v)>4 then v=scale(unit(v),4)end
    -- A small deterministic toppling impulse prevents a perfectly symmetric
    -- standing pose from remaining balanced. It is not a measured game blast.
    local right=unit(sub(anchors.r_shoulder.p,anchors.l_shoulder.p))
    local up=unit(sub(anchors.chest.p,anchors.hips.p))
    local forward=unit(cross(right,up))
    s.forward=forward
    for _,name in ipairs(names)do
      local p=s.initial[name].p
      local radius=(name=='hips' or name=='chest') and .065 or name=='head' and .047 or .019
      local angular=scale(cross(right,sub(p,anchors.hips.p)),1.6)
      local speed=add(v,add(angular,scale(forward,.3)))
      local mass=(name=='hips' or name=='chest') and 4 or name=='head' and 2 or 1
      s.points[name]={p={unpack(p)},previous=sub(p,scale(speed,1/120)),radius=radius*height,weight=1/mass}
    end
    for _,edge in ipairs(edges)do
      local d=length(sub(anchors[edge[1]].p,anchors[edge[2]].p))
      assert(d>.005 and d<height*1.2,'degenerate body constraint')
      s.links[#s.links+1]={a=edge[1],b=edge[2],min=d,max=d}
    end
    -- Limit complete folding back without locking the initial aiming bend.
    for _,chain in ipairs({{'l_shoulder','l_elbow','l_hand'},{'r_shoulder','r_elbow','r_hand'},
                           {'l_thigh','l_knee','l_foot'},{'r_thigh','r_knee','r_foot'}})do
      local a=length(sub(anchors[chain[1]].p,anchors[chain[2]].p))
      local b=length(sub(anchors[chain[2]].p,anchors[chain[3]].p))
      s.links[#s.links+1]={a=chain[1],b=chain[3],min=math.max(math.abs(a-b),.24*(a+b)),max=a+b}
    end
    return s
  end
  local function step(s)
    local dt=1/120
    for _,name in ipairs(names)do
      local r=s.points[name];local p,b=r.p,r.previous
      local x,y,z=p[1],p[2],p[3]
      p[1]=x+(x-b[1])*.992;p[2]=y+(y-b[2])*.992;p[3]=z+(z-b[3])*.992-9.82*dt*dt
      b[1],b[2],b[3]=x,y,z
    end
    for iteration=1,16 do
      for _,link in ipairs(s.links)do
        local a,b=s.points[link.a],s.points[link.b]
        local ap,bp=a.p,b.p
        local x,y,z=bp[1]-ap[1],bp[2]-ap[2],bp[3]-ap[3]
        local d=math.sqrt(x*x+y*y+z*z)
        assert(d>1e-9,'collapsed constraint')
        local target=math.max(link.min,math.min(link.max,d))
        local k=(d-target)/d/(a.weight+b.weight)
        local ka,kb=k*a.weight,k*b.weight
        ap[1]=ap[1]+x*ka;ap[2]=ap[2]+y*ka;ap[3]=ap[3]+z*ka
        bp[1]=bp[1]-x*kb;bp[2]=bp[2]-y*kb;bp[3]=bp[3]-z*kb
      end
      for _,name in ipairs(names)do
        local r=s.points[name];local level=s.floor+r.radius
        if r.p[3]<level then
          r.p[3]=level
          -- Tangential damping only when contacting the approximate plane.
          r.previous[1]=r.previous[1]+(r.p[1]-r.previous[1])*.12
          r.previous[2]=r.previous[2]+(r.p[2]-r.previous[2])*.12
          r.previous[3]=math.max(r.previous[3],level)
        end
      end
    end
    for _,name in ipairs(names)do vec(s.points[name].p,3)end
    s.steps=s.steps+1
  end
  function M.advance(s,elapsed)
    assert(finite(elapsed) and elapsed>=0,'invalid elapsed time')
    local wanted=math.min(480,math.floor(elapsed*120+1e-6))
    -- A render hitch cannot cause an unlimited catch-up burst. Freeze only
    -- after all 480 fixed steps, never a stale midway pose at wall-clock 4s.
    for _=1,math.min(32,math.max(0,wanted-s.steps))do step(s)end
    return s.steps==480
  end
  function M.frames(s)
    local out={}
    for name,next_name in pairs(child)do
      local initial=sub(s.initial[next_name].p,s.initial[name].p)
      local current=sub(s.points[next_name].p,s.points[name].p)
      out[name]={q=between(initial,current),p=s.points[name].p,origin=s.initial[name].p}
    end
    -- Keep torso roll coherent with the two shoulders, not only its long axis.
    local a=sub(s.initial.r_shoulder.p,s.initial.l_shoulder.p)
    local b=sub(s.points.r_shoulder.p,s.points.l_shoulder.p)
    local q=out.hips.q
    local up=unit(sub(s.points.chest.p,s.points.hips.p))
    a=qr(q,a);a=sub(a,scale(up,dot(a,up)));b=sub(b,scale(up,dot(b,up)))
    local twist=between(a,b);out.hips.q=qm(twist,q)
    out.chest.q=out.hips.q
    for name,parent in pairs(terminal)do
      out[name]={q=out[parent].q,p=s.points[name].p,origin=s.initial[name].p}
    end
    return out
  end
  function M.deform(frames,owner,pose)
    local f=assert(frames[owner],'unknown articulated owner')
    return {q=qm(f.q,pose.q),p=add(f.p,qr(f.q,sub(pose.p,f.origin)))}
  end
  function M.owner(name)
    if child[name] or terminal[name] then return name end
    if name=='neck' then return 'head' end
    if name=='spine1' or name=='spine2' or name=='l_clavicle' or name=='r_clavicle' then return 'chest' end
    for _,side in ipairs({'l_','r_'})do
      if name==side..'shoulder_twist' then return side..'shoulder' end
      if name==side..'hand_twist' then return side..'elbow' end
      if name:sub(1,2)==side and name:find('finger',3,true) then return side..'hand' end
      if name==side..'ball' or name==side..'toe' then return side..'foot' end
    end
    if name=='hips' or name=='boss' or name=='root' then return 'hips' end
  end
  return M
end)()

end)())
  -- Visual-only corpse copies. Never relink, destroy or edit native Avatar/armour
-- graphs. Engine handles below live for ONE render callback, not in registries.
rawset(_G,'__hd2ir_corpse_freeze',(function()
  local F={enabled=false}
  local frozen,clones,live_cache,logged,failed={},{},{},{},{}
  local live_pending,errors={},{}
  local pins={};rawset(_G,'__hd2ir_corpse_slots',pins)
  local pending,cores={},{}
  local tick,now,created=0,0,0
  local native_api
  local function slot(u)return rawget(_G,'__hd2ir_unit_instance_slot')(u)end
  local function note(key,message)
    if not logged[key] then logged[key]=true;log('corpse-copy-v4 '..message)end
  end
  function F.report(kind,err)
    local r=errors[kind] or {next=0,count=0};errors[kind]=r;r.count=r.count+1
    if now>=r.next then
      log('corpse-copy-v4 '..kind..' rejected count='..r.count..' error='..tostring(err))
      r.next=now+5
    end
  end
  local function identity()return rawget(_G,'__hd2ir_physics_identity')end
  local function eligible(b)
    local p=b.profile
    local flags=p and tonumber(p.flags)
    if not flags or flags~=math.floor(flags) or flags<0 or flags>65535 then return false end
    local gender=math.floor(flags/4)%4
    return (gender==1 or gender==2) and p.authored and p.active and not p.observe_only and not b.pose_only
  end
  local function close(aq,ap,bq,bp)
    return aq and ap and bq and bp and qerror_degrees(aq,bq)<.1 and perror(ap,bp)<.001
  end
  local function available()
    if not native_api or not native_api.freeze_corpse_physics then return false,'corpse retirement ABI' end
    for _,name in ipairs({'spawn_unit','destroy_unit','unlink_unit','update_unit'})do
      if type(get(W,name))~='function' then return false,'World.'..name end
    end
    for _,name in ipairs({'name_hash','set_unit_visibility','scene_graph_link','scene_graph_parent','has_node','node','alive'})do
      if type(get(U,name))~='function' then return false,'Unit.'..name end
    end
    return true
  end
  local function core(avatar)
    local key=slot(avatar.unit)
    if cores[key] then return cores[key] end
    if U.alive(avatar.unit)~=true or U.has_node(avatar.unit,'hips')~=true then return nil end
    local n=U.node(avatar.unit,'hips')
    local count=U.num_scene_graph_items(avatar.unit)
    if type(n)~='number' or n~=math.floor(n) or n<0 or n>count or count>256 then return nil end
    local q,p=world_pose(avatar.unit,n)
    if not q or not p then return nil end
    local c={node=n,q=q,p=p,owner=key}
    if U.has_node(avatar.unit,'head')==true then
      local head=U.node(avatar.unit,'head')
      if type(head)=='number' and head>=0 and head<=count then
        local _,hp=world_pose(avatar.unit,head)
        local d=hp and perror(hp,p)
        if d and d>.1 and d<2 then
          c.up=qrotate(qconjugate(q),{(hp[1]-p[1])/d,(hp[2]-p[2])/d,(hp[3]-p[3])/d})
        end
      end
    end
    cores[key]=c;return c
  end
  local limb_edges={{'neck','head'},{'chest','neck'},
    {'l_clavicle','l_shoulder'},{'l_shoulder','l_elbow'},{'l_elbow','l_hand'},
    {'r_clavicle','r_shoulder'},{'r_shoulder','r_elbow'},{'r_elbow','r_hand'},
    {'hips','l_thigh'},{'l_thigh','l_knee'},{'l_knee','l_foot'},
    {'hips','r_thigh'},{'r_thigh','r_knee'},{'r_knee','r_foot'}}
  local function native_rows(native,array)
    if not array then return native or {} end
    local rows={}
    -- Snapshots contain booleans, handles, profile tables and numbers alongside
    -- the pose array. Never pairs() that container or inspect its metadata as bones.
    for _,pose in ipairs(native or {})do
      if type(pose)=='table' and type(pose.name)=='string' then rows[pose.name]=pose end
    end
    return rows
  end
  local function detached(native,c,cached)
    for name,pose in pairs(native or {})do
      if type(pose)~='table' or not pose.p then return true end
      if name~='boss' and name~='root' and name~='StingrayEntityRoot' and
         name~='FbxAxisSystem_ConvertNode' and perror(pose.p,c.p)>3.5 then return true end
    end
    for _,edge in ipairs(limb_edges)do
      local a,b=native and native[edge[1]],native and native[edge[2]]
      local ca,cb=cached and cached[edge[1]],cached and cached[edge[2]]
      if a and b and ca and cb then
        local rest=perror(ca.p,cb.p)
        if perror(a.p,b.p)>rest+math.max(.12,rest*.4) then return true end
      end
    end
    return false
  end
  local function capture(unit,count,offset,c,explicit)
    local rows={}
    for n=offset,count-1+offset do
      local chosen=explicit and explicit[n+1]
      local q,p
      if chosen then q,p=chosen.q,chosen.p else q,p=world_pose(unit,n)end
      if not q or not p then return nil end
      q,p=relative_pose(c.q,c.p,q,p)
      if not q or not p then return nil end
      rows[n]={q={q[1],q[2],q[3],q[4]},p={p[1],p[2],p[3]}}
    end
    return rows
  end
  function F.native_handoff_clean(scope)
    if not scope then return next(pending)==nil and next(frozen)==nil and next(clones)==nil end
    local clean=rawget(_G,'__hd2ir_handoff_scope_clean')
    local function owner(r)return r.world,r.owner end
    return clean(scope,frozen,owner) and clean(scope,clones,owner) and
      clean(scope,pending,function(r)return slot(r.world),r.binding and r.binding.avatar and slot(r.binding.avatar.unit) end)
  end
  function F.begin(api,frame)
    tick,now,native_api=frame,os.clock(),api;pending,cores,live_pending={},{},{}
    if api and api.corpse_freeze_context then api.corpse_freeze_context(frame,0)end
    local was=F.enabled
    F.enabled=api and api.corpse_freeze_enabled and tonumber(api.corpse_freeze_enabled())==1 or false
    if was~=F.enabled then log('corpse-copy-v4 enabled='..tostring(F.enabled)..' declared_gender_only=true')end
    rawset(_G,'__hd2ir_corpse_freeze_active',F.enabled or next(clones)~=nil)
    for key,r in pairs(live_cache)do if now-r.time>30 then live_cache[key]=nil end end
  end
  local control_reason,control_log_after=nil,0
  function F.control_context(contexts,avatars)
    if not native_api or not native_api.corpse_freeze_context then return end
    local function check()
      -- Positive ship evidence, never unit-count or camera-distance guessing.
      -- Extra Worlds (menus/ADS/loading) and unavailable state stay locked.
      if type(contexts)~='table' or #contexts~=1 or type(avatars)~='table' then return false,'worlds-unconfirmed' end
      local context=contexts[1]
      local officer,display=false,false
      for _,row in ipairs(context.scene_sources or {})do
        if row.kind=='democracy-officer' and row.hash=='15678e360612b805' and U.alive(row.unit)==true then officer=true end
        if row.kind=='ship-display' and row.hash=='5b390845a8e3fc29' and U.alive(row.unit)==true then display=true end
      end
      if not officer or not display then return false,'ship-anchors-missing' end
      -- This gates the scene, not a particular player's solver. Network health
      -- ownership and locomotion states are not required for a ship UI switch.
      -- Both current, independently discovered ship-only resources must exist
      -- in the sole visible Avatar World; a retained ship + mission World fails.
      for _,item in ipairs(avatars)do
        if item.world==context.world and U.alive(item.unit)==true and U.has_animation_state_machine(item.unit)==true then
          return true,'ship-anchors-confirmed'
        end
      end
      return false,'live-ship-avatar-missing'
    end
    local ok,ship,reason=pcall(check)
    native_api.corpse_freeze_context(tick,ok and ship and 1 or 2)
    reason=ok and reason or 'query-failed'
    if reason~=control_reason and now>=control_log_after then
      log('corpse-control-v2 frame='..tick..' reason='..tostring(reason))
      control_reason=reason;control_log_after=now+5
    end
  end
  -- Called before the normal driver consumes native_snapshot or can reject a
  -- severed input. Only already-proven ownership plus a living cache qualify.
  function F.queue_input(world,b,snapshot)
    if not F.enabled or not eligible(b) or not b.instance_id or identity().role(b.avatar.unit)~=3 then return end
    local key=slot(b.unit)
    if (frozen[key] and not frozen[key].guard) or clones[key] then return end
    local cached=live_cache[key]
    if not cached or cached.world~=slot(world) or cached.owner~=slot(b.avatar.unit) or
       cached.hash~=b.profile.hash or cached.count~=b.node_count or now-cached.time>30 then return end
    if snapshot and (snapshot.frame~=tick or snapshot.unit~=b.unit or snapshot.profile~=b.profile or
       snapshot.node_count~=b.node_count or snapshot.offset~=cached.offset) then return end
    local c=core(b.avatar);if not c then return end
    pending[key]={world=world,binding=b,offset=cached.offset,core=c,cache_only=true,
      early=detached(native_rows(snapshot,true),c,cached.native)}
  end
  function F.observe(world,b,offset,explicit,numeric_owner,native)
    if not F.enabled or not eligible(b) then return end
    local key=slot(b.unit);if (frozen[key] and not frozen[key].guard) or clones[key] then return end
    local role=identity().role(b.avatar.unit)
    if role~=1 and role~=2 and role~=3 then return end
    local c=core(b.avatar);if not c then return end
    local torn=detached(native,c,live_cache[key] and live_cache[key].native)
    if role==3 then
      pending[key]={world=world,binding=b,offset=offset,core=c,explicit=explicit,numeric_owner=numeric_owner,early=torn}
      return
    end
    if torn or U.has_animation_state_machine(b.avatar.unit)~=true then return end
    local bucket=math.floor(now*4)
    local old=live_cache[key]
    if old and old.bucket==bucket then return end
    local count=0;for _ in pairs(live_cache)do count=count+1 end
    if not old and count>=256 then return end
    local shape=capture(b.unit,b.node_count,offset,c,explicit)
    if shape then
      local saved_native,joints={},{}
      for name,row in pairs(native or {})do
        if row.p then saved_native[name]={p={row.p[1],row.p[2],row.p[3]}}end
      end
      for i,n in ipairs(b.profile.nodes)do
        local source=b.profile.target_sources[i]
        local name=source and source_names[source+1]
        if name and math.floor((b.profile.target_flags[i] or 0)/1024)%2==1 then joints[n+offset]=name end
      end
      live_pending[key]={shape=shape,bucket=bucket,time=now,world=slot(world),native=saved_native,up=c.up,
        owner=c.owner,hash=b.profile.hash,count=b.node_count,offset=offset,joints=joints,
        core={q={unpack(c.q)},p={unpack(c.p)}}}
    end
  end
  local function prepare(item,use_cache)
    local b,c=item.binding,item.core
    local unit,count,offset=b.unit,b.node_count,item.offset
    assert(eligible(b) and (offset==0 or offset==1),'undeclared gender or invalid offset')
    assert(U.alive(unit)==true and U.num_scene_graph_items(unit)==count and count>=2 and count<=256 and
      U.has_node(unit,'StingrayEntityRoot')==true and U.node(unit,'StingrayEntityRoot')==offset,'unsupported Unit root/layout')
    for _,n in ipairs(b.profile.nodes)do
      assert(n>=1 and n<count and n==math.floor(n),'invalid target or weighted root')
    end
    -- Autodesk documents name_hash -> spawn_unit; do not hash a bare hex path
    -- a second time, and never try guessed private resource names.
    local resource=U.name_hash(unit)
    assert(type(resource)=='string' and #resource>0,'spawn resource unavailable')
    local shape=not use_cache and capture(unit,count,offset,c,item.explicit) or nil
    assert(shape or use_cache,'corrected shape capture failed')
    local parents={}
    if use_cache then
      for n=offset+1,count-1+offset do parents[n]=U.scene_graph_parent(unit,n)end
    end
    return {unit=unit,world=item.world,shape=shape,count=count,offset=offset,core=c,resource=resource,parents=parents,
      key=slot(unit),hash=b.profile.hash,world_slot=slot(item.world),owner=c.owner,
      profile_id=b.profile.id,instance_id=b.instance_id,avatar_id=b.avatar.id}
  end
  local function set(unit,node,pose)
    U.set_local_rotation(unit,node,assert(engine_quaternion(pose.q)))
    U.set_local_position(unit,node,assert(engine_vector(pose.p)))
  end
  local function apply(r)
    assert(created<256,'copy lifetime limit')
    created=created+1 -- Failed engine spawn attempts count too; bounded per session.
    local u=assert(W.spawn_unit(r.world,r.resource,assert(engine_vector(r.core.p)),assert(engine_quaternion(r.core.q))),'spawn failed')
    assert(u~=r.unit,'spawn returned original Unit')
    r.clone=u
    U.set_unit_visibility(u,false)
    assert(U.alive(u)==true and U.name_hash(u)==r.resource and U.num_scene_graph_items(u)==r.count and
      U.has_node(u,'StingrayEntityRoot')==true and U.node(u,'StingrayEntityRoot')==r.offset,'copy identity/layout mismatch')
    assert(U.has_animation_state_machine(u)~=true,'copy has active animation controller')
    if type(get(U,'num_actors'))=='function' then assert(U.num_actors(u)==0,'copy has native actors')end
    W.unlink_unit(r.world,u)
    U.scene_graph_link(u,r.offset,nil)
    for n=r.offset+1,r.count-1+r.offset do U.scene_graph_link(u,n,r.offset)end
    set(u,r.offset,r.core)
    for n=r.offset+1,r.count-1+r.offset do set(u,n,r.shape[n])end
    W.update_unit(r.world,u)
    for n=r.offset,r.count-1+r.offset do
      local q,p=world_pose(u,n)
      local eq,ep=r.core.q,r.core.p
      if n~=r.offset then eq,ep=compose_pose(eq,ep,r.shape[n].q,r.shape[n].p)end
      assert(close(q,p,eq,ep),'copy world shape readback failed')
      if n~=r.offset then assert(U.scene_graph_parent(u,n)==r.offset,'copy parent readback failed')end
    end
  end
  local function register_clone(r)
    local key=slot(r.clone)
    local record={world=r.world_slot,owner=r.owner,hash=r.hash,count=r.count,root=r.offset,original=r.key,clone=key,
      guard=r.guard,shape=r.guard and r.shape or nil,
      motion_shape=r.motion_shape,motion_owners=r.motion_owners,
      fixed_core=r.motion_shape and r.core or nil}
    clones[key]=record
    pins[key],pins[r.key],pins[r.world_slot],pins[r.owner]=true,true,true,true
    return record
  end
  local function fallen_rotation(c,up)
    assert(up,'no intact body axis for fallen fallback')
    local a=qrotate(c.q,up)
    local d=math.sqrt(a[1]*a[1]+a[2]*a[2])
    local b
    if d>.01 then b={a[1]/d,a[2]/d,0}
    else
      local side=qrotate(c.q,{1,0,0});d=math.sqrt(side[1]*side[1]+side[2]*side[2])
      b=d>.01 and {side[1]/d,side[2]/d,0} or {1,0,0}
    end
    local q=assert(qnormalize({a[2]*b[3]-a[3]*b[2],a[3]*b[1]-a[1]*b[3],
      a[1]*b[2]-a[2]*b[1],1+a[1]*b[1]+a[2]*b[2]+a[3]*b[3]}))
    return qmul(qmul(qconjugate(c.q),q),c.q)
  end
  local function rewrite_copy(world,u,r,shape,c)
    set(u,r.root,c)
    for n=r.root+1,r.root+r.count-1 do set(u,n,shape[n])end
    W.update_unit(world,u)
    for n=r.root+1,r.root+r.count-1 do
      local q,p=world_pose(u,n);local eq,ep=compose_pose(c.q,c.p,shape[n].q,shape[n].p)
      assert(close(q,p,eq,ep),'guard final shape readback failed')
    end
  end
  local function start_motion(prepared,g,age)
    local m=assert(rawget(_G,'__hd2ir_corpse_motion'),'articulated module unavailable')
    local ranked={};for _,r in ipairs(prepared)do ranked[#ranked+1]=r end
    local required={};for _,name in ipairs(m.names)do required[name]=true end
    local function score(r)
      local n=0;for _,name in pairs(r.cached.joints or {})do if required[name]then n=n+1 end end;return n
    end
    table.sort(ranked,function(a,b)local x,y=score(a),score(b);if x~=y then return x>y end;return a.hash<b.hash end)
    local anchors={}
    local initial=assert(ranked[1].cached.core,'missing complete living frame')
    for _,r in ipairs(ranked)do
      assert(now-r.cached.time<=.8,'living articulated sample too old')
      for n,name in pairs(r.cached.joints or {})do
        if required[name] and not anchors[name] then
          local q,p=compose_pose(initial.q,initial.p,r.shape[n].q,r.shape[n].p)
          anchors[name]={q=q,p=p}
        end
      end
    end
    local age_of_sample=math.max(.016,now-ranked[1].cached.time)
    local current=prepared[1].core.p
    local velocity={(current[1]-initial.p[1])/age_of_sample,(current[2]-initial.p[2])/age_of_sample,(current[3]-initial.p[3])/age_of_sample}
    local state=m.new(anchors,velocity) -- Validate completely before altering prepared copies.
    local plans={}
    for _,r in ipairs(prepared)do
      local owners,shape={},{}
      for n,name in pairs(r.cached.joints or {})do owners[n]=m.owner(name)end
      for n=r.offset+1,r.count-1+r.offset do
        local q,p=compose_pose(initial.q,initial.p,r.shape[n].q,r.shape[n].p)
        shape[n]={q=q,p=p}
        if not owners[n] then
          local parent=r.parents[n];local visited={}
          for _=1,r.count do
            if type(parent)~='number' or parent<=r.offset or parent>=r.offset+r.count or visited[parent]then break end
            visited[parent]=true
            if owners[parent]then owners[n]=owners[parent];break end
            parent=r.parents[parent]
          end
        end
        if not owners[n] then
          local best=math.huge
          for _,name in ipairs(m.names)do
            local d=perror(p,anchors[name].p)
            if d<best then best=d;owners[n]=name end
          end
        end
      end
      plans[#plans+1]={r=r,shape=shape,owners=owners}
    end
    g.motion=state;g.motion_started=now-math.min(age,4)
    for _,plan in ipairs(plans)do
      plan.r.motion_shape,plan.r.motion_owners=plan.shape,plan.owners
      plan.r.core=initial
    end
  end
  local function update_motion(world,g,rows)
    local m=rawget(_G,'__hd2ir_corpse_motion')
    local complete,c
    local ok,err=pcall(function()
      complete=m.advance(g.motion,math.max(0,now-g.motion_started))
      local frames=m.frames(g.motion)
      c={q={0,0,0,1},p={unpack(g.motion.points.hips.p)}}
      for _,row in ipairs(rows)do
        local r=row.r;row.target={}
        for n,pose in pairs(r.motion_shape)do
          local out=m.deform(frames,r.motion_owners[n],pose)
          local q,p=relative_pose(c.q,c.p,out.q,out.p);assert(q and p,'invalid motion output')
          row.target[n]={q=q,p=p}
        end
      end
      for _,row in ipairs(rows)do rewrite_copy(world,row.u,row.r,row.target,c)end
    end)
    if ok then
      for _,row in ipairs(rows)do
        row.r.fixed_core=c;row.r.shape=row.target
        if complete then
          row.r.guard=nil;row.r.shape=nil;row.r.motion_shape=nil;row.r.motion_owners=nil;live_cache[row.r.original]=nil
        end
      end
      if complete then
        note('settled-'..g.owner,'frozen owner='..g.owner..' units='..#rows..' pose=articulated-fall fixed_world=true support=last-live-feet-approx steps='..g.motion.steps..' original_graph_untouched=true')
      end
    else
      for _,row in ipairs(rows)do
        local r=row.r
        if not pcall(rewrite_copy,world,row.u,r,r.shape,r.fixed_core)then r.quarantine=true end
        r.guard=nil;r.shape=nil;r.motion_shape=nil;r.motion_owners=nil;live_cache[r.original]=nil
      end
      F.report('motion-write',err)
    end
  end
  local function finish_guard(world,g,live,c)
    if not g.motion and now<g.until_time then return end
    local rows={}
    for _,key in ipairs(g.keys)do
      local r=frozen[key]
      if not r or r.quarantine or not live[r.clone] or not live[key] then return end
      local copy,original=live[r.clone],live[key]
      if not eligible(original) or original.profile.hash~=r.hash or copy.profile.hash~=r.hash or
         U.alive(copy.unit)~=true or U.alive(original.unit)~=true or
         U.num_scene_graph_items(copy.unit)~=r.count or U.num_scene_graph_items(original.unit)~=r.count then return end
      rows[#rows+1]={r=r,u=copy.unit}
    end
    if g.motion then return update_motion(world,g,rows)end
    local ok,err=pcall(function()
      local tilt=not g.settled and fallen_rotation(c,g.up) or nil
      for _,row in ipairs(rows)do
        local r=row.r
        if g.settled then row.target=g.settled[r.original]
        else
          row.target={}
          for n,p in pairs(r.shape)do row.target[n]={q=qmul(tilt,p.q),p=qrotate(tilt,p.p)}end
        end
      end
      for _,row in ipairs(rows)do rewrite_copy(world,row.u,row.r,row.target,c)end
    end)
    if ok then
      for _,row in ipairs(rows)do row.r.guard=nil;row.r.shape=nil;live_cache[row.r.original]=nil end
      note('settled-'..g.owner,'frozen owner='..g.owner..' units='..#rows..' pose='..
        (g.settled and 'intact-dead' or 'rigid-fallen-fallback')..' original_graph_untouched=true')
    else
      for _,row in ipairs(rows)do
        if not pcall(rewrite_copy,world,row.u,row.r,row.r.shape,c)then row.r.quarantine=true end
        row.r.guard=nil;row.r.shape=nil;live_cache[row.r.original]=nil
      end
      -- Keep the intact display when finalization fails; do not retry bulk
      -- writes every frame or expose partially written copies.
      g.until_time=math.huge;F.report('settle',err)
    end
  end
  function F.flush(bindings)
    local ready=pending;pending={}
    if not F.enabled then return end
    local ok,missing=available()
    if not ok then note('api','unavailable='..missing..'; original display retained');return end
    local groups={}
    for _,b in ipairs(bindings)do
      local r=frozen[slot(b.unit)]
      if eligible(b) and b.instance_id and not failed[slot(b.avatar.unit)] and (not r or r.guard) and not clones[slot(b.unit)] then
        local owner=slot(b.avatar.unit)
        local g=groups[owner] or {};groups[owner]=g;g[#g+1]=slot(b.unit)
      end
    end
    for owner,keys in pairs(groups)do
      -- Publish living cache as one same-frame group. A failed/newer part must
      -- not overwrite the last complete group with incompatible sample buckets.
      local complete_live=true
      for _,key in ipairs(keys)do if not live_pending[key] then complete_live=false;break end end
      if complete_live then for _,key in ipairs(keys)do live_cache[key]=live_pending[key]end end
      local guard=frozen[keys[1]] and frozen[keys[1]].guard
      if guard then
        local shapes,c={},nil
        local complete=#keys==#guard.keys
        for _,key in ipairs(guard.keys)do
          local item=ready[key]
          if not item or item.early or item.cache_only then complete=false;break end
          c=item.core
          local ok,shape=pcall(capture,item.binding.unit,item.binding.node_count,item.offset,c,item.explicit)
          if not ok or not shape then complete=false;break end
          shapes[key]=shape
        end
        -- Prefer a complete genuinely reclining corpse, never the first dying
        -- standing/aiming frame. Otherwise finalization uses the intact fallback.
        if complete and c and c.up and now<guard.until_time then
          local axis=qrotate(c.q,c.up)
          if math.abs(axis[3])<.7 then guard.settled=shapes end
        end
      else
      local prepared,reason,age={},nil,nil
      local early,use_cache=false,false
      for _,key in ipairs(keys)do
        local item=ready[key]
        if not item then reason='incomplete corrected group';break end
        age=identity().dead_age and identity().dead_age(item.binding.avatar.unit) or nil
        if not age then reason='no confirmed death clock';break end
        early=early or item.early;use_cache=use_cache or item.early or item.cache_only or false
      end
      if not reason and (age>=4 or use_cache) then
        if created+#keys>256 then reason='copy lifetime limit' end
        if not reason then for _,key in ipairs(keys)do
          local success,r=pcall(prepare,ready[key],use_cache)
          if not success then reason=tostring(r);break end
          prepared[#prepared+1]=r
        end end
        local bucket
        if not reason and use_cache then for _,r in ipairs(prepared)do
          local cached=live_cache[r.key]
          if not cached or cached.owner~=owner or cached.world~=r.world_slot or cached.hash~=r.hash or
              cached.count~=r.count or cached.offset~=r.offset or now-cached.time>30 or
              (bucket and cached.bucket~=bucket) then reason='no complete intact group cache';break end
          if not cached.up then reason='no intact body axis';break end
          bucket=cached.bucket;r.shape=cached.shape;r.up=cached.up;r.cached=cached
        end end
        if not reason then
          local protection=use_cache and {until_time=now+math.max(0,4-age),up=prepared[1].up,owner=owner,keys=keys} or nil
          if protection then
            local ok,err=pcall(start_motion,prepared,protection,age)
            if not ok then note('motion-unavailable-'..owner,'articulated unavailable owner='..owner..' reason='..tostring(err))end
          end
          for _,r in ipairs(prepared)do r.guard=protection end
          local committed,err=pcall(function()
            for _,r in ipairs(prepared)do apply(r)end
            for _,r in ipairs(prepared)do
              assert(tonumber(native_api.freeze_corpse_physics(r.profile_id,r.instance_id,r.avatar_id))==1,'corpse physics retirement rejected')
            end
            for _,r in ipairs(prepared)do U.set_unit_visibility(r.clone,true)end
            for _,r in ipairs(prepared)do r.hidden=true;U.set_unit_visibility(r.unit,false)end
          end)
          if committed then
            for _,r in ipairs(prepared)do frozen[r.key]=register_clone(r);if not protection then live_cache[r.key]=nil end end
            note('frozen-'..owner,(protection and 'protected' or 'frozen')..' owner='..owner..' units='..#prepared..' delay='..string.format('%.3f',age)..
              ' intact_cache='..tostring(use_cache)..' declared_gender=true original_graph_untouched=true')
          else
            failed[owner]=true -- One failed spawn transaction per corpse, not per render frame.
            local restored=true
            for _,r in ipairs(prepared)do
              if r.hidden and not pcall(U.set_unit_visibility,r.unit,true)then restored=false end
              if r.clone then
                pcall(U.set_unit_visibility,r.clone,false)
                if not pcall(W.destroy_unit,r.world,r.clone)then
                  -- Only our new copy can be quarantined/deleted. Keep it out
                  -- of ordinary discovery even after a cleanup API failure.
                  local record=register_clone(r);record.quarantine=true
                end
              end
            end
            note('failed-'..owner,'copy group failed owner='..owner..' display_restored='..tostring(restored)..' error='..tostring(err))
          end
        end
      end
      if reason and age and age>=4 then note('skip-'..owner..'-'..reason,'skipped owner='..owner..' reason='..reason)end
      end
    end
  end
  function F.filter(world,avatars,armour)
    if next(clones)==nil then return armour end
    -- discover_armour_units already freshly queries every profile resource on
    -- every callback. Do not retain its handles or dereference old identity keys.
    local wid=slot(world)
    local owners,live,skip={},{},{}
    for _,a in ipairs(avatars)do owners[slot(a.unit)]=a end
    for _,item in ipairs(armour)do live[slot(item.unit)]=item end
    local finished={}
    for _,r in pairs(clones)do
      local g=r.guard
      if r.world==wid and g and not finished[g] and owners[r.owner] then
        finished[g]=true
        local ok,err=pcall(function()
          local c=core(owners[r.owner]);if c then finish_guard(world,g,live,c)end
        end)
        if not ok then F.report('guard',err)end
      end
    end
    for key,r in pairs(clones)do if r.world==wid then
      local copy_item,original=live[key],live[r.original]
      skip[key]=true
      local valid=false
      if not r.quarantine and copy_item and original and eligible(original) and original.profile.hash==r.hash and owners[r.owner] then
        local ok,err=pcall(function()
          local u=copy_item.unit
          assert(U.alive(u)==true and U.num_scene_graph_items(u)==r.count,'copy lifecycle changed')
          local c=r.fixed_core or assert(core(owners[r.owner]),'core unavailable')
          -- Two setters per display Unit; never update a limb pose again.
          set(u,r.root,c);W.update_unit(world,u)
          local q,p=world_pose(u,r.root);assert(close(q,p,c.q,c.p),'core following failed')
          U.set_unit_visibility(u,true)
          U.set_unit_visibility(original.unit,false)
        end)
        valid=ok
        if not ok then note('follow-'..key,'copy follow failed '..tostring(err))end
      end
      if valid then skip[r.original]=not r.guard or r.guard.motion~=nil
      else
        if copy_item then pcall(U.set_unit_visibility,copy_item.unit,false)end
        if original then pcall(U.set_unit_visibility,original.unit,true)end
      end
    end end
    local result={}
    for _,item in ipairs(armour)do if not skip[slot(item.unit)] then result[#result+1]=item end end
    return result
  end
  return F
end)())

  -- Source-bound local TP locomotion. Histories contain scalars only, never a
-- cached Unit/World used for a native query. Frame loss invalidates the history.
rawset(_G,"__hd2ir_gait_control",(function()
  local catalog=rawget(_G,"__hd2ir_tp_gait_catalog")
  local histories={}
  local function finite(n)return type(n)=="number" and n==n and math.abs(n)<math.huge end
  local function fade(n,a,b)local t=math.max(0,math.min(1,(n-a)/(b-a)));return t*t*(3-2*t)end
  local function map(values)local out={};for _,v in ipairs(values or {})do out[v]=true end;return out end
  local cycles=map(catalog and catalog.cycle_states)
  local exits=map(catalog and catalog.exit_states)
  local main=map(catalog and catalog.safe_main_states)
  local menus=map(catalog and catalog.menu_states)
  local ship_cycles=map(catalog and catalog.ship_cycle_states)
  local ship_empty=map(catalog and catalog.ship_empty_upper_states)
  local function sample(item,current_frame,now,api)
    if type(item)~="table" or not finite(current_frame) or not finite(now) then return 0,"input" end
    local slot=item.instance_slot
    if not finite(slot) or slot<=0 then return 0,"identity" end
    local world_slot=rawget(_G,"__hd2ir_unit_instance_slot")(item.world)
    local key=tostring(world_slot)..":"..tostring(slot)
    local function stop(reason)histories[key]=nil;return 0,reason end
    if not catalog then return stop("source-unverified") end
    if not api or not api.gait_correction_enabled or tonumber(api.gait_correction_enabled())~=1 then return stop("off") end
    if rawget(_G,"__hd2ir_carrier_fp_hold")==true or item.camera_nearest~=true or item.world_overlapping then return stop("view") end
    if rawget(_G,"__hd2ir_physics_identity").role(item.unit)~=1 then return stop("not-self") end
    if not rawget(_G,"__hd2ir_animation_ready")(item.unit) then return stop("animation-unavailable") end
    local q=item.root_q
    if type(q)~="table" then return stop("root") end
    local norm=0
    for i=1,4 do if not finite(q[i]) then return stop("root") end;norm=norm+q[i]*q[i] end
    if math.abs(norm-1)>.01 then return stop("root") end
    local tuple={pcall(function()return U.animation_get_state(item.unit)end)}
    if not tuple[1] or #tuple~=catalog.layer_count+1 then return stop("state") end
    for i=2,#tuple do
      local value=tonumber(tuple[i])
      if not finite(value) or value<0 or value~=math.floor(value) then return stop("state") end
      tuple[i]=value
    end
    local base=tuple[2]
    local upper,main_state=tuple[catalog.menu_layer+1],tuple[catalog.main_layer+1]
    -- Ship base 1/2 is a full-body locomotion tree. Its upper states 76/77
    -- contain no animation: the contact system's menu label must not silence
    -- the legs. Keep a narrow source-bound exception, with empty main action
    -- and the same live speed/direction, identity and transition guards below.
    local ship=ship_cycles[base] and ship_empty[upper] and main_state==catalog.ship_main_empty
    if (menus[upper] and not ship) or not main[main_state] then return stop("override") end
    if not cycles[base] and not exits[base] then return stop("non-standing") end
    local target=0
    if cycles[base] then
      local ok,speed,angle=pcall(function()
        local function variable(name)
          if not U.animation_has_variable(item.unit,name) then return nil end
          return tonumber(U.animation_get_variable(item.unit,U.animation_find_variable(item.unit,name)))
        end
        return variable(catalog.speed_variable),variable(catalog.angle_variable)
      end)
      if not ok or not finite(speed) or not finite(angle) or speed<0 or speed>30 or math.abs(angle)>360 then return stop("variable") end
      angle=(angle+180)%360-180
      target=fade(speed,.25,1)*(1-fade(math.abs(angle),35,70))
    end
    local previous=histories[key]
    if previous and previous.frame==current_frame then return previous.weight,"same-frame" end
    local dt=previous and now-previous.time or 0
    if previous and (current_frame~=previous.frame+1 or dt<=0 or dt>.2) then previous=nil;dt=0 end
    if previous and dt>0 then
      local cosine=math.abs(q[1]*previous.q1+q[2]*previous.q2+q[3]*previous.q3+q[4]*previous.q4)
      local angular_speed=2*math.acos(math.min(1,cosine))*180/math.pi/dt
      target=target*(1-fade(angular_speed,120,300))
    end
    local weight=previous and previous.weight or 0
    -- Bounded rates use wall-frame time, not the number/order of body parts.
    -- A new object or a missing frame starts neutral instead of inheriting gait.
    local delta=target-weight
    weight=weight+math.max(-dt/.14,math.min(dt/.18,delta))
    weight=math.max(0,math.min(1,weight))
    local count=0
    for k,v in pairs(histories)do
      if current_frame-v.frame>2 or current_frame<v.frame then histories[k]=nil else count=count+1 end
    end
    if not histories[key] and count>=64 then return stop("history-limit") end
    histories[key]={frame=current_frame,time=now,weight=weight,q1=q[1],q2=q[2],q3=q[3],q4=q[4]}
    return weight,cycles[base] and "cycle" or "exit"
  end
  return {sample=sample}
end)())

  -- Synchronous frame-local collection. Coroutines never leave this callback;
-- the native queue owns numeric copies, not game handles or Lua pointers.
rawset(_G,"__hd2ir_pose_batch",(function()
  local M={}
  local backend, installed, collecting = nil,nil,false
  local owners={}
  local prepared_marker,written_marker={},{}
  -- These barriers stay inside one synchronous callback. Only shared body
  -- consumers of the same Avatar participate; helmets/other actors do not.
  function M.scene_ready(undo)
    local owner=owners[coroutine.running()]
    if not owner or not owner.group then return true end
    owner.undo=undo
    local accepted=coroutine.yield(prepared_marker)==true
    -- Only this live shared transaction guarantees a complete post-group
    -- readback before publication. Ordinary/standalone consumers receive no
    -- second result and must keep their immediate verification.
    return accepted,accepted
  end
  function M.scene_written(verify)
    local owner=owners[coroutine.running()]
    if not owner or not owner.group then return true end
    owner.verify=verify
    return coroutine.yield(written_marker)==true
  end
  -- Each suspended invocation retains its own original arguments on its Lua
  -- stack. No argument table/unpack or shared output scratch crosses a yield.
  local function queued(original,instance,count,animation,action,mask,contacts,single,capacity,...)
    if not collecting or not owners[coroutine.running()] then return original(...) end
    local job=tonumber(backend.submit(instance,count,animation,action,mask,contacts,single,capacity)) or 0
    if job==0 then return 0 end
    local ready=coroutine.yield(job)
    if not ready then return 0 end
    if tonumber(backend.select(job))~=1 then return 0 end
    local ok,result=pcall(original,...)
    backend.select(0)
    if not ok then error(result,0) end
    return result
  end
  function M.install(api,fn)
    if installed==api then return true end
    local b={begin=fn("hd2ir_pose_batch_begin","unsigned (*)(unsigned)"),
      submit=fn("hd2ir_pose_batch_submit","unsigned (*)(unsigned long long,unsigned,const float *,unsigned,unsigned,const float *,unsigned,unsigned)"),
      execute=fn("hd2ir_pose_batch_execute","unsigned (*)(void)"),
      select=fn("hd2ir_pose_batch_select","unsigned (*)(unsigned)"),
      finish=fn("hd2ir_pose_batch_end","unsigned (*)(void)")}
    if not(b.begin and b.submit and b.execute and b.select and b.finish) then
      backend,installed=nil,nil;return false
    end
    backend,installed=b,api
    local bound=api.retarget_bound
    api.retarget_bound=function(id,cap,nodes,model)
      return queued(bound,id,0,nil,0,0,nil,0,cap,id,cap,nodes,model)
    end
    if api.retarget_unit_pose then
      local pose=api.retarget_unit_pose
      api.retarget_unit_pose=function(id,count,anim,cap,nodes,model)
        return queued(pose,id,count,anim,0,0,nil,0,cap,id,count,anim,cap,nodes,model)
      end
    end
    if api.retarget_unit_pose_action then
      local action=api.retarget_unit_pose_action
      api.retarget_unit_pose_action=function(id,count,anim,a,cap,nodes,model)
        return queued(action,id,count,anim,a,0,nil,0,cap,id,count,anim,a,cap,nodes,model)
      end
    end
    for _,key in ipairs({"retarget_unit_pose_contacts","retarget_unit_pose_singlehand"}) do
      local original=api[key]
      if original then
        local single=key=="retarget_unit_pose_singlehand" and 1 or 0
        api[key]=function(id,count,anim,a,mask,contacts,cap,nodes,model)
          return queued(original,id,count,anim,a,mask,contacts,single,cap,
            id,count,anim,a,mask,contacts,cap,nodes,model)
        end
      end
    end
    return true
  end
  local function shared_body(binding)
    return installed and installed.shared_body_profile and binding.avatar and binding.profile and
      binding.profile.active and not binding.profile.observe_only and
      (not binding.pose_only or binding.presentation_bound==true) and
      tonumber(installed.shared_body_profile(binding.profile.id))==1
  end
  local function display_binding(binding)
    return binding.pose_only==true and binding.preview_audit==true and not binding.preview_update and
      binding.avatar and not binding.avatar.presentation_kind and
      type(binding.presentation_world)=='number' and binding.presentation_world>0 and
      binding.presentation_world==math.floor(binding.presentation_world)
  end
  function M.route_presentations(bindings,presentations,worlds)
    if not(installed and installed.retarget_presentation_instance) or type(worlds)~='table' then return end
    -- World admission is freshly proven by physics_identity. Do not promote
    -- NPCs, FP or network actors, or keep a lease when that proof disappears.
    -- A uniquely owned display and a pose-consensus display of the SAME Unit
    -- must use the same render-instance physics history across both routes.
    for i=#bindings,1,-1 do
      local b=bindings[i]
      local world=worlds[b.world]
      if type(world)=='number' and world>0 and world==math.floor(world) and
          b.profile and b.profile.authored and b.profile.active and not b.profile.observe_only and
          b.avatar and not b.avatar.presentation_kind and not b.preview_update and not b.pose_only then
        b.pose_only=true;b.preview_audit=true;b.presentation_world=world;b.presentation_bound=true
        table.remove(bindings,i);presentations[#presentations+1]=b
      end
    end
    table.sort(presentations,function(a,b)
      return rawget(_G,'__hd2ir_unit_instance_slot')(a.unit)<rawget(_G,'__hd2ir_unit_instance_slot')(b.unit)
    end)
  end
  local function run(bindings,drive,display_only)
    -- Backend decides whether even zero/one binding needs a committed frame.
    -- Shared physics must not bypass collection merely because a part vanished.
    if not display_only and (not backend or tonumber(backend.begin(#bindings))~=1) then
      -- A refused shared batch is not permission to fall back to independent
      -- body writes. Legacy/non-shared consumers keep their existing path.
      for i=1,#bindings do
        if not shared_body(bindings[i]) then drive(bindings[i].world,bindings[i]) end
      end
      return
    end
    local pending,groups,scene,verified={},{},{},{}
    local first_error=nil
    local function fail(owner,message)
      if owner and owner.group then owner.group.failed=true end
      if message then first_error=first_error or message end
    end
    local function resume(co,ready,expected,next_phase)
      local owner=owners[co]
      local resumed,value=coroutine.resume(co,ready)
      if not resumed then fail(owner,value)
      elseif coroutine.status(co)=="suspended" then
        if value==expected then next_phase[#next_phase+1]=co
        else fail(owner,"unexpected scene batch yield") end
      elseif value~=true then fail(owner) end
    end
    local function rollback_failed()
      for i=#scene,1,-1 do
        local owner=owners[scene[i]]
        if owner.applied and owner.group.failed and not owner.rollback_attempted then
          owner.rollback_attempted=true
          local restored,result=pcall(owner.undo)
          owner.rolled_back=restored and result==true
          if not owner.rolled_back then owner.group.recovery_needed=true end
          if not restored then first_error=first_error or result end
        end
      end
      -- Inverse updates can invalidate an earlier inverse readback too. The
      -- driver's 'verify' mode is read-only; 'defer' copies numbers only. Keep
      -- EVERY prepared member as a watch if any member cannot be restored,
      -- including siblings that had not reached their first scene write.
      for i=1,#scene do
        local owner=owners[scene[i]]
        if owner.group.failed then
          local ok,result=pcall(owner.undo,'verify')
          if not ok or result~=true then owner.group.recovery_needed=true end
        end
      end
      for i=1,#scene do
        local owner=owners[scene[i]]
        if owner.group.recovery_needed then
          local ok,result=pcall(owner.undo,'defer')
          if not ok then first_error=first_error or result end
        end
      end
    end
    local ok,err=pcall(function()
      collecting=not display_only
      for i=1,#bindings do
        local binding=bindings[i]
        local co=coroutine.create(function() return drive(binding.world,binding) end)
        local owner={}
        if shared_body(binding) then
          local group=groups[binding.avatar]
          if not group then group={};groups[binding.avatar]=group end
          owner.group=group
        end
        owners[co]=owner
        local resumed,value=coroutine.resume(co)
        if not resumed then fail(owner,value)
        elseif coroutine.status(co)=="suspended" then
          if display_only then
            if value==prepared_marker then scene[#scene+1]=co
            else fail(owner,"unexpected display scene yield") end
          else pending[#pending+1]=co end
        elseif value~=true then fail(owner) end
      end
      collecting=false
      local ready=display_only or tonumber(backend.execute())==1
      for i=1,#pending do
        resume(pending[i],ready,prepared_marker,scene)
      end
      -- Every member has completed validation before the first scene write.
      -- A late setter/update/readback failure invalidates this Avatar only.
      for i=1,#scene do
        local co=scene[i];local owner=owners[co]
        owner.applied=not owner.group.failed
        resume(co,owner.applied,written_marker,verified)
      end
      -- A sibling's successful World.update_unit can invalidate an earlier
      -- readback. Inspect every member again after the last scene mutation,
      -- before any member publishes lifecycle/pose-cache success.
      for i=1,#verified do
        local owner=owners[verified[i]]
        if not owner.group.failed and owner.verify then
          local checked,result=pcall(owner.verify)
          if not checked then fail(owner,result)
          elseif result~=true then fail(owner) end
        end
      end
      rollback_failed()
      -- Lifecycle/pose-cache publication happens only after all shared writes
      -- and readbacks succeed. Failed assemblies never publish success;
      -- incomplete rollback keeps its numeric watch pending for a fresh retry.
      for i=1,#verified do
        local co=verified[i]
        resume(co,not owners[co].group.failed,nil,{})
      end
      -- An unexpected error in a post-write observer must not leave only
      -- part of this Avatar published. Never run a rollback closure twice.
      rollback_failed()
    end)
    if not ok then
      for _,group in pairs(groups) do group.failed=true end
      rollback_failed()
    end
    collecting=false;owners={}
    if not display_only then backend.finish() end
    if not ok then error(err,0) end
    if first_error then error(first_error,0) end
  end
  function M.run(bindings,drive)return run(bindings,drive,false)end
  function M.run_presentations(bindings,drive)
    local displays={}
    for _,b in ipairs(bindings)do
      if installed and installed.retarget_presentation_instance and display_binding(b) then
        displays[#displays+1]=b
      else drive(b.world,b) end -- legacy stateless FP/NPC/unknown path unchanged
    end
    -- Known same-Avatar BODY parts retain the existing prepare/write/readback/
    -- rollback barriers. Anonymous instances do not acquire an invented owner.
    if #displays>0 then return run(displays,drive,true)end
  end
  return M
end)())

  -- Candidate timing experiment: the first UI draw can consume native bones
  -- before the render feed's corrected pose. Re-prove only ambiguous small
  -- preview inputs after update; do NOT move the frame/physics/identity feed.
  do
    local running,errors,reported=false,0,{}
    rawset(_G,"__hd2ir_preview_update",function()
      -- First-open visual/GPU acceptance failed. Keep the experiment available
      -- for isolated tests, but do not run this extra pass in shipped candidates.
      if rawget(_G,"__hd2ir_preview_update_enabled")~=true or
          running or not C or not C.shared_body_profile or not C.retarget_presentation_pose or
          drive_mode~="retarget_test" or (rawget(_G,"__hd2ir_declared_profile_count") or 0)==0 then return end
      running=true
      local previous_reads=rawget(_G,"__hd2ir_source_reads")
      rawset(_G,"__hd2ir_source_reads",{})
      local ok,err=pcall(function()
        local contexts=active_avatar_worlds()
        if type(contexts)~="table" then return end
        local written=0
        for _,context in ipairs(contexts) do
          local n=context.unit_count
          if finite(n) and n==math.floor(n) and n>0 and n<=512 and
              #context.avatars>=2 and #context.avatars<=32 then
            local avatars={}
            for _,unit in ipairs(context.avatars) do
              local count=try(function()return U.num_scene_graph_items(unit)end)
              if finite(count) and count==math.floor(count) and count>1 and count<=256 then
                local q,p=world_pose(unit,1)
                if q and p then avatars[#avatars+1]={unit=unit,world=context.world,node_count=count,
                  root_q=q,p=p,camera_nearest=false,camera_distance=math.huge} end
              end
            end
            local overlap=false
            for a=1,#avatars do
              for b=a+1,#avatars do
                if perror(avatars[a].p,avatars[b].p)<=0.01 then overlap=true end
              end
            end
            if overlap then
              local armour=discover_armour_units(context.world,frame,n)
              local pool=rawget(_G,"__hd2ir_prepare_native_snapshots")(armour)
              for _,item in ipairs(armour) do
                local profile,native=item.profile,item.native_snapshot
                if native and profile.authored and profile.active and not profile.observe_only and
                    profile.hash~=CARRIER_RESOURCE_HASH and written<256 then
                  local candidates={}
                  for _,node in ipairs({1,0}) do
                    if node<item.node_count then
                      local q,p=world_pose(item.unit,node)
                      if q and p then
                        for i,avatar in ipairs(avatars) do
                          local dx,dy,dz=p[1]-avatar.p[1],p[2]-avatar.p[2],p[3]-avatar.p[3]
                          local d2=dx*dx+dy*dy+dz*dz
                          if not candidates[i] or d2<candidates[i].d2 then
                            candidates[i]={avatar=avatar,d2=d2,node=node,q=q,p=p}
                          end
                        end
                      end
                    end
                  end
                  local best,second=math.huge,math.huge
                  for _,candidate in pairs(candidates) do
                    if candidate.d2<best then second,best=best,candidate.d2
                    else second=math.min(second,candidate.d2) end
                  end
                  if best<9 and math.sqrt(second)-math.sqrt(best)<=BINDING_AMBIGUITY_MARGIN then
                    -- Fresh cache per Unit: a sparse root-probe set must never
                    -- poison another Unit's complete candidate input set.
                    local pose,reason=rawget(_G,"__hd2ir_presentation_context")(
                      candidates,native,{},profile,pool)
                    if pose then
                      local accepted=retarget_test_unit(context.world,{profile=profile,unit=item.unit,
                        node_count=item.node_count,avatar=pose,pose_only=true,preview_update=true,native_snapshot=native})
                      if accepted then
                        written=written+1
                        if candidate_trace and not reported[profile.hash] then
                          reported[profile.hash]=true
                          log("preview-update accepted unit="..profile.hash.." frame="..frame.." reason="..tostring(reason))
                        end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end)
      -- Only scalar counters survive. Even a disappearing World must release
      -- its current handles and pose cache before returning to the engine.
      rawset(_G,"__hd2ir_source_reads",previous_reads)
      running=false
      if not ok then
        errors=errors+1
        if errors<=3 or errors%600==0 then log("preview-update error #"..errors..": "..tostring(err)) end
      end
    end)
  end
  local frames_sent, avatars_sent, units_sent, rejected = 0, 0, 0, 0
  local hook_errors = 0
  local old_render = rawget(_G, "render")
  if type(old_render) ~= "function" then return end
  local old_update=rawget(_G,"update")
  if type(old_update)=="function" then
    rawset(_G,"update",function(...)
      rawget(_G,"__hd2ir_weapon_root_trial").restore_pending()
      local function pack(...)return {n=select("#",...),...}end
      local result=pack(old_update(...))
      if rawget(_G,"__hd2ir_preview_update_enabled")==true then rawget(_G,"__hd2ir_preview_update")() end
      return unpack(result,1,result.n)
    end)
    log("whole-weapon-trial pre-update restore hook installed")
  else
    log("whole-weapon-trial unavailable: no update hook; no shifted hands/gun")
  end
  -- The Avatar root is camera-zero only during the first ADS transition
  -- frames, then settles near 0.93 m while the player is still aiming. Keep a
  -- tiny scalar latch in the Lua VM rather than another captured local: this
  -- render closure is already at LuaJIT 5.1's 60-upvalue limit.
  rawset(_G, "__hd2ir_carrier_fp_hold", false)
  local function render_frame(...)
    if rawget(_G,"__hd2ir_weapon_root_trial").rendering then return old_render(...) end
    if rawget(_G,'__hd2ir_work_begin')then rawget(_G,'__hd2ir_work_begin')()end
    rawget(_G,"__hd2ir_weapon_root_trial").restore_pending()
    frame = frame + 1
    if rawget(_G,'__hd2ir_topology_begin')then rawget(_G,'__hd2ir_topology_begin')(frame)end
    -- Production gait smoothing needs one timestamp shared by this frame's
    -- Avatars. Keep it independent of optional performance diagnostics.
    local gait_sample_time = os.clock()
    if rawget(_G,"__hd2ir_preview_delivery") then rawget(_G,"__hd2ir_preview_delivery").begin() end
    rawget(_G,'__hd2ir_corpse_freeze').begin(C,frame)
    rawget(_G,"__hd2ir_weapon_root_trial").begin()
    rawset(_G,"__hd2ir_source_reads",{})
    local handoff_feed_complete=false
    local hook_ok, hook_error = pcall(function()
      if rawget(_G,'__hd2ir_native_handoff') and not rawget(_G,'__hd2ir_native_handoff').begin() then return end
      if not load_bridge(frame) then return end
      refresh_drive_mode(frame)
      if (rawget(_G,"__hd2ir_declared_profile_count") or 0)==0 and not rawget(_G,"__hd2ir_native_handoff") then return end
      local contexts = active_avatar_worlds()
      if type(contexts) ~= "table" or #contexts == 0 then
        update_lifecycle_gap()
        return
      end

      -- A package with no declared Mod profiles still observes fresh roots,
      -- publishes readiness and commits an explicit empty addon frame. No
      -- Avatar pose, profile target or synthetic local binding is required.
      if (rawget(_G,'__hd2ir_declared_profile_count') or 0)==0 then
        local gate=rawget(_G,'__hd2ir_native_handoff')
        if not gate then return end
        gate.filter({});gate.filter({})
        if tonumber(C.begin_frame(frame))~=1 then return end
        if tonumber(C.end_frame(frame))~=1 then return end
        rawget(_G,'__hd2ir_pose_batch').run({},retarget_test_unit)
        rawget(_G,'__hd2ir_pose_batch').run_presentations({},retarget_test_unit)
        handoff_feed_complete=true
        return
      end

      -- ADS keeps a second third-person World alive. Detect first person before
      -- processing either World, otherwise the non-camera World can restore a
      -- carrier after the camera World hid its copy. This is deliberately a
      -- cheap root-only pre-pass; full skeleton reads still happen only for
      -- bound Avatars below. Real samples put the local root at camera distance
      -- 0.000 m, while ordinary third person remains outside the 0.35 m gate.
      local suppress_all_carriers =
        rawget(_G, "__hd2ir_carrier_fp_hold") == true
      local first_person_transition = false
      local nearest_probe_d2 = math.huge
      -- The two read-only root passes share successful numeric snapshots only
      -- within this render callback. Context keys keep mirror Worlds separate;
      -- failed/unvisited probes are read normally below, never cached as absent.
      local avatar_root_reads = {}
      for ci = 1, #contexts do
        local probe_context = contexts[ci]
        local probe_camera = camera_position(probe_context.world)
        if probe_camera ~= nil then
          local roots = {}
          avatar_root_reads[probe_context] = roots
          for ai = 1, #probe_context.avatars do
            local probe_avatar = probe_context.avatars[ai]
            local probe_nodes = try(function()
              return U.num_scene_graph_items(probe_avatar)
            end)
            if type(probe_nodes) == "number" and probe_nodes > 1 then
              local probe_q, probe_root = world_pose(probe_avatar, 1)
              if probe_root ~= nil then
                if probe_q ~= nil then
                  roots[probe_avatar] = {node_count=probe_nodes,q=probe_q,p=probe_root}
                end
                local dx = probe_root[1] - probe_camera[1]
                local dy = probe_root[2] - probe_camera[2]
                local dz = probe_root[3] - probe_camera[3]
                local probe_d2 = dx * dx + dy * dy + dz * dz
                if probe_d2 < nearest_probe_d2 then
                  nearest_probe_d2 = probe_d2
                end
                -- 0.1225 == 0.35^2. Keep the squared threshold literal here:
                -- capturing one more outer local would exceed LuaJIT 5.1's
                -- hard 60-upvalue limit for this already large render hook.
                if probe_d2 <= 0.1225 then
                  first_person_transition = true
                  break
                end
              end
            end
          end
        end
        if first_person_transition then break end
      end
      if first_person_transition then
        if not suppress_all_carriers then
          log("first-person carrier hold entered at camera-zero transition")
        end
        suppress_all_carriers = true
      elseif suppress_all_carriers and #contexts == 1 and
             nearest_probe_d2 > 1.0 then
        -- First-person samples stay at <=0.93 m after the transition. Release
        -- only after the mirror World has gone and the remaining camera/root
        -- separation is unambiguously back above one metre.
        suppress_all_carriers = false
        log(string.format(
          "first-person carrier hold released worlds=1 distance=%.3f",
          math.sqrt(nearest_probe_d2)))
      end
      rawset(_G, "__hd2ir_carrier_fp_hold", suppress_all_carriers)

      -- First read only avatar roots. Full 256-bone poses are collected later
      -- only for avatars that actually own a configured armour Unit. This
      -- keeps teammates correct without paying the full cost for old corpses.
      -- Process every Avatar-bearing World in one C++ frame: equipment/body
      -- previews and Hellpod staging use presentation Worlds separate from the
      -- ship or mission World, so choosing only the World with most Avatars
      -- left the visible preview at the original body shape.
      local avatars, bindings, ambiguous_bindings = {}, {}, 0
      local presentation_bindings={}
      for ci = 1, #contexts do
        local context = contexts[ci]
        local world, avatar_units = context.world, context.avatars
        local context_avatars = {}
        local presentation_cache={}
        local camera_p = camera_position(world)
        local nearest_camera_index, nearest_camera_d2 = nil, math.huge
        for i = 1, #avatar_units do
          local avatar = avatar_units[i]
          local roots = avatar_root_reads[context]
          local sampled = roots and roots[avatar]
          local node_count = sampled and sampled.node_count or
            try(function() return U.num_scene_graph_items(avatar) end)
          if type(node_count) == "number" and node_count > 1 then
            local root_q, root_p
            if sampled then root_q,root_p=sampled.q,sampled.p
            else root_q,root_p=world_pose(avatar,1) end
            if root_q ~= nil and root_p ~= nil then
              local item = {
                world = world, unit = avatar, node_count = node_count,
                root_q = root_q, p = root_p, needed = false,
                camera_nearest = false, camera_distance = math.huge,
              }
              if camera_p ~= nil then
                local dx = root_p[1] - camera_p[1]
                local dy = root_p[2] - camera_p[2]
                local dz = root_p[3] - camera_p[3]
                local d2 = dx * dx + dy * dy + dz * dz
                item.camera_distance = math.sqrt(d2)
                if d2 < nearest_camera_d2 then
                  nearest_camera_index = #context_avatars + 1
                  nearest_camera_d2 = d2
                end
              end
              context_avatars[#context_avatars + 1] = item
              avatars[#avatars + 1] = item
            end
          end
        end
        if nearest_camera_index ~= nil then
          context_avatars[nearest_camera_index].camera_nearest = true
        end
        -- Keep this calculation local to the already-large render callback;
        -- capturing another helper would cross LuaJIT 5.1's 60-upvalue cap.
        local context_overlapping = false
        for ai = 1, #context_avatars do
          for bi = ai + 1, #context_avatars do
            local a, b = context_avatars[ai].p, context_avatars[bi].p
            local dx, dy, dz = a[1] - b[1], a[2] - b[2], a[3] - b[3]
            if dx * dx + dy * dy + dz * dz <= 0.0001 then
              context_overlapping = true
            end
          end
        end
        for i = 1, #context_avatars do
          context_avatars[i].world_overlapping = context_overlapping
        end
        local avatar_slots={}
        for _,a in ipairs(context_avatars)do avatar_slots[#avatar_slots+1]=rawget(_G,'__hd2ir_unit_instance_slot')(a.unit)end
        table.sort(avatar_slots)
        -- A cached role is only a scan-budget hint, never a write/owner proof.
        -- Units themselves came from this callback's fresh Avatar enumeration.
        local gameplay_world=false
        local scan_identity=rawget(_G,'__hd2ir_physics_identity')
        if #(context.scene_sources or {})==0 and scan_identity and type(scan_identity.role)=='function' then
          for _,a in ipairs(context_avatars)do
            local role=scan_identity.role(a.unit)
            if role==1 or role==2 then gameplay_world=true;break end
          end
        end
        local armour_units = discover_armour_units(world, frame, context.unit_count,table.concat(avatar_slots,':'),gameplay_world)
        if rawget(_G,'__hd2ir_corpse_freeze_active')==true then
          armour_units=rawget(_G,'__hd2ir_corpse_freeze').filter(world,context_avatars,armour_units)
        end
        local native_pool=rawget(_G,"__hd2ir_prepare_native_snapshots")(armour_units)
        local presentation_owned={}
        rawget(_G,"__hd2ir_collect_nonplayer_presentations")(world,context.scene_sources or {},armour_units,presentation_bindings,presentation_owned)
        rawget(_G,"__hd2ir_collect_first_person_presentations")(world,context_avatars,armour_units,presentation_bindings,presentation_owned)
        if #context_avatars > 0 then
          -- Marker Units stay read-only. They select which shared body
          -- Profile belongs to this concrete Avatar instance.
          update_armour_identities(world, context_avatars,
                                   suppress_all_carriers)
          for i = 1, #armour_units do
            local armour = armour_units[i]
            local matched = armour.profile
            local unit = armour.unit
            local node_count = armour.node_count or try(function() return U.num_scene_graph_items(unit) end)
            if not presentation_owned[unit] and type(node_count) == "number" and node_count > 1 then
              -- First select the best root probe independently for each
              -- Avatar in THIS World. Only then compare different Avatars.
              local candidates = {}
              local root_probes = matched.observe_only and
                                  matched.anchor_nodes or {1, 0}
              if #root_probes == 0 then root_probes = {1, 0} end
              for _, node in ipairs(root_probes) do
                if node < node_count then
                  local q, p = world_pose(unit, node)
                  if q ~= nil and p ~= nil then
                    for ai = 1, #context_avatars do
                      local ap = context_avatars[ai].p
                      local dx = p[1] - ap[1]
                      local dy = p[2] - ap[2]
                      local dz = p[3] - ap[3]
                      local d2 = dx * dx + dy * dy + dz * dz
                      local candidate = candidates[ai]
                      if candidate == nil or d2 < candidate.d2 then
                        candidates[ai] = {
                          avatar = context_avatars[ai], d2 = d2,
                          node = node, q = q, p = p,
                        }
                      end
                    end
                  end
                end
              end
              -- The retarget binding below intentionally filters by the
              -- required armour family. Visibility restoration cannot use
              -- that filtered set: when the user switches from EX-16 back to
              -- EX-03, the same shared resource must become visible again.
              -- Resolve a separate unfiltered, marker-proven owner first.
              local visibility_best, visibility_second = nil, nil
              for ai = 1, #context_avatars do
                local candidate = candidates[ai]
                local family = candidate and
                               candidate.avatar.armour_family or nil
                if candidate ~= nil and
                   (family == "ex03" or family == "ex16") then
                  if visibility_best == nil or
                     candidate.d2 < visibility_best.d2 then
                    visibility_second, visibility_best =
                      visibility_best, candidate
                  elseif visibility_second == nil or
                         candidate.d2 < visibility_second.d2 then
                    visibility_second = candidate
                  end
                end
              end
              if visibility_best ~= nil and visibility_best.d2 < 9.0 then
                local visibility_distance = math.sqrt(visibility_best.d2)
                local visibility_second_distance =
                  visibility_second ~= nil and
                  math.sqrt(visibility_second.d2) or math.huge
                if visibility_second_distance - visibility_distance >
                   BINDING_AMBIGUITY_MARGIN then
                  apply_visibility_probe(world, unit, matched,
                                         visibility_best.avatar)
                end
              end

              local best, second = nil, nil
              local required_family = PROFILE_REQUIRED_ARMOUR[matched.hash]
              if matched.authored then required_family = nil end
              -- A carrier assigned earlier in this same callback has an
              -- explicit scalar lease. Prefer that owner even when another
              -- Avatar or corpse is physically closer to the carrier root.
              local leased_candidate = nil
              local unit_key = unit
              for ai = 1, #context_avatars do
                local avatar = context_avatars[ai]
                if avatar.carrier_units ~= nil and
                   avatar.carrier_units[unit_key] then
                  leased_candidate = candidates[ai]
                  break
                end
              end
              if leased_candidate ~= nil then
                best = leased_candidate
              else
                for ai = 1, #context_avatars do
                  local candidate = candidates[ai]
                  if candidate ~= nil and
                     (required_family == nil or
                      candidate.avatar.armour_family == required_family) then
                    if best == nil or candidate.d2 < best.d2 then
                      second, best = best, candidate
                    elseif second == nil or candidate.d2 < second.d2 then
                      second = candidate
                    end
                  end
                end
              end
              -- Armour components should be within three metres of the
              -- avatar/corpse they belong to. A farther match fails closed.
              if best ~= nil and best.d2 < 9.0 and #bindings < 256 then
                local best_distance = math.sqrt(best.d2)
                local second_distance = second ~= nil and
                                        math.sqrt(second.d2) or math.huge
                local pose_owner_proven,presentation_native = false,nil
                if matched.authored then
                  local refined,native = rawget(_G, "__hd2ir_refine_authored_owner")(
                    matched, unit, node_count, candidates,armour.native_snapshot)
                  if refined ~= nil then best, pose_owner_proven = refined, true end
                  presentation_native=native
                end
                local binding_gate = first_person_binding_allowed(
                  matched, best.avatar, world, unit,
                  suppress_all_carriers)
                if (matched.authored and not pose_owner_proven) or
                   (second_distance-best_distance<=BINDING_AMBIGUITY_MARGIN and binding_gate~="stable" and not pose_owner_proven) then
                  if matched.authored and C.retarget_presentation_pose~=nil and presentation_native and
                      #presentation_bindings+#bindings<256 then
                    local pose_context,reason=rawget(_G,"__hd2ir_presentation_context")(
                      candidates,presentation_native,presentation_cache,matched,native_pool)
                    if pose_context then
                      presentation_bindings[#presentation_bindings+1]={world=world,profile=matched,
                        avatar=pose_context,unit=unit,node_count=node_count,pose_only=true,preview_audit=true,native_snapshot=presentation_native}
                    end
                    local key="presentation|"..matched.hash.."|"..tostring(reason)
                    if not ambiguity_probe_logged[key] then
                      ambiguity_probe_logged[key]=true
                      log("authored presentation-only "..matched.hash.." accepted="..tostring(pose_context~=nil).." reason="..tostring(reason))
                    end
                  end
                  ambiguous_bindings = ambiguous_bindings + 1
                  lifecycle_ambiguous_total = lifecycle_ambiguous_total + 1
                  local probe_key = string.format("%d|%s|%s|%d",
                    lifecycle_generation, tostring(world), matched.hash,
                    #context_avatars)
                  if not ambiguity_probe_logged[probe_key] and
                     ambiguity_probe_count < 96 then
                    ambiguity_probe_logged[probe_key] = true
                    ambiguity_probe_count = ambiguity_probe_count + 1
                    local bp, sp = best.avatar.p,
                                         second ~= nil and second.avatar.p or nil
                    log(string.format(
                      "binding ambiguity profile=%s generation=%d world=%s " ..
                      "avatars=%d unit_nodes=%d root_node=%d " ..
                      "unit=(%.4f,%.4f,%.4f) best=%.5f " ..
                      "avatar=(%.4f,%.4f,%.4f) camera_nearest=%s " ..
                      "second=%.5f second_avatar=(%.4f,%.4f,%.4f) " ..
                      "second_camera_nearest=%s margin=%.5f",
                      matched.hash, lifecycle_generation, tostring(world),
                      #context_avatars, node_count, best.node,
                      best.p[1], best.p[2], best.p[3], best_distance,
                      bp[1], bp[2], bp[3],
                      tostring(best.avatar.camera_nearest), second_distance,
                      sp and sp[1] or 0.0, sp and sp[2] or 0.0,
                      sp and sp[3] or 0.0,
                      tostring(second and
                               second.avatar.camera_nearest or false),
                      second_distance - best_distance))
                  end
                elseif binding_gate == false then
                else
                  best.avatar.needed = true
                  best.avatar.gait_enabled = best.avatar.gait_enabled or matched.female
                  bindings[#bindings + 1] = {
                    world = world, profile = matched, avatar = best.avatar,
                    unit = unit, node_count = node_count,
                    root_node = best.node,
                    root_q = best.q, root_p = best.p,native_snapshot=armour.native_snapshot,
                  }
                end
              end
            end
          end
        end
      end
      -- Stable, older render instances first: when a new route becomes visible
      -- its common canonical input can join an already continuous cohort.
      table.sort(presentation_bindings,function(a,b)
        return rawget(_G,'__hd2ir_unit_instance_slot')(a.unit)<rawget(_G,'__hd2ir_unit_instance_slot')(b.unit)
      end)
      if #avatars == 0 then
        rawget(_G,'__hd2ir_shared_body_lifecycle').observe({},C,function()return nil end)
        for i=1,#presentation_bindings do retarget_test_unit(presentation_bindings[i].world,presentation_bindings[i]) end
        update_lifecycle_gap()
        return
      end
      if rawget(_G,'__hd2ir_work_mark')then rawget(_G,'__hd2ir_work_mark')(1)end
      update_lifecycle(active_world_set_key(contexts), #contexts, avatars,
                       bindings, ambiguous_bindings)
      if C.set_avatar_physics_class then
        pcall(rawget(_G,"__hd2ir_physics_identity").update,avatars)
      end
      -- Only uniquely native-bound actors in a separate, non-network/non-NPC
      -- World qualify. Ambiguous icons and stateless ship fixtures stay out.
      local display_lives={}
      local display_ok,display_result=pcall(rawget(_G,'__hd2ir_physics_identity').presentation_lives,
        avatars,contexts,suppress_all_carriers)
      if display_ok and type(display_result)=='table' then display_lives=display_result end
      -- Pose consensus proves the rendered input, not a player owner. These
      -- anonymous UI Units receive render-instance history in a separate ABI;
      -- never promote them to gameplay actors or touch stateless NPC fixtures.
      local worlds_ok,preview_worlds=pcall(rawget(_G,'__hd2ir_physics_identity').presentation_worlds,
        avatars,contexts,suppress_all_carriers)
      if worlds_ok and type(preview_worlds)=='table' then
        for _,context in ipairs(contexts)do
          local key='presentation-physics|'..rawget(_G,'__hd2ir_unit_instance_slot')(context.world)..
            '|'..tostring(context.fp_graph_absent)..'|'..tostring(preview_worlds[context.world]~=nil)
          if not ambiguity_probe_logged[key] then
            ambiguity_probe_logged[key]=true
            log(key..' legacy_camera_hold='..tostring(suppress_all_carriers))
          end
        end
        for _,binding in ipairs(presentation_bindings)do
          if binding.preview_audit and not binding.avatar.presentation_kind then
            binding.presentation_world=preview_worlds[binding.world]
          end
        end
      end
      rawget(_G,'__hd2ir_shared_body_lifecycle').observe(avatars,C,function(item)
        return display_lives[item.instance_slot] or rawget(_G,'__hd2ir_physics_identity').shared_life(item.unit,item.world)
      end)
      rawget(_G,'__hd2ir_scene_restore').restore_pending(bindings)
      if rawget(_G,'__hd2ir_native_handoff') then
        rawget(_G,'__hd2ir_native_handoff').filter(bindings)
        rawget(_G,'__hd2ir_native_handoff').filter(presentation_bindings)
        -- A filtered teammate must not trigger a full Avatar skeleton read.
        for _,a in ipairs(avatars)do a.needed=false end
        for _,b in ipairs(bindings)do b.avatar.needed=true end
      end
      if worlds_ok and type(preview_worlds)=='table' then
        -- Recover any existing actor-scoped incomplete write BEFORE moving
        -- its freshly proven display binding to the render-instance route.
        rawget(_G,'__hd2ir_pose_batch').route_presentations(bindings,presentation_bindings,preview_worlds)
      end
      -- Private candidate gate: only a fully committed visual replacement can
      -- remove this exact teammate's bindings. Absent/failed module is a no-op.
      if rawget(_G,'__hd2ir_work_mark')then rawget(_G,'__hd2ir_work_mark')(2)end
      if type(rawget(_G,'__hd2ir_stock_swap_frame'))=='function' then
        pcall(rawget(_G,'__hd2ir_stock_swap_frame'),avatars,bindings)
      end
      if rawget(_G,'__hd2ir_work_mark')then rawget(_G,'__hd2ir_work_mark')(3)end
      -- Read every target world pose before the write and refresh only the
      -- matched armour Unit.  The avatar and all foreign Units stay read-only.
      for i = 1, #bindings do
        roundtrip_unit(bindings[i].world, bindings[i])
      end
      local handoff_rejected,handoff_units=rejected,units_sent
      if tonumber(C.begin_frame(frame)) ~= 1 then rejected = rejected + 1 return end
      -- IDs only need to be unique inside this committed frame. Unit handles
      -- remain local to this render call and never cross a hook boundary.
      pcall(rawget(_G,'__hd2ir_corpse_freeze').control_context,contexts,avatars)
      local avatar_count = 0
      for i = 1, #avatars do
        local item = avatars[i]
        if item.needed and avatar_count < 32 then
          local root = ffi.new("float[12]")
          local bones = ffi.new("float[?]", #source_names * 12)
          fill_matrix(root, 0, item.root_q, item.p)
          local complete = true
          for bi = 1, #source_names do
            local q, p = rawget(_G,"__hd2ir_read_avatar_pose")(item,source_names[bi])
            if q == nil or p == nil then complete = false break end
            fill_matrix(bones, (bi - 1) * 12, q, p)
          end
          if complete then
            item.source_bones = bones
            -- The C++ mailbox only needs IDs to be unique inside one frame,
            -- but the corpse lifecycle probe must recognize the same Avatar
            -- after a death/respawn boundary. The weak-key slot is stable for
            -- that concrete Unit instance and is never used to call through a
            -- cached handle, so passing it here adds identity without adding
            -- lifetime risk.
            local candidate_id = item.instance_slot
            if tonumber(C.push_avatar(candidate_id, root, #source_names, bones)) == 1 then
              local incarnation=rawget(_G,'__hd2ir_shared_body_lifecycle').token(candidate_id)
              if incarnation and C.set_avatar_incarnation then C.set_avatar_incarnation(candidate_id,incarnation)end
              if C.set_avatar_physics_class then
                C.set_avatar_physics_class(candidate_id,display_lives and display_lives[candidate_id] and 4 or rawget(_G,"__hd2ir_physics_identity").role(item.unit))
              end
              if item.gait_enabled and C.set_avatar_gait_weight and C.gait_correction_enabled then
                local gait=rawget(_G,"__hd2ir_gait_control")
                local ok,weight=pcall(gait.sample,item,frame,gait_sample_time,C)
                C.set_avatar_gait_weight(candidate_id,ok and weight or 0)
              end
              avatar_count = avatar_count + 1
              item.id = candidate_id
              avatars_sent = avatars_sent + 1
            else
              rejected = rejected + 1
            end
          else
            rejected = rejected + 1
          end
        end
      end

      -- Persistent Unit identity: World scans and per-resource lookups have
      -- different enumeration orders. Frame-local ordinals would switch a
      -- helmet's physics state every DISCOVERY_INTERVAL (and across players).
      for i = 1, #bindings do
        local binding = bindings[i]
        if binding.avatar.id ~= nil and not binding.scene_restore_blocked then
          local instance_id = rawget(_G, "__hd2ir_unit_instance_slot")(binding.unit)
          local root = ffi.new("float[12]")
          fill_matrix(root, 0, binding.root_q, binding.root_p)
          if tonumber(C.bind_unit(binding.profile.id, instance_id,
                                  binding.avatar.id, root)) == 1 then
            if rawget(_G,'__hd2ir_native_handoff') then rawget(_G,'__hd2ir_native_handoff').bound(binding.unit,binding.avatar.unit,binding.avatar.world) end
            binding.instance_id = instance_id
            units_sent = units_sent + 1
          else
            rejected = rejected + 1
          end
        end
      end
      if rawget(_G,'__hd2ir_work_mark')then rawget(_G,'__hd2ir_work_mark')(4)end
      if tonumber(C.end_frame(frame)) == 1 then
        frames_sent = frames_sent + 1
        rawget(_G,"__hd2ir_pose_batch").run(bindings,retarget_test_unit)
        if rawget(_G,'__hd2ir_corpse_freeze_active')==true then
          rawget(_G,'__hd2ir_corpse_freeze').flush(bindings)
        end
        rawget(_G,'__hd2ir_pose_batch').run_presentations(presentation_bindings,retarget_test_unit)
        handoff_feed_complete=rejected==handoff_rejected and units_sent-handoff_units==#bindings
      else
        rejected = rejected + 1
      end
      if rawget(_G,'__hd2ir_work_mark')then rawget(_G,'__hd2ir_work_mark')(5)end
      -- Read-only telemetry after the real native submission and pose dispatch.
      if type(rawget(_G,'__hd2ir_stock_swap_result'))=='function' then
        pcall(rawget(_G,'__hd2ir_stock_swap_result'),avatars,bindings,frame,
          frames_sent,avatars_sent,units_sent,retarget_units,retarget_nodes)
      end

      if frame % 1800 == 0 then
        local status = ffi.new("hd2ir_status_v1[1]")
        local status_size = ffi.sizeof("hd2ir_status_v1")
        local returned = tonumber(C.get_status(status, status_size)) or 0
        if returned == status_size then
          local s = status[0]
          log(string.format(
            "frames=%d feed_avatars=%d feed_bindings=%d feed_rejected=%d " ..
            "runtime_mode=%d profiles=%d source_bones=%d live_avatars=%d " ..
            "live_units=%d needle_matches=%d palette_writes=%d ambiguous=%d " ..
            "lua_drive=%s roundtrip_units=%d nodes=%d rejected=%d " ..
            "max_residual=%.5fdeg/%.7fm scans=%d scan_hits=%d " ..
            "resource_hits=%d resource_misses=%d " ..
            "retarget_attempts=%d units=%d nodes=%d rejected=%d " ..
            "raw_max=%.4fdeg/%.6fm step_max=%.4fdeg/%.6fm " ..
            "retarget_residual=%.5fdeg/%.7fm quarantines=%d recoveries=%d " ..
            "fp_entries=%d fp_exits=%d fp_writes=%d " ..
            "lifecycle_generation=%d transitions=%d ambiguous_total=%d",
            frames_sent, avatars_sent, units_sent, rejected,
            tonumber(s.mode), tonumber(s.profiles), tonumber(s.source_bones),
            tonumber(s.avatars), tonumber(s.unit_instances),
            tonumber(s.needle_matches), tonumber(s.palette_writes),
            tonumber(s.ambiguous_instances), drive_mode, roundtrip_units,
            roundtrip_nodes, roundtrip_rejected, max_roundtrip_rotation,
            max_roundtrip_position, discovery_scans, discovery_hits,
            resource_lookup_hits, resource_lookup_misses,
            retarget_attempts, retarget_units, retarget_nodes,
            retarget_rejected, max_retarget_raw_rotation,
            max_retarget_raw_position, max_retarget_step_rotation,
            max_retarget_step_position, max_retarget_residual_rotation,
            max_retarget_residual_position, binding_quarantines,
            binding_recoveries, fp_entries, fp_exits, fp_writes,
            lifecycle_generation,
            lifecycle_transitions, lifecycle_ambiguous_total))
        else
          log(string.format("frames=%d avatars=%d unit_bindings=%d rejected=%d " ..
                            "status_size_mismatch=%d/%d",
                            frames_sent, avatars_sent, units_sent, rejected,
                            returned, status_size))
        end
        if C.physics_capabilities ~= nil and C.get_physics_status ~= nil then
          local physics = ffi.new("hd2ir_physics_status_v1[1]")
          local physics_size = ffi.sizeof("hd2ir_physics_status_v1")
          local physics_returned = try(function()
            return C.get_physics_status(physics, physics_size)
          end)
          physics_returned = tonumber(physics_returned) or 0
          if physics_returned == physics_size and
             tonumber(physics[0].version) == 1 then
            local p = physics[0]
            log(string.format(
              "PhysBone status: configs=%d instances=%d steps=%d " ..
              "resets=%d rejected_steps=%d",
              tonumber(p.configs), tonumber(p.instances), tonumber(p.steps),
              tonumber(p.resets), tonumber(p.rejected_steps)))
            if C.get_physics_events~=nil then
              local size=ffi.sizeof("hd2ir_physics_events_v1")
              if size==104 then
                local events=ffi.new("hd2ir_physics_events_v1[1]")
                local count=try(function()return C.get_physics_events(events,size)end)
                if tonumber(count)==size and tonumber(events[0].version)==1 then
                  local e=events[0]
                  -- The game's tostring(cdata) treats uint64 values as dead
                  -- engine objects. Format the exact words without precision loss.
                  local words=ffi.cast("unsigned *",events)
                  local unit_hex=string.format("%08x%08x",tonumber(words[21]),tonumber(words[20]))
                  local instance_hex=string.format("%08x%08x",tonumber(words[23]),tonumber(words[22]))
                  log(string.format("PhysBone events: initial=%d layout=%d frame_gap=%d time_gap=%d teleport=%d continuation_trials=%d animation_fallbacks=%d partial_fallbacks=%d last_reason=%d last_frame=%d last_unit=%s last_instance=%s elapsed=%.6fs anchor=%.6fm",
                    tonumber(e.initializations),tonumber(e.layout_resets),tonumber(e.frame_gap_resets),
                    tonumber(e.time_gap_resets),tonumber(e.teleport_resets),tonumber(e.continuation_trials),
                    tonumber(e.animation_fallbacks),tonumber(e.partial_fallbacks),tonumber(e.last_reset_reason),
                    tonumber(e.last_reset_frame),unit_hex,instance_hex,
                    tonumber(e.last_reset_elapsed),tonumber(e.last_reset_anchor_distance)))
                end
              end
            end
          else
            log(string.format(
              "PhysBone 状态不可用: returned=%d expected=%d version=%d",
              physics_returned, physics_size,
              tonumber(physics[0].version) or -1))
          end
        end
      end
    end)
    if rawget(_G,'__hd2ir_native_handoff') then rawget(_G,'__hd2ir_native_handoff').result(hook_ok and handoff_feed_complete) end
    if not hook_ok then
      hook_errors = hook_errors + 1
      if hook_errors <= 3 or hook_errors % 600 == 0 then
        log("render feed error #" .. tostring(hook_errors) .. ": " ..
            tostring(hook_error))
      end
    end
    rawset(_G,"__hd2ir_source_reads",nil)
    local whole_trial=rawget(_G,"__hd2ir_weapon_root_trial")
    if hook_ok then whole_trial.apply() end
    -- Success retains numeric restoration data until the next update/render;
    -- errors restore immediately. No Unit handle survives this invocation.
    local function pack_render(...)return {n=select("#",...),...}end
      if rawget(_G,'__hd2ir_work_mark')then rawget(_G,'__hd2ir_work_mark')(6)end
    whole_trial.rendering=true
    local render_result=pack_render(pcall(old_render,...))
    if rawget(_G,"__hd2ir_preview_delivery") then pcall(rawget(_G,"__hd2ir_preview_delivery").finish) end
    if render_result[1] then whole_trial.defer_restore() else whole_trial.restore() end
    whole_trial.rendering=false
    whole_trial.begin()
    if rawget(_G,'__hd2ir_work_finish')then rawget(_G,'__hd2ir_work_finish')()end
    if not render_result[1] then error(render_result[2]) end
    return unpack(render_result,2,render_result.n)
  end

  -- Guard the whole synchronous feed, including discovery/bridge calls and
  -- restoration before the old-render tail. A nested callback must not replace
  -- the outer frame counter, source cache, or native batch transaction.
  do
    local running=false
    local function pack(...)return {n=select("#",...),...}end
    rawset(_G,"render",function(...)
      if running then return old_render(...) end
      running=true
      local result=pack(pcall(render_frame,...))
      running=false
      if rawget(_G,'__hd2ir_native_handoff') then
        local clean=result[1] and rawget(_G,'__hd2ir_preview_update_enabled')~=true and
          rawget(_G,'__hd2ir_native_legacy_disabled')==true
        rawget(_G,'__hd2ir_native_handoff').finish(clean==true,function(scope)
          return scope and rawget(_G,'__hd2ir_scene_restore').native_handoff_clean(scope) and
            rawget(_G,'__hd2ir_weapon_root_trial').native_handoff_clean(scope) and
            rawget(_G,'__hd2ir_corpse_freeze').native_handoff_clean(scope)
        end)
      end
      rawset(_G,"__hd2ir_source_reads",nil)
      -- Do not reset weapon rendering/plans/pending on an unexpected tail
      -- exception: a partly deferred weapon restore may still need them.
      -- Preserve the original failure semantics, including nil return slots.
      if not result[1] then error(result[2],0) end
      return unpack(result,2,result.n)
    end)
  end

  log("render hook installed; avatars stay read-only; calibration defaults to retarget_test")
  -- Optional VM policy is reached only after the runtime hooks are installed.
  --@@GC_POLICY_INTEGRATED_BEGIN@@
-- Embedded startup policy, not a separate Bingus module or callback wrapper.
-- Known third-party policies retain control. Removal takes a full VM restart.
do
  local function configure_gc_policy()
    local key = "HD2IRGcPolicy"
    -- Do not replace another revision, malformed state, or a previous attempt.
    -- Returning here returns from this helper, never from the runtime body.
    if rawget(_G, key) ~= nil then return end
    local state = {revision = "gc-pause400-1", status = "checking",
      requested_pause = 400, attempted = false, scope = "whole Lua VM"}
    rawset(_G, key, state)
    local loader = rawget(_G, "CowboyBingusModLoader")

    local function finish(status, reason)
      state.status, state.reason = status, reason
      -- One best-effort startup record. Logging cannot retry a GC operation.
      local file
      pcall(function()
        if type(loader) == "table" and type(loader.open_log) == "function" then
          file = loader.open_log("HD2IRGcPolicy.log")
        end
        if file then
          local now = os.time()
          local local_parts, utc_parts = os.date("*t", now), os.date("!*t", now)
          utc_parts.isdst = local_parts.isdst
          local offset = os.difftime(os.time(local_parts), os.time(utc_parts))
          local minutes = math.floor(math.abs(offset) / 60)
          local stamp = string.format("%s %s%02d:%02d", os.date("%Y-%m-%d %H:%M:%S", now),
            offset < 0 and "-" or "+", math.floor(minutes / 60), minutes % 60)
          file:write("HD2IR GC Policy ", state.revision,
            "\nlocal_time=", stamp, "\nstatus=", status,
            "\nreason=", reason, "\nrequested_pause=400\nprevious_pause=",
            tostring(state.previous_pause or "unknown"),
            "\nattempted=", tostring(state.attempted),
            "\nscope=whole Lua VM\nrestart_required_to_remove=true\n")
        end
      end)
      if file then pcall(function() file:close() end) end
    end

    if type(loader) ~= "table" or rawget(loader, "api") ~= 1 or
        type(rawget(loader, "modules")) ~= "table" then
      return finish("blocked", "Bingus API 1 is unavailable; runtime continues")
    end
    if rawget(_G, "HD2SmoothBoot") ~= nil then
      return finish("delegated", "SmoothBoot marker is present; its GC policy is preserved")
    end
    if rawget(_G, "HD2IRGcPolicyTest") ~= nil then
      return finish("delegated", "Legacy GC test marker is present; its policy is preserved")
    end
    -- Known resource presence, not require(): detect later loader entries too.
    -- Never read or edit the other policy's configuration or callback chain.
    local checked, owner = pcall(function()
      local sr = rawget(_G, "stingray")
      local app = type(sr) == "table" and sr.Application
      if app == nil or type(app.can_get) ~= "function" then
        error("resource lookup unavailable")
      end
      local smoothboot = app.can_get("lua", "mods/codex/smoothboot")
      if type(smoothboot) ~= "boolean" then error("invalid resource lookup result") end
      if smoothboot then return "SmoothBoot resource" end
      local legacy = app.can_get("lua", "mods/hd2ir/gc_policy_test")
      if type(legacy) ~= "boolean" then error("invalid resource lookup result") end
      if legacy then return "Legacy GC test resource" end
      return false
    end)
    if not checked then
      return finish("blocked", "Known-policy resource check failed; runtime continues")
    end
    if owner then
      return finish("delegated", owner .. " is present; its GC policy is preserved")
    end
    local gc = rawget(_G, "collectgarbage")
    if type(gc) ~= "function" then
      return finish("blocked", "GC setter is unavailable; runtime continues")
    end

    -- The only GC operation: no getter emulation, stepmul, restore or polling.
    -- A setter can fail after a side effect, so latch before calling it.
    state.attempted = true
    local applied, old = pcall(gc, "setpause", state.requested_pause)
    if not applied then
      return finish("failed", "GC setter raised an error; effective policy is unverified")
    end
    if type(old) ~= "number" or old ~= old or old == math.huge or old == -math.huge then
      return finish("unverified", "GC setter returned an unexpected prior value")
    end
    state.previous_pause = old
    return finish("applied_once", "Pause was set once; later external policy changes are preserved")
  end
  -- A failed optional policy must not stop the runtime's own initialization.
  pcall(configure_gc_policy)
end
--@@GC_POLICY_INTEGRATED_END@@
end)

-- Private, finite observer only. No additional game API calls or pose writes.
pcall(function()
  if rawget(_G,'__hd2ir_teammate_appearance_observer') then return end
  local ffi=require('ffi')
  pcall(ffi.cdef,[[void *GetModuleHandleA(const char *name);
    void *GetProcAddress(void *module,const char *name);]])
  local k32=ffi.load('kernel32')
  local emit
  local previous=rawget(_G,'__hd2ir_teammate_identity_status_sink')
  local sink
  local function valid(n,max)return type(n)=='number' and n==math.floor(n) and n>=0 and n<=max end
  sink=function(live,objects,...)
    if type(previous)=='function' then pcall(previous,live,objects,...) end
    if not emit then
      -- Identity callbacks run only after the normal bridge has loaded. Look
      -- up that already-loaded module; never load a second addon from a path.
      local ok,fn=pcall(function()
        local module=k32.GetModuleHandleA('HD2IndependentRig.addon64')
        if module==nil or module==ffi.NULL then return end
        local address=k32.GetProcAddress(module,'hd2ir_teammate_observe_actor')
        if address==nil or address==ffi.NULL then return end
        return ffi.cast('unsigned (*)(unsigned,unsigned long long,unsigned long long,unsigned,unsigned)',address)
      end)
      if ok then emit=fn end
      if not emit then
        if rawget(_G,'__hd2ir_teammate_identity_status_sink')==sink then rawset(_G,'__hd2ir_teammate_identity_status_sink',previous) end
        return
      end
    end
    if type(live)~='table' or #live>32 or type(objects)~='table' then return end
    local slot=rawget(_G,'__hd2ir_unit_instance_slot')
    if type(slot)~='function' then return end
    for _,item in ipairs(live)do
      local s=item.s or {};local a=item.a or {};local id=s.network
      local o=valid(id,4294967295) and objects[id]
      local role=valid(s.role,3) and s.role or 0
      -- A cached role must not claim a currently healthy actor without the
      -- current sample. Health is encoded as live/dead, not continuously logged.
      if o and type(o.health)=='number' and o.health==o.health and math.abs(o.health)<1.e9 and a.unit and a.world then
        local u,w=a.instance_slot or slot(a.unit),slot(a.world)
        if valid(u,9007199254740991) and valid(w,9007199254740991) and u>0 and w>0 then
          local status=emit(id,u,w,role,o.health>0 and 1 or 0)
          if status==2 then
            if rawget(_G,'__hd2ir_teammate_identity_status_sink')==sink then
              rawset(_G,'__hd2ir_teammate_identity_status_sink',previous)
            end
            return
          end
        end
      end
    end
  end
  rawset(_G,'__hd2ir_teammate_appearance_observer',true)
  rawset(_G,'__hd2ir_teammate_identity_status_sink',sink)
end)

-- Cache immutable NAME -> INDEX mappings only, never poses or ownership.
-- Caller must supply this callback's freshly enumerated Unit and live count.
pcall(function()
  local S=assert(rawget(_G,'stingray'));local U=assert(S.Unit);local ID=assert(S.IdString64)
  assert(type(U.name_hash)=='function' and type(ID.to_hex)=='function')
  local tick=0;local current={};local saved=setmetatable({},{__mode='k'})
  -- Update and render may share the public frame number. Start a new resource
  -- check boundary whenever either callback enumerates fresh Worlds.
  rawset(_G,'__hd2ir_topology_barrier',function()current={}end)
  rawset(_G,'__hd2ir_topology_begin',function(value)
    if type(value)~='number' or value~=math.floor(value) or value<=0 then return end
    if value~=tick then current={};tick=value end
  end)
  rawset(_G,'__hd2ir_topology_node',function(unit,name,count)
    if tick==0 then return U.has_node(unit,name)==true and U.node(unit,name) or nil end
    assert(type(count)=='number' and count==math.floor(count) and count>=1 and count<=512,'topology-count')
    local row=current[unit]
    if not row or row.count~=count then
      assert(U.alive(unit)==true,'topology-dead')
      local resource=ID.to_hex(U.name_hash(unit))
      assert(type(resource)=='string' and #resource==16,'topology-resource')
      local prior=saved[unit]
      if prior and prior.resource==resource and prior.count==count and
          (prior.tick==tick or prior.tick==tick-1) then row=prior
      else row={resource=resource,count=count,names={}};saved[unit]=row end
      row.tick=tick;current[unit]=row
    end
    local node=row.names[name]
    if node~=nil then return node end
    if U.has_node(unit,name)~=true then return nil end
    node=U.node(unit,name)
    if type(node)~='number' or node~=math.floor(node) or node<0 or node>count then return nil end
    row.names[name]=node;return node
  end)
end)

rawset(_G,'__hd2ir_handoff_scope_clean',(function()
-- Numeric-only scope. Unknown ownership still blocks; an authenticated other
-- World or actor cannot hold an unrelated teammate's writer barrier forever.
return function(scope,records,identity)
  local function valid(n)return type(n)=='number' and n==n and n>0 and n%1==0 end
  if type(scope)~='table' or not valid(scope.world) or not valid(scope.avatar) then return false end
  for _,record in pairs(records)do
    local world,owner=identity(record)
    if not valid(world) then return false end
    if world==scope.world and (not valid(owner) or owner==scope.avatar) then return false end
  end
  return true
end

end)())
