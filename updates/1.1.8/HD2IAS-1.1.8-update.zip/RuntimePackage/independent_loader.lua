-- HD2-Addon: mods/hd2ir/runtime
-- Independent entry point for Bingus Shared Loader v15 addon discovery.
-- No boot resource, polling hook, or diagnostic sampler is installed here.
local identity = "@@MODULE_IDENTITY@@"
local key = "__hd2ir_loader_state"
local previous = rawget(_G, key)
if previous ~= nil then
  if type(previous) == "table" and previous.identity == identity and previous.status == "active" then
    return previous
  end
  error("HD2 LUA: duplicate, incomplete, or different runtime; restart after correcting installed packages")
end
if rawget(_G, "__hd2ir_weapon_root_trial") ~= nil or
   rawget(_G, "__hd2ir_scene_restore") ~= nil or
   rawget(_G, "__hd2ir_gait_control") ~= nil then
  error("HD2 LUA: legacy merged runtime is already active; migrate the old package first")
end

local old_update, old_render = rawget(_G, "update"), rawget(_G, "render")
if type(old_update) ~= "function" or type(old_render) ~= "function" then
  error("HD2 LUA: game update/render callbacks are not ready")
end
local sr = rawget(_G, "stingray")
if type(sr) ~= "table" then error("HD2 LUA: Stingray API unavailable") end
for _, name in ipairs({"Application", "World", "Unit", "Quaternion", "Vector3", "IdString64"}) do
  local ok, value = pcall(function() return sr[name] end)
  if not ok or value == nil then error("HD2 LUA: missing Stingray API " .. name) end
end
local ffi_ok, ffi = pcall(require, "ffi")
if not ffi_ok or type(ffi) ~= "table" then error("HD2 LUA: LuaJIT FFI unavailable") end

local saved = {}
local function owned(name)
  return type(name) == "string" and name:sub(1, 8) == "__hd2ir_"
end
for name, value in pairs(_G) do if owned(name) then saved[name] = value end end
local state = {identity = identity, status = "loading"}
rawset(_G, key, state)
local ok, reason = pcall(function()
--@@RUNTIME_BODY_BEGIN@@
@@RUNTIME_BODY@@
--@@RUNTIME_BODY_END@@
end)
local function member(global, name)
  local value = rawget(_G, global)
  return type(value) == "table" and type(value[name]) == "function"
end
-- The legacy body's outer pcall can suppress an initialization exception.
-- A successful require therefore needs positive installation evidence as well.
local installed = type(rawget(_G, "update")) == "function" and rawget(_G, "update") ~= old_update and
  type(rawget(_G, "render")) == "function" and rawget(_G, "render") ~= old_render and
  member("__hd2ir_gait_control", "sample") and
  member("__hd2ir_shared_body_lifecycle", "observe") and
  member("__hd2ir_weapon_root_trial", "restore_pending") and
  member("__hd2ir_scene_restore", "restore_pending")
if not ok or not installed then
  rawset(_G, "update", old_update)
  rawset(_G, "render", old_render)
  local remove = {}
  for name in pairs(_G) do if owned(name) then remove[#remove + 1] = name end end
  for _, name in ipairs(remove) do rawset(_G, name, nil) end
  for name, value in pairs(saved) do rawset(_G, name, value) end
  state.status = "failed"
  state.reason = ok and "runtime initialization incomplete" or tostring(reason)
  rawset(_G, key, state)
  error("HD2 LUA: " .. state.reason)
end
state.status = "active"
return state
