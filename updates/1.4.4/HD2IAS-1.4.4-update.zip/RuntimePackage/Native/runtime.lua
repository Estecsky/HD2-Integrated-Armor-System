-- HD2 integrated armour: paired full-native pose control, ABI 5.
-- No Unit bone getter/setter, solver, World update, spawn or destroy is used.
-- Native admission failure does not enable the retired Lua pose driver.
rawset(_G,'__hd2ir_native_handoff',nil)
rawset(_G,'__hd2ir_native_legacy_disabled',true)
rawset(_G,'__hd2ir_stock_swap_frame',function()end)
rawset(_G,'__hd2ir_stock_swap_result',function()end)
rawset(_G,'__hd2ir_preview_update_enabled',false)
pcall(function()
  local S=rawget(_G,'stingray');if not S then return end
  local A,W,U,ID=S.Application,S.World,S.Unit,S.IdString64
  if not A or not W or not U or not ID then return end
  local ffi=require('ffi')
  pcall(ffi.cdef,[[void *GetModuleHandleA(const char*);void *GetProcAddress(void*,const char*);unsigned GetTickCount(void);]])
  local frame,next_slot=0,1
  local slots,seen={},{}
  local function slot(value)
    if value==nil then return 0 end
    local value_slot=slots[value]
    if not value_slot then
      if next_slot>4294967295 then return 0 end
      value_slot=next_slot;next_slot=next_slot+1;slots[value]=value_slot
    end
    seen[value]=frame;return value_slot
  end
  rawset(_G,'__hd2ir_unit_instance_slot',slot)
  local function contexts()
    local worlds=A.worlds();if type(worlds)~='table' or #worlds>32 then return end
    local result={}
    for _,world in ipairs(worlds)do
      local count=W.num_units(world)
      local avatars=W.units_by_resource(world,'content/fac_helldivers/cha_avatar/avatar_helldiver')
      local fp=W.units_by_resource(world,'content/fac_helldivers/fp_cha_avatar/fp_cha_avatar')
      if type(count)~='number' or count<0 or count>131072 or type(avatars)~='table' or #avatars>32 or
          type(fp)~='table' or #fp>32 then return end
      local sources={}
      for _,ref in ipairs({{hash='5b390845a8e3fc29',kind='ship-display'},{hash='15678e360612b805',kind='democracy-officer'}})do
        local rows=W.units_by_resource(world,ID.from_hex(ref.hash))
        if type(rows)~='table' or #rows>32 then return end
        for _,unit in ipairs(rows)do
          if string.find(string.lower(tostring(U.debug_name(unit))),ref.hash,1,true) then sources[#sources+1]={unit=unit,hash=ref.hash,kind=ref.kind} end
        end
      end
      if count>0 and (#avatars>0 or #fp>0 or #sources>0)then
        result[#result+1]={world=world,avatars=avatars,scene_sources=sources}
      end
    end
    return result
  end
  local function ship_phase(rows)
    if #rows~=1 then return 2 end
    local row=rows[1];local display,officer=false,false
    for _,source in ipairs(row.scene_sources)do
      if U.alive(source.unit)==true then
        if source.kind=='ship-display' then display=true end
        if source.kind=='democracy-officer' then officer=true end
      end
    end
    if display and officer then
      for _,unit in ipairs(row.avatars)do
        if U.alive(unit)==true and U.has_animation_state_machine(unit)==true then return 1 end
      end
    end
    return 2
  end
  local ready,context,receipt,bound_addon,bound_native,generation
  -- Bounded numeric diagnostics only; no engine addresses or sampled data.
  local state={version=5,installed=false,reason=0,receipt_frame=0,hint_failures=0}
  local function bind()
    local addon=ffi.C.GetModuleHandleA('HD2IndependentRig.addon64')
    local native=ffi.C.GetModuleHandleA('HD2NativeHandoffFull_w64_release.dll')
    if addon==nil or addon==ffi.NULL or native==nil or native==ffi.NULL then
      ready,context,receipt,bound_addon,bound_native,generation=nil,nil,nil,nil,nil,nil;return false
    end
    if addon==bound_addon and native==bound_native and ready and context and receipt and generation then return true end
    local function fn(module,name,kind)
      local p=ffi.C.GetProcAddress(module,name)
      if p==nil or p==ffi.NULL then return end
      return ffi.cast(kind,p)
    end
    local addon_route=fn(addon,'hd2ir_runtime_route_v1','unsigned (*)(void)')
    local native_route=fn(native,'hd2ir_runtime_route_v1','unsigned (*)(void)')
    if not addon_route or not native_route or tonumber(addon_route())~=2 or tonumber(native_route())~=2 then return false end
    ready=fn(addon,'hd2ir_bridge_ready_v1','unsigned (*)(void)')
    context=fn(addon,'hd2ir_corpse_freeze_context','void (*)(uint64_t,unsigned)')
    receipt=fn(native,'hd2_pose_control_ack_v2','unsigned (*)(unsigned,unsigned,uint64_t,unsigned)')
    local begin=fn(native,'hd2_pose_control_begin_v1','unsigned (*)(unsigned)')
    if not ready or not context or not receipt or not begin then return false end
    generation=tonumber(begin(5));if not generation or generation<1 then generation=nil;return false end
    bound_addon,bound_native=addon,native
    return true
  end
  local installed=false
  rawset(_G,'__hd2ir_install_native_control',function()
    if installed then return true end
    local old=rawget(_G,'render');if type(old)~='function' then return false end
    local running=false
    local function pack(...)return {n=select('#',...),...}end
    rawset(_G,'render',function(...)
      if running then return old(...) end
      running=true;frame=frame+1
      if frame%120==0 then for value,last in pairs(seen)do if frame-last>2 then seen[value]=nil;slots[value]=nil end end end
      local gate=rawget(_G,'__hd2ir_native_handoff')
      local ok,complete=pcall(function()
        if not gate then
          local connect=rawget(_G,'__hd2ir_connect_native_control')
          if connect then connect() end
          gate=rawget(_G,'__hd2ir_native_handoff')
        end
        state.reason=1
        if not gate or not gate.begin() or not bind() or tonumber(ready())~=1 then return false end
        -- The paired control-only wrapper is alive. World enumeration is a
        -- read-only appearance/corpse hint, not native pose admission. The
        -- native driver still proves its own current Worlds, Units and host.
        -- A loading/preview hint failure must not expire every native pose.
        state.reason=2
        if tonumber(receipt(5,generation,frame,1))~=1 then return false end
        state.receipt_frame=frame;state.reason=3
        context(frame,0)
        local rows=contexts();if not rows then return false end
        gate.observe(rows);context(frame,ship_phase(rows))
        -- This layer owns no pose feed or transient model write. The positive
        -- control-only receipt is separate from the per-peer drain receipt.
        gate.filter({});gate.filter({})
        state.reason=0
        return true
      end)
      if state.reason==3 then state.hint_failures=state.hint_failures+1 end
      if gate and gate.control_state then
        local c=gate.control_state();state.mode_requested=c.requested;state.mode_received=c.received
      end
      if gate then gate.result(ok and complete==true) end
      local result=pack(pcall(old,...))
      if gate then pcall(gate.finish,ok and complete==true and result[1],function(scope)return scope~=nil end) end
      running=false
      if not result[1] then error(result[2],0) end
      return unpack(result,2,result.n)
    end)
    installed=true
    state.installed=true;state.render=rawget(_G,'render')
    rawset(_G,'__hd2ir_native_control_state',state)
    return true
  end)
end)

do
local factory=(function()
-- v3 retained-incarnation multi-peer writer barrier. Numeric generation IDs + numeric World keys
-- only; no retained Unit/World userdata. A receipt is never native authority.
return function(id, world_id, poll, acknowledge, diagnostic, reuse_token)
  local M,current={},nil
  local fresh,seen,metrics,success={},{},{},false
  local fresh_poll,scopes=false,{}
  local accepted,scoped=nil,{}
  for i=1,64 do metrics[i]={filters=0,removed=0,self_bound=0,peer_bound=0} end
  local function clear(t)for k in pairs(t)do t[k]=nil end end
  local function integer(v,maximum)
    return type(v)=='number' and v==v and v>=1 and v<=maximum and v%1==0
  end
  local function list(a,max)
    if type(a)~='table' or #a<1 or #a>max then return end
    local map,n={},0
    for k in pairs(a)do if not integer(k,#a)then return end;n=n+1 end
    if n~=#a then return end
    for _,v in ipairs(a)do if not integer(v,1073741823) or map[v]then return end;map[v]=true end
    return map
  end
  local function signature(p)
    local a={};for v in pairs(p.map)do a[#a+1]=v end;table.sort(a)
    return p.world..'/'..p.root..'/'..table.concat(a,',')
  end
  local function decode(s)
    if type(s)~='table' or s.version~=3 or not integer(s.revision,4294967295) or
       type(s.lanes)~='table' or #s.lanes~=64 then return end
    local preserve=list(s.preserve,31);if not preserve then return end
    local value={revision=s.revision,preserve=preserve,self_root=s.preserve[1],lanes={}}
    for i=1,64 do
      local x=s.lanes[i];if type(x)~='table' then return end
      local p={epoch=x.epoch,world=x.world,root=x.root,phase=x.phase,early=x.early}
      if p.phase==0 then
        if p.epoch~=0 or p.root~=0 or p.world~=0 or p.early~=0 or type(x.units)~='table' or #x.units~=0 then return end
      else
        if not integer(p.epoch,4294967295) or not integer(p.world,4294967295) or
           not integer(p.phase,3) or (p.early~=0 and p.early~=1) then return end
        if p.phase==2 and p.early~=1 or p.phase==3 and p.early~=0 then return end
        p.map=list(x.units,61);if not p.map or not p.map[p.root]then return end
        p.signature=signature(p)
        if p.phase~=3 then
          for v in pairs(p.map)do if preserve[v]then return end end
          for j=1,i-1 do local q=value.lanes[j]
            if q.phase~=0 and q.phase~=3 and q.world==p.world then
              for v in pairs(p.map)do if q.map[v]then return end end
            end
          end
        end
      end
      if current then
        local old=current.lanes[i]
        if p.epoch<old.epoch then return end
        if old.epoch>0 and p.epoch==old.epoch then
          if p.signature~=old.signature or p.phase<old.phase then return end
        end
      end
      value.lanes[i]=p
    end
    if current and s.revision<current.revision then return end
    return value
  end
  local function match(p,u,a,w)
    return p.phase~=0 and p.phase~=3 and p.world==w and
      ((u and p.map[u]) or (a and p.root==a))
  end
  function M.begin()
    clear(fresh);clear(scopes);clear(scoped);success=false;fresh_poll=false
    for i=1,64 do
      seen[i]=false;local m=metrics[i]
      m.filters=0;m.removed=0;m.self_bound=0;m.peer_bound=0
    end
    local ok,s,unchanged=pcall(poll)
    if ok and s then
      -- Only the private transport closure can issue this token, and only
      -- after comparing ALL wire bytes. A repeated revision alone grants
      -- nothing. Reuse only a previously fully decoded/accepted snapshot.
      if reuse_token and unchanged==reuse_token and s==accepted and current then fresh_poll=true
      else local good=decode(s);if good then current=good;accepted=s;fresh_poll=true end end
    end
    -- Communication failure retains the previous authenticated gates, but
    -- cannot poison the local player's complete feed or earn a drain receipt.
    return true
  end
  function M.observe(contexts)
    if type(contexts)~='table' or #contexts>32 then return end
    for _,c in ipairs(contexts)do
      local w=world_id(c.world)
      if integer(w,4294967295) and type(c.avatars)=='table' and #c.avatars<=32 then
        for _,u in ipairs(c.avatars)do local n=id(u)
          if n then
            if fresh[n]==false or (fresh[n] and fresh[n]~=w)then fresh[n]=false else fresh[n]=w end
            if current then for i,p in ipairs(current.lanes)do
              if p.phase~=0 and p.phase~=3 and p.world==w and p.root==n then
                seen[i]=true;scopes[i]={world=w,avatar=world_id(u)}
              end
            end end
          end
        end
      end
    end
  end
  function M.early(unit,world)
    if not current then return false end
    local u=id(unit);if not u or current.preserve[u]then return false end
    local w=world and world_id(world) or fresh[u]
    for _,p in ipairs(current.lanes)do if p.early==1 and match(p,u,u,w)then return true end end
    return false
  end
  function M.filter(bindings)
    if not current then return end
    local to=1
    for i=1,#bindings do
      local b=bindings[i];local u=id(b.unit);local a=b.avatar and id(b.avatar.unit)
      local w=b.avatar and b.avatar.world and world_id(b.avatar.world) or (a and fresh[a])
      local remove=false
      if not ((u and current.preserve[u]) or (a and current.preserve[a]))then
        for lane,p in ipairs(current.lanes)do if match(p,u,a,w)then
          metrics[lane].removed=metrics[lane].removed+1;remove=true
        end end
      end
      if not remove then bindings[to]=b;to=to+1 end
    end
    for i=#bindings,to,-1 do bindings[i]=nil end
    for i=1,64 do metrics[i].filters=metrics[i].filters+1 end
  end
  function M.bound(unit,avatar,world)
    if not current then return end
    local u,a=id(unit),id(avatar);local w=world and world_id(world) or fresh[a]
    for i,p in ipairs(current.lanes)do
      if match(p,u,a,w)then metrics[i].peer_bound=metrics[i].peer_bound+1
      elseif (u and current.preserve[u]) or (a and current.preserve[a])then
        metrics[i].self_bound=metrics[i].self_bound+1
      end
    end
  end
  function M.result(ok) success=ok==true end
  local diagnostic_count,last_diagnostic=0,nil
  function M.finish(clean,lane_clean)
    clear(scoped)
    if current then for i,p in ipairs(current.lanes)do if p.phase==1 then
      scoped[i]=true
      if lane_clean then local ok,value=pcall(lane_clean,scopes[i]);scoped[i]=ok and value==true end
    end end end
    if current and diagnostic and diagnostic_count<48 then
      local rows={tostring(current.revision),tostring(success),tostring(clean)}
      local draining=false
      for i,p in ipairs(current.lanes)do if p.phase==1 then
        draining=true;local m=metrics[i]
        rows[#rows+1]=table.concat({i,p.epoch,tostring(seen[i]),m.filters,m.self_bound,m.peer_bound,m.removed,
          tostring(fresh_poll),tostring(fresh[current.self_root]==p.world),tostring(fresh[p.root]==p.world),tostring(scoped[i])},'/')
      end end
      if draining then local text=table.concat(rows,' ')
        if text~=last_diagnostic then last_diagnostic=text;diagnostic_count=diagnostic_count+1;pcall(diagnostic,text)end
      end
    end
    if not current or not fresh_poll or not success or clean~=true then return false end
    local all=true
    for i,p in ipairs(current.lanes)do if p.phase==1 then
      local m=metrics[i]
      if not seen[i] or fresh[p.root]~=p.world or fresh[current.self_root]~=p.world or m.filters~=2 or m.peer_bound~=0 or not scoped[i] then all=false
      else
        local receipt={version=3,lane=i-1,epoch=p.epoch,revision=current.revision,
          filters=m.filters,self_bound=m.self_bound,peer_bound=0,removed=m.removed,clean=1,
          observed=1,complete=1,absent=m.removed==0 and 1 or 0,self_seen=1}
        local ok,value=pcall(acknowledge,receipt);if not ok or value~=1 then all=false end
      end
    end end
    return all
  end
  function M.state()return current end
  return M
end

end)()
rawset(_G,'__hd2ir_handoff_scope_clean',(function()
-- Numeric-only scope. Unknown ownership still blocks; an authenticated other
-- World or actor cannot hold an unrelated teammate's writer barrier forever.
return function(scope,records,identity)
  local function valid(n)return type(n)=='number' and n==n and n>0 and n%1==0 end
  if type(scope)~='table' or not valid(scope.world) or not valid(scope.avatar) then return false end
  for _,record in pairs(records)do
    local world,owner=identity(record)
    if not valid(world) then return false end
    if world==scope.world and (not valid(owner) or owner==scope.avatar) then return false end
  end
  return true
end

end)())
local id=(function()
-- Factory only: no installed feed hook, native calls, or game mutation here.
-- Input Units MUST come from this callback's fresh engine enumeration.
-- The injected query accepts a full native Unit ID and may return exactly 1
-- only for a currently verified remote native takeover. It is NOT a distance,
-- network-ID, weak userdata slot, resource hash, or cached friendly-role query.
local ffi=require('ffi')
return function(query)
  assert(type(query)=='function' or type(query)=='cdata','native exclusion query required')
  local function id(unit)
    if type(unit)~='userdata' then return nil end
    local ok,value=pcall(function()return tonumber(ffi.cast('uintptr_t',unit))end)
    if not ok or type(value)~='number' or value~=value or value<4 or value>4294967295 or value%1~=0 then return nil end
    -- Verified actual Unit.alive and num_scene_graph_items wrappers call
    -- lua_touserdata then shift EAX by two. Unit.id is a DIFFERENT identity.
    return math.floor(value/4)
  end
  local function exclude(unit)
    local value=id(unit);if not value then return false end
    local ok,status=pcall(query,value)
    return ok and tonumber(status)==1
  end
  return {id=id,exclude=exclude}
end

end)()(function()return 0 end).id
local connect=(function()
-- Install only with the matching private normal native plugin. The public
-- addon continues to own the user's switch; this bridge does not add a UI.
return function(factory,id)
  local ffi=require('ffi');local S=rawget(_G,'stingray')
  local slot=rawget(_G,'__hd2ir_unit_instance_slot')
  if not S or type(slot)~='function' then return false end
  pcall(ffi.cdef,[[
    void *GetModuleHandleA(const char*);void *GetProcAddress(void*,const char*);unsigned GetTickCount(void);
    int memcmp(const void*,const void*,size_t);
    typedef struct {unsigned epoch,world,root,phase,early,count,units[61];} hd2_full_lane_v2;
    typedef struct {unsigned version,revision,preserve_count,preserve[31];hd2_full_lane_v2 lanes[64];} hd2_full_wire_v3;
    typedef struct {unsigned version,lane,epoch,revision,filters,self_bound,peer_bound,removed,clean,observed,complete,absent,self_seen;} hd2_full_ack_v3;
    typedef struct {unsigned version,revision,root,network,body,head,shape,count,texture_count,reserved;uint64_t resources[27],textures[54];} hd2_full_resources_v3;
    typedef struct {unsigned version,root,network,world,resource_revision;} hd2_full_offer_v3;
    typedef unsigned (*hd2_full_copy_fn)(void*,unsigned);
    typedef unsigned (*hd2_full_receive_fn)(const void*,unsigned);
    typedef unsigned (*hd2_full_resources_fn)(unsigned,unsigned,void*,unsigned);
    typedef unsigned (*hd2_full_mode_fn)(unsigned);
    typedef unsigned (*hd2_full_control_fn)(void);
    typedef struct {unsigned version,roots[4];} hd2_full_presentation_v1;
  ]])
  assert(ffi.sizeof('hd2_full_wire_v3')==17288 and ffi.sizeof('hd2_full_resources_v3')==688)
  local module=ffi.C.GetModuleHandleA('HD2NativeHandoffFull_w64_release.dll')
  local addon=ffi.C.GetModuleHandleA('HD2IndependentRig.addon64')
  if module==nil or addon==nil then return false end
  local function bind(m,name,kind)
    local p=ffi.C.GetProcAddress(m,name);assert(p~=nil,'Missing native handoff ABI: '..name);return ffi.cast(kind,p)
  end
  if tonumber(bind(addon,'hd2ir_runtime_route_v1','unsigned (*)(void)')())~=2 or
     tonumber(bind(module,'hd2ir_runtime_route_v1','unsigned (*)(void)')())~=2 then return false end
  local copy=bind(module,'hd2_full_snapshot','hd2_full_copy_fn')
  local ack=bind(module,'hd2_full_ack','hd2_full_receive_fn')
  local resource=bind(module,'hd2_full_resources','hd2_full_resources_fn')
  local offer=bind(module,'hd2_full_offer','hd2_full_receive_fn')
  local mode=bind(module,'hd2_full_mode','hd2_full_mode_fn')
  local control=bind(addon,'hd2ir_stock_teammate_trial_enabled','hd2_full_control_fn')
  local presentation=bind(module,'hd2_full_presentation_hint','hd2_full_copy_fn')
  local presentation_buffer=ffi.new('hd2_full_presentation_v1[1]')
  local presentation_roots={}
  assert(ffi.sizeof('hd2_full_ack_v3')==52)
  local buffer=ffi.new('hd2_full_wire_v3[1]');local receipt=ffi.new('hd2_full_ack_v3[1]')
  local request=ffi.new('hd2_full_resources_v3[1]');local ready=ffi.new('hd2_full_offer_v3[1]')
  local proofs,last_mode,next_poll={},nil,0
  local wire_crt=ffi.load('msvcrt')
  local cached_wire=ffi.new('hd2_full_wire_v3[1]')
  local cached_snapshot,reuse_token=nil,{}
  local function poll()
    local n=tonumber(copy(buffer,17288));if n==0 then return nil end;assert(n==17288)
    if cached_snapshot and wire_crt.memcmp(buffer,cached_wire,17288)==0 then return cached_snapshot,reuse_token end
    local b=buffer[0];assert(tonumber(b.version)==3)
    local s={version=3,revision=tonumber(b.revision),preserve={},lanes={}}
    local np=tonumber(b.preserve_count);assert(np>=1 and np<=31)
    for i=0,np-1 do s.preserve[#s.preserve+1]=tonumber(b.preserve[i])end
    for i=0,63 do local p=b.lanes[i];local n=tonumber(p.count);assert(n>=0 and n<=61)
      local q={epoch=tonumber(p.epoch),world=tonumber(p.world),root=tonumber(p.root),
        phase=tonumber(p.phase),early=tonumber(p.early),units={}}
      for j=0,n-1 do q.units[#q.units+1]=tonumber(p.units[j])end;s.lanes[i+1]=q
    end
    ffi.copy(cached_wire,buffer,17288);cached_snapshot=s
    return s
  end
  local gate=factory(id,slot,poll,function(a)
    for k,v in pairs(a)do receipt[0][k]=v end;return tonumber(ack(receipt,52))
  end,function(text)
    local trace=rawget(_G,'__hd2ir_peer_follow_trace')
    if type(trace)=='function' then trace('native-full-drain',text)end
  end,reuse_token)
  local U,GS,N,A,ID=S.Unit,S.GameSession,S.Network,S.Application,S.IdString64
  -- A numeric, expiring budget hint only. It never authenticates a writer,
  -- owner or gameplay root. Skipped presentation Worlds retain game visuals.
  function gate.presentation_begin()
    presentation_roots={}
    if tonumber(presentation(presentation_buffer,20))~=20 or tonumber(presentation_buffer[0].version)~=1 then return end
    for i=0,3 do local root=tonumber(presentation_buffer[0].roots[i])
      if root>0 and root<1073741824 then presentation_roots[root]=true end
    end
  end
  function gate.skip_presentation(avatars)
    if type(avatars)~='table' or #avatars>32 then return false end
    for _,unit in ipairs(avatars)do local root=id(unit)
      if root and presentation_roots[root]then return true end
    end
    return false
  end
  -- Independent user command delivery. Scene/resource observation can fail
  -- without silently keeping an older checkbox value. This grants no write.
  local control_state={requested=nil,received=nil,failures=0}
  function gate.control_begin()
    local ok,value=pcall(function()
      local enabled=tonumber(control());if enabled~=0 and enabled~=1 then return false end
      control_state.requested=enabled
      if enabled~=last_mode then
        if tonumber(mode(enabled))~=1 then return false end
        last_mode=enabled;control_state.received=enabled
      end
      return true
    end)
    if not ok or value~=true then control_state.failures=control_state.failures+1;return false end
    return true
  end
  function gate.control_state()return control_state end
  local begin=gate.begin
  function gate.begin()
    gate.control_begin()
    return begin()
  end
  local observe=gate.observe
  function gate.observe(contexts)
    gate.control_begin()
    observe(contexts)
    pcall(function()
      local now=tonumber(ffi.C.GetTickCount());if now<next_poll and next_poll-now<1000 then return end;next_poll=now+100
      local session=N.game_session();local self=N.peer_id()
      if not session or type(self)~='string' or self=='' or GS.in_session(session)~=true then return end
      local current={}
      if type(contexts)~='table' or #contexts>32 then return end
      for _,c in ipairs(contexts)do if type(c.avatars)=='table' and #c.avatars<=32 then
        local world=slot(c.world)
        for _,u in ipairs(c.avatars)do
          local root=id(u);local held=root and proofs[root]
          -- Requests originate in the authenticated native roster, independent
          -- of whether anyone wears a Mod. No cached userdata or classifier
          -- state supplies an actor identity.
          -- An old writer preserve list is not a current owner proof. This
          -- read-only request still requires fresh native roster and Lua owner.
          local got=root and tonumber(resource(root,0,request,688))==688
          local network=got and tonumber(request[0].network)
          if got and tonumber(request[0].version)==3 and tonumber(request[0].root)==root and
             network>0 and network~=0x7fff and world and world>0 and
             U.alive(u)==true and U.has_animation_state_machine(u)==true and
             GS.game_object_exists(session,network)==true and
             GS.game_object_is_type(session,network,'gl7xl2w')==true then
            local owner=GS.game_object_owner(session,network);local health=GS.game_object_field(session,network,'health')
            if type(owner)=='string' and owner~='' and owner~=self and
               type(health)=='number' and health==health and health>0 and health<1e9 then
              local proof={session=session,world=world,self=self,owner=owner,network=network}
              current[root]=proof
              do
                local r=request[0];local count=tonumber(r.count);local textures=tonumber(r.texture_count)
                local loaded=count>=1 and count<=27 and textures>=0 and textures<=54 and tonumber(r.reserved)==0
                local revision=tonumber(r.revision)
                local cached=held and held.resource_revision==revision and held.session==session and
                  held.world==world and held.self==self and held.owner==owner and held.network==network
                for j=0,(cached and -1 or count-1) do
                  if not loaded then break end
                  -- uint64 -> two exact uint32 words, never through double.
                  local halves=ffi.cast('const unsigned*',r.resources+j)
                  local hex=string.format('%08x%08x',tonumber(halves[1]),tonumber(halves[0]))
                  if A.can_get('unit',ID.from_hex(hex))~=true then loaded=false end
                end
                for j=0,(cached and -1 or textures-1) do
                  if not loaded then break end
                  local halves=ffi.cast('const unsigned*',r.textures+j)
                  local hex=string.format('%08x%08x',tonumber(halves[1]),tonumber(halves[0]))
                  if hex=='0000000000000000' or A.can_get('texture',ID.from_hex(hex))~=true then loaded=false end
                end
                if loaded and revision>0 and tonumber(r.root)==root and tonumber(r.network)==network and
                   N.game_session()==session then
                  proof.resource_revision=revision
                  ready[0].version=3;ready[0].root=root;ready[0].network=network;ready[0].world=world
                  ready[0].resource_revision=r.revision;offer(ready,20)
                end
              end
            end
          end
        end
      end end
      proofs=current
    end)
  end
  -- Both old callbacks must be withheld before first execution: otherwise two
  -- different replacement systems could own the same teammate appearance.
  rawset(_G,'__hd2ir_stock_swap_frame',function()end)
  rawset(_G,'__hd2ir_stock_swap_result',function()end)
  rawset(_G,'__hd2ir_native_legacy_disabled',true)
  rawset(_G,'__hd2ir_native_handoff',gate)
  return true
end

end)()
rawset(_G,'__hd2ir_connect_native_control',function()return connect(factory,id)end)
end

pcall(function()local install=rawget(_G,'__hd2ir_install_native_control');if install then install()end end)

pcall(function()
  --@@GC_POLICY_INTEGRATED_BEGIN@@
-- Embedded startup policy, not a separate Bingus module or callback wrapper.
-- Known third-party policies retain control. Removal takes a full VM restart.
do
  local function configure_gc_policy()
    local key = "HD2IRGcPolicy"
    -- Do not replace another revision, malformed state, or a previous attempt.
    -- Returning here returns from this helper, never from the runtime body.
    if rawget(_G, key) ~= nil then return end
    local state = {revision = "gc-pause400-1", status = "checking",
      requested_pause = 400, attempted = false, scope = "whole Lua VM"}
    rawset(_G, key, state)
    local loader = rawget(_G, "CowboyBingusModLoader")

    local function finish(status, reason)
      state.status, state.reason = status, reason
      -- One best-effort startup record. Logging cannot retry a GC operation.
      local file
      pcall(function()
        if type(loader) == "table" and type(loader.open_log) == "function" then
          file = loader.open_log("HD2IRGcPolicy.log")
        end
        if file then
          local now = os.time()
          local local_parts, utc_parts = os.date("*t", now), os.date("!*t", now)
          utc_parts.isdst = local_parts.isdst
          local offset = os.difftime(os.time(local_parts), os.time(utc_parts))
          local minutes = math.floor(math.abs(offset) / 60)
          local stamp = string.format("%s %s%02d:%02d", os.date("%Y-%m-%d %H:%M:%S", now),
            offset < 0 and "-" or "+", math.floor(minutes / 60), minutes % 60)
          file:write("HD2IR GC Policy ", state.revision,
            "\nlocal_time=", stamp, "\nstatus=", status,
            "\nreason=", reason, "\nrequested_pause=400\nprevious_pause=",
            tostring(state.previous_pause or "unknown"),
            "\nattempted=", tostring(state.attempted),
            "\nscope=whole Lua VM\nrestart_required_to_remove=true\n")
        end
      end)
      if file then pcall(function() file:close() end) end
    end

    if type(loader) ~= "table" or rawget(loader, "api") ~= 1 or
        type(rawget(loader, "modules")) ~= "table" then
      return finish("blocked", "Bingus API 1 is unavailable; runtime continues")
    end
    if rawget(_G, "HD2SmoothBoot") ~= nil then
      return finish("delegated", "SmoothBoot marker is present; its GC policy is preserved")
    end
    if rawget(_G, "HD2IRGcPolicyTest") ~= nil then
      return finish("delegated", "Legacy GC test marker is present; its policy is preserved")
    end
    -- Known resource presence, not require(): detect later loader entries too.
    -- Never read or edit the other policy's configuration or callback chain.
    local checked, owner = pcall(function()
      local sr = rawget(_G, "stingray")
      local app = type(sr) == "table" and sr.Application
      if app == nil or type(app.can_get) ~= "function" then
        error("resource lookup unavailable")
      end
      local smoothboot = app.can_get("lua", "mods/codex/smoothboot")
      if type(smoothboot) ~= "boolean" then error("invalid resource lookup result") end
      if smoothboot then return "SmoothBoot resource" end
      local legacy = app.can_get("lua", "mods/hd2ir/gc_policy_test")
      if type(legacy) ~= "boolean" then error("invalid resource lookup result") end
      if legacy then return "Legacy GC test resource" end
      return false
    end)
    if not checked then
      return finish("blocked", "Known-policy resource check failed; runtime continues")
    end
    if owner then
      return finish("delegated", owner .. " is present; its GC policy is preserved")
    end
    local gc = rawget(_G, "collectgarbage")
    if type(gc) ~= "function" then
      return finish("blocked", "GC setter is unavailable; runtime continues")
    end

    -- The only GC operation: no getter emulation, stepmul, restore or polling.
    -- A setter can fail after a side effect, so latch before calling it.
    state.attempted = true
    local applied, old = pcall(gc, "setpause", state.requested_pause)
    if not applied then
      return finish("failed", "GC setter raised an error; effective policy is unverified")
    end
    if type(old) ~= "number" or old ~= old or old == math.huge or old == -math.huge then
      return finish("unverified", "GC setter returned an unexpected prior value")
    end
    state.previous_pause = old
    return finish("applied_once", "Pause was set once; later external policy changes are preserved")
  end
  -- A failed optional policy must not stop the runtime's own initialization.
  pcall(configure_gc_policy)
end
--@@GC_POLICY_INTEGRATED_END@@
end)
