-- HD2-Addon: mods/hd2ir/runtime
-- Paired full-native control entry point for Bingus Shared Loader discovery.
local identity = "@@MODULE_IDENTITY@@"
local key = "__hd2ir_loader_state"
local previous = rawget(_G, key)
if previous ~= nil then
  if type(previous) == "table" and previous.identity == identity and previous.status == "active" then
    return previous
  end
  error("HD2 LUA: duplicate, incomplete, or different runtime; restart after correcting installed packages")
end
for _, name in ipairs({"__hd2ir_weapon_root_trial", "__hd2ir_scene_restore",
    "__hd2ir_gait_control", "__hd2ir_native_control_state"}) do
  if rawget(_G, name) ~= nil then
    error("HD2 LUA: another runtime is already active; migrate the old package first")
  end
end
local old_update, old_render = rawget(_G, "update"), rawget(_G, "render")
if type(old_update) ~= "function" or type(old_render) ~= "function" then
  error("HD2 LUA: game update/render callbacks are not ready")
end
local sr = rawget(_G, "stingray")
if type(sr) ~= "table" then error("HD2 LUA: Stingray API unavailable") end
for _, name in ipairs({"Application", "World", "Unit", "IdString64"}) do
  local ok, value = pcall(function() return sr[name] end)
  if not ok or value == nil then error("HD2 LUA: missing Stingray API " .. name) end
end
local ffi_ok, ffi = pcall(require, "ffi")
if not ffi_ok or type(ffi) ~= "table" then error("HD2 LUA: LuaJIT FFI unavailable") end
local saved = {}
local function owned(name)
  return type(name) == "string" and name:sub(1, 8) == "__hd2ir_"
end
for name, value in pairs(_G) do if owned(name) then saved[name] = value end end
local state = {identity = identity, status = "loading"}
rawset(_G, key, state)
local ok, reason = pcall(function()
--@@RUNTIME_BODY_BEGIN@@
@@RUNTIME_BODY@@
--@@RUNTIME_BODY_END@@
end)
-- Require positive installation of this exact control-only contract. Native
-- admission is separate and remains fail-closed until a fresh control receipt.
local control = rawget(_G, "__hd2ir_native_control_state")
local installed = rawget(_G, "update") == old_update and
  type(control) == "table" and control.version == 5 and control.installed == true and
  type(control.render) == "function" and control.render ~= old_render and
  rawget(_G, "render") == control.render and
  rawget(_G, "__hd2ir_native_legacy_disabled") == true and
  type(rawget(_G, "__hd2ir_connect_native_control")) == "function" and
  type(rawget(_G, "__hd2ir_install_native_control")) == "function" and
  rawget(_G, "__hd2ir_weapon_root_trial") == nil and
  rawget(_G, "__hd2ir_scene_restore") == nil and
  rawget(_G, "__hd2ir_gait_control") == nil
if not ok or not installed then
  rawset(_G, "update", old_update)
  rawset(_G, "render", old_render)
  local remove = {}
  for name in pairs(_G) do if owned(name) then remove[#remove + 1] = name end end
  for _, name in ipairs(remove) do rawset(_G, name, nil) end
  for name, value in pairs(saved) do rawset(_G, name, value) end
  state.status = "failed"
  state.reason = ok and "native control initialization incomplete" or tostring(reason)
  rawset(_G, key, state)
  error("HD2 LUA: " .. state.reason)
end
state.status = "active"
return state
